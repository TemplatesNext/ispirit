<?php


add_action( 'vc_before_init', 'ispirit_vc_heading' );
function ispirit_vc_heading() {
	vc_map( 
		array(
      		"name" => __( "NX heading", "ispirit" ),
      		"base" => "nx_heading",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Style", "ispirit" ),
            		"param_name" => "style",
					'value' => array(
								__( 'Default', 'nx' ) => 'default',
								__( 'Underlined', 'nx' ) => 'underlined',
								__( 'Middlelined', 'nx' ) => 'centerlined',
								__( 'Short Underlined Colored', 'nx' ) => 'coloredline',
							),				
            		"description" => __( "Choose style for this heading", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Heading Tag", "ispirit" ),
            		"param_name" => "heading_tag",
					'value' => array(
								__( 'Default-div', 'nx' ) => 'div',
								__( 'H1', 'nx' ) => 'h1',
								__( 'H2', 'nx' ) => 'h2',
								__( 'H3', 'nx' ) => 'h3',
								__( 'H4', 'nx' ) => 'h4',
								__( 'H5', 'nx' ) => 'h5',															
							),				
            		"description" => __( "Choose a heading tag", "ispirit" )
         		),						
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Font Size, (Min 7 and max 48 pixels)", "ispirit" ),
            		"param_name" => "size",
            		"value" => '24',
            		"description" => __( "Enter heading font size (pixels)", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Alignment", "ispirit" ),
            		"param_name" => "align",
					'value' => array(
								__( 'Left', 'nx' ) => 'left',
								__( 'Center', 'nx' ) => 'center',
								__( 'Right', 'nx' ) => 'right',														
							),				
            		"description" => __( "Heading text alignment", "ispirit" )
         		),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Margin", "ispirit" ),
            		"param_name" => "margin",
            		"value" => '16',
            		"description" => __( "Bottom margin (pixels)", "ispirit" )
         		),				
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Link Text", "ispirit" ),
            		"param_name" => "linktext",
            		"value" => "",
            		"description" => __( "Optional hyper link to another page or section", "ispirit" )
         		),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Link URL", "ispirit" ),
            		"param_name" => "linkurl",
            		"value" => "",
            		"description" => __( "URL for the optional link, including http://", "ispirit" )
         		),				
				array(
					"type" => "textarea",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Heading Text", "ispirit" ),
					"param_name" => "content",
					"value" => __( "Heading text", "ispirit" ),
					"description" => __( "Enter your heading text.", "my-text-domain" )
				),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Class", "ispirit" ),
            		"param_name" => "class",
            		"value" => "",
            		"description" => __( "Optional custom class", "ispirit" )
         		)							
													
      		)
			
   		)			 
	);
}


add_action( 'vc_before_init', 'ispirit_vc_calltoact' );
function ispirit_vc_calltoact() {
	vc_map( 
		array(
      		"name" => __( "NX Call To Act", "ispirit" ),
      		"base" => "nx_calltoact",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		//'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
      		//'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      		"params" => array(
         		array(
            		"type" => "colorpicker",
            		"class" => "",
            		"heading" => __( "Background Color", "ispirit" ),
            		"param_name" => "cta_bgcolor",
            		"value" => '#77be32', //Default Red color
            		"description" => __( "Call to act background color", "ispirit" )
         		),			
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Text Color", "ispirit" ),
            		"param_name" => "cta_textcolor",
            		//"value" => __( "light", "ispirit" ),
					'value' => array(
						'light' 	=> 'light',
						'dark' 		=> 'Dark'
					),					
            		"description" => __( "Call to act text color", "ispirit" )
         		),
         		array(
            		"type" => "textfield",
            		"holder" => "div",
            		"class" => "",
            		"heading" => __( "Button Text", "ispirit" ),
            		"param_name" => "cta_button_text",
            		"value" => __( "Know More..", "ispirit" )
         		),
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Button Link URL", "ispirit" ),
            		"param_name" => "cta_button_url",
            		"value" => __( "http://www.google.com/", "ispirit" )
         		),
         		array(
            		"type" => "textarea",
            		"holder" => "div",
            		"class" => "",
            		"heading" => __( "Content", "ispirit" ),
            		"param_name" => "content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
            		"value" => __( "Call to act text", "ispirit" ),
            		"description" => __( "Enter call to act content.", "ispirit" )
         		),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Class", "ispirit" ),
            		"param_name" => "class",
            		"value" => "",
            		"description" => __( "Optional custom class", "ispirit" )
         		)
      		)
			
   		)			 
	);
}

add_action( 'vc_before_init', 'ispirit_vc_blog' );
function ispirit_vc_blog() {
	vc_map( 
		array(
      		"name" => __( "NX Blog", "ispirit" ),
      		"base" => "nx_blog",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Post Per Page", "ispirit" ),
            		"param_name" => "posts_per_page",
            		"value" => 10,
            		"description" => __( "Enter a number between 1 to 1000", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Layout Type", "ispirit" ),
            		"param_name" => "blog_layout",
					'value' => array(
								__( 'Standard',  "nx"  ) => '1',
								__( 'Masonry',  "nx"  ) => '2',
								__( 'Masonry Modern',  "nx"  ) => '3',								
					),					
            		"description" => __( "Select blog layout type", "ispirit" )
         		),	
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number of columns", "ispirit" ),
            		"param_name" => "columns",
					'value' => array(
								__( '2', 'nx' ) => '2',
								__( '3', 'nx' ) => '3',
								__( '4', 'nx' ) => '4',
							),				
            		"description" => __( "Number of columns in blog layout", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Show Catagories", "ispirit" ),
            		"param_name" => "meta_cat",
					'value' => array(
								__( 'Yes', 'nx' ) 	=> 'yes',
								__( 'No', 'nx' ) 	=> 'no',
							),				
            		"description" => __( "Show or Hide Categories", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Show \"Read More\"", "ispirit" ),
            		"param_name" => "read_more",
					'value' => array(
								__( 'Yes', 'nx' ) 	=> 'yes',
								__( 'No', 'nx' ) 	=> 'no',
							),				
            		"description" => __( "Show or Hide Read More links", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Paging", "ispirit" ),
            		"param_name" => "paging",
					'value' => array(
								__( 'Yes', 'nx' ) 	=> 'yes',
								__( 'No', 'nx' ) 	=> 'no',
							),				
            		"description" => __( "Use Pagination", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Pagination & filter alignment", "ispirit" ),
            		"param_name" => "pagnav_align",
					'value' => array(
								__( 'Left', 'nx' ) => 'left',
								__( 'Right', 'nx' ) => 'right',
								__( 'Center', 'nx' ) => 'center',
							),				
            		"description" => __( "Pagination & filter alignment", "ispirit" )
         		)
      		)
			
   		)			 
	);
}

add_action( 'vc_before_init', 'ispirit_vc_blog_carousel' );
function ispirit_vc_blog_carousel() {
	vc_map( 
		array(
      		"name" => __( "NX Blog Carousel", "ispirit" ),
      		"base" => "nx_blogcarousel",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Post Per Page", "ispirit" ),
            		"param_name" => "posts_per_page",
            		"value" => 6,
            		"description" => __( "Enter a number between 1 to 1000", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Layout Type", "ispirit" ),
            		"param_name" => "blog_car_layout",
					'value' => array(
								__( 'Standard',  "nx"  ) => '1',
								__( 'Modern',  "nx"  ) => '2',
					),					
            		"description" => __( "Select layout type", "ispirit" )
         		),	
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number of columns", "ispirit" ),
            		"param_name" => "columns",
					'value' => array(
								__( '2', 'nx' ) => '2',
								__( '3', 'nx' ) => '3',
								__( '4', 'nx' ) => '4',
							),				
            		"description" => __( "Number of columns in blog layout", "ispirit" )
         		)
      		)
			
   		)			 
	);
}

add_action( 'vc_before_init', 'ispirit_vc_portfolio' );
function ispirit_vc_portfolio() {
	vc_map( 
		array(
      		"name" => __( "NX Portfolio", "ispirit" ),
      		"base" => "nx_portfolio",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Portfolio Item Per Page", "ispirit" ),
            		"param_name" => "posts_per_page",
            		"value" => 10,
            		"description" => __( "Enter a number between 1 to 1000", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Portfolio Layout", "ispirit" ),
            		"param_name" => "layout",
					'value' => array(
							__( 'Masonry Standard',  "nx"  ) => '2',
							__( 'Masonry gallery',  "nx"  ) => '1',
					),					
            		"description" => __( "Select portfolio layout type", "ispirit" )
         		),	
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number of columns", "ispirit" ),
            		"param_name" => "columns",
					'value' => array(
								__( '2', 'nx' ) => '2',
								__( '3', 'nx' ) => '3',
								__( '4', 'nx' ) => '4',
							),				
            		"description" => __( "Number of columns in layout", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Category Filter", "ispirit" ),
            		"param_name" => "filtering",
					'value' => array(
								__( 'No', 'nx' ) 	=> 'no',
								__( 'Yes', 'nx' ) 	=> 'yes',
							),				
            		"description" => __( "Use catagory Filter (only available with masonry layout)", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Paging", "ispirit" ),
            		"param_name" => "paging",
					'value' => array(
								__( 'No', 'nx' ) 	=> 'no',
								__( 'Yes', 'nx' ) 	=> 'yes',
							),				
            		"description" => __( "Use Pagination", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Pagination & filter alignment", "ispirit" ),
            		"param_name" => "pagnav_align",
					'value' => array(
								__( 'Left', 'nx' ) => 'left',
								__( 'Right', 'nx' ) => 'right',
								__( 'Center', 'nx' ) => 'center',	
							),				
            		"description" => __( "Pagination & filter alignment", "ispirit" )
         		),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Class", "ispirit" ),
            		"param_name" => "class",
            		"value" => "",
            		"description" => __( "Optional custom class", "ispirit" )
         		)		
      		)
			
   		)			 
	);
}



add_action( 'vc_before_init', 'ispirit_vc_team' );
function ispirit_vc_team() {
	vc_map( 
		array(
      		"name" => __( "NX Team", "ispirit" ),
      		"base" => "nx_team",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Team Member Per Page", "ispirit" ),
            		"param_name" => "posts_per_page",
            		"value" => 4,
            		"description" => __( "Enter a number between 1 to 1000", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number of columns", "ispirit" ),
            		"param_name" => "columns",
					'value' => array(
								__( '2', 'nx' ) => '2',
								__( '3', 'nx' ) => '3',
								__( '4', 'nx' ) => '4',
							),				
            		"description" => __( "Number of columns in layout", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Paging", "ispirit" ),
            		"param_name" => "paging",
					'value' => array(
								__( 'No', 'nx' ) 	=> 'no',
								__( 'Yes', 'nx' ) 	=> 'yes',
							),				
            		"description" => __( "Use Pagination", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Pagination & filter alignment", "ispirit" ),
            		"param_name" => "pagnav_align",
					'value' => array(
								__( 'Left', 'nx' ) => 'left',
								__( 'Right', 'nx' ) => 'right',
								__( 'Center', 'nx' ) => 'center',	
							),				
            		"description" => __( "Pagination & filter alignment", "ispirit" )
         		)			
      		)
			
   		)			 
	);
}


add_action( 'vc_before_init', 'ispirit_vc_testimonials' );
function ispirit_vc_testimonials() {
	vc_map( 
		array(
      		"name" => __( "NX Testimonials", "ispirit" ),
      		"base" => "nx_testimonials",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Testimonial Style", "ispirit" ),
            		"param_name" => "style",
					'value' => array(
								__( 'Default', 'nx' ) => 'default',
								__( 'Centererd', 'nx' ) => 'centererd',
								__( 'Centered Compact', 'nx' ) => 'centererd-compact',	
							),				
            		"description" => __( "Testimonial style", "ispirit" )
         		),
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Delay (millisecond)", "ispirit" ),
            		"param_name" => "delay",
            		"value" => 8000,
            		"description" => __( "Enter a number between 1000 to 20000 (1 to 20 seco0nd)", "ispirit" )
         		)							
      		)
			
   		)			 
	);
}

add_action( 'vc_before_init', 'ispirit_vc_clients' );
function ispirit_vc_clients() {
	vc_map( 
		array(
      		"name" => __( "NX Clients", "ispirit" ),
      		"base" => "nx_clients",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Client ID\'s", "ispirit" ),
            		"param_name" => "post__in",
            		"value" => '',
            		"description" => __( "Enter comma separated ID's of the client that you want to show", "ispirit" )
         		),
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number Of Clients", "ispirit" ),
            		"param_name" => "posts_per_page",
            		"value" => 4,
            		"description" => __( "Specify number of clients you want to show.", "ispirit" )
         		),					
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Border Around Logo", "ispirit" ),
            		"param_name" => "client_border",
					'value' => array(
								__( 'Use Border', 'nx' ) => '1',
								__( 'Hide Border', 'nx' ) => '2',
							),				
            		"description" => __( "Use border around the clients logo", "ispirit" )
         		)						
      		)
			
   		)			 
	);
}

add_action( 'vc_before_init', 'ispirit_vc_products_carousel' );
function ispirit_vc_products_carousel() {
	vc_map( 
		array(
      		"name" => __( "NX Products Carousel", "ispirit" ),
      		"base" => "nx_products_carusel",
      		"class" => "",
      		"category" => __( "TemplatesNext", "ispirit"),
			"icon" => get_template_directory_uri() . '/images/tnext-logo.png',			
      		"params" => array(
				array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Product or Category ID\'s", "ispirit" ),
            		"param_name" => "prod_ids",
            		"value" => '',
            		"description" => __( "Enter comma separated ID\'s of the products/categories that you want to show or keep it blank. Works only with \"Products By ID\" and \"Product Categories\"", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "div",
            		"class" => "",
            		"heading" => __( "Carusel Listing Type", "ispirit" ),
            		"param_name" => "product_listing_type",
					'value' => array(
								__( 'Recent Products', 'nx' ) => 'recent_products',
								__( 'Product Categories', 'nx' ) => 'product_categories',
								__( 'Featured products', 'nx' ) => 'featured_products',
								__( 'Products on Sale', 'nx' ) => 'sale_products',
								__( 'Best Selling Products', 'nx' ) => 'best_selling_products',
								__( 'Top Rated Products', 'nx' ) => 'top_rated_products',
								__( 'Products By ID', 'nx' ) => 'products',																
							),				
            		"description" => __( "Select product listing type for the carusel", "ispirit" )
         		),
         		array(
            		"type" => "dropdown",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number Of Columns", "ispirit" ),
            		"param_name" => "columns",
					'value' => array(
								__( '4', 'nx' ) => 4,
								__( '2', 'nx' ) => 2,
								__( '3', 'nx' ) => 3,
								__( '5', 'nx' ) => 5,
								__( '6', 'nx' ) => 6,
							),				
            		"description" => __( "Select number of column to be shown in the carusel", "ispirit" )
         		),
         		array(
            		"type" => "textfield",
            		"holder" => "",
            		"class" => "",
            		"heading" => __( "Number Of Products", "ispirit" ),
            		"param_name" => "number",
            		"value" => 8,
            		"description" => __( "Enter number of product to be shown in the carusel, min. 4 and max. 20 products", "ispirit" )
         		)						
      		)
			
   		)			 
	);
}

