<?php


if (isset($_GET['activated']) && is_admin()) {
	set_transient( '_welcome_screen_activation_redirect', true, 30 );
}

add_action( 'admin_init', 'welcome_screen_do_activation_redirect' );
function welcome_screen_do_activation_redirect() {
  // Bail if no activation redirect
    if ( ! get_transient( '_welcome_screen_activation_redirect' ) ) {
    return;
  }

  // Delete the redirect transient
  delete_transient( '_welcome_screen_activation_redirect' );

  // Bail if activating from network, or bulk
  if ( is_network_admin() || isset( $_GET['activate-multi'] ) ) {
    return;
  }

  // Redirect to bbPress about page
  wp_safe_redirect( add_query_arg( array( 'page' => 'welcome-screen-about' ), admin_url( 'themes.php' ) ) );

}

add_action('admin_menu', 'welcome_screen_pages');

function welcome_screen_pages() {
	add_theme_page(
		'Welcome To Welcome i-spirit',
		'About i-spirit',
		'read',
		'welcome-screen-about',
		'welcome_screen_content',
		'dashicons-awards', 
		6 		
	);
}

function welcome_screen_content() {
	
	include get_template_directory() . '/inc/theme-welcome/tw-content.php';
	include get_template_directory() . '/inc/theme-welcome/tw-functions.php';	
	
	$logo_url = get_template_directory_uri() . '/inc/theme-welcome/welcome-logo.png';
	$img_url = get_template_directory_uri() . '/inc/theme-welcome/images/';
	$active_tab = 'ispirit_about';
	
	/* Urls */
	$reviewURL = esc_url('//www.templatesnext.org/ispirit/landing/reviews/');
	$goPremiumURL = esc_url('//www.templatesnext.org/ispirit/landing/');
	$videoguide = esc_url('//www.templatesnext.org/ispirit/landing/i-spirit-video-guide/');
	$supportforum = esc_url('//www.templatesnext.org/ispirit/landing/forums/forum/premium-theme/i-spirit-support/'); 
	$toolkit = esc_url('//www.templatesnext.org/ispirit/landing/start-up-guide/');
	$fb_page = esc_url('//www.facebook.com/templatesnext/');
	$pb_tutorial = esc_url('https://siteorigin.com/page-builder/documentation/');


	$ocdi_buttont = "";
	if ( class_exists('OCDI_Plugin') ) {
		$ocdi_buttont = "button-enabled";
	} else
	{
		$ocdi_buttont = "button-disabled";
	} 	
	$details_theme = wp_get_theme();
	$name_version = $details_theme->get( 'Name' ) . " - " . $details_theme->get( 'Version' );
  	?>
  	<div class="wrapp">
        <div class="nx-info-wrap-2 welcome-panel">
        	
        	<div class="nx-info-wrap">
            	
                <div class="nx-welcome"><?php _e( 'Welcome To ', 'i-spirit' ); echo $name_version; ?></div>
                <div class="tx-wspace-24"></div>
                <div class="tx-wspace-24"></div>                
                <div class="nx-info-desc">
                    <p>
						<?php _e( 'Congratulations! You are about to use most flexible and powerful premium WordPress theme combined with #1 premium slider and page builder.', 'i-spirit' ); ?>
                    </p>
                    <a class="button button-primary button-hero" href="<?php echo $reviewURL; ?>">
                    <?php _e( 'Post Your Review', 'i-spirit' ); ?>
                    </a>  
                </div>
                <div class="tx-wspace-12"></div>
                <div class="nx-admin-row">
                	<div class="one-four-col">
                    	<a href="<?php echo $videoguide; ?>" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-video-alt2"></span></div>
                            <h3 class="tx-admin-link"><?php _e( 'Video Guide', 'i-spirit' ); ?></h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="<?php echo $supportforum; ?>" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-format-chat"></span></div>
                            <h3 class="tx-admin-link"><?php _e( 'Support Forum', 'i-spirit' ); ?></h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="<?php echo $toolkit; ?>" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-migrate"></span></div>
                            <h3 class="tx-admin-link"><?php _e( 'Setup Guide', 'i-spirit' ); ?></h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="<?php echo $fb_page; ?>" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-facebook-alt"></span></div>
                            <h3 class="tx-admin-link"><?php _e( 'Community', 'i-spirit' ); ?></h3>
                        </a>
                    </div>                                                            
                </div>
                <div class="tx-wspace-24"></div>
                <?php
					if( isset( $_GET[ 'tab' ] ) ) {
						$active_tab = $_GET[ 'tab' ];
					}
				?>
                <h2 class="nav-tab-wrapper">
                    <a href="?page=welcome-screen-about&tab=ispirit_about" class="nav-tab <?php echo $active_tab == 'ispirit_about' ? 'nav-tab-active' : ''; ?>">
                   		<?php _e( 'Starting with i-spirit', 'i-spirit' ); ?>
                    </a>
                    <a href="?page=welcome-screen-about&tab=ispirit_kick" class="nav-tab <?php echo $active_tab == 'ispirit_kick' ? 'nav-tab-active' : ''; ?> nx-kick">
                    	<?php _e( 'One Click Kick Start', 'i-spirit' ); ?>
                    </a>
                    <a href="?page=welcome-screen-about&tab=ispirit_plugins" class="nav-tab <?php echo $active_tab == 'ispirit_plugins' ? 'nav-tab-active' : ''; ?>">
                    	<?php _e( 'Plugins', 'i-spirit' ); ?>
                    </a>
                    <a href="?page=welcome-screen-about&tab=ispirit_faq" class="nav-tab <?php echo $active_tab == 'ispirit_faq' ? 'nav-tab-active' : ''; ?> nx-plug">
                    	<?php _e( 'FAQs/Support', 'i-spirit' ); ?>
                    </a>
                </h2>
                
                <?php
					if( $active_tab == 'ispirit_about' )
					{
				?> 
                	<div class="nx-tab-content">
                		<p>&nbsp;</p>
                        <ol>
							<?php
									echo '<li>';
									_e( 'Install Plugins', 'i-excel' );
									printf( __( 'To install and activate all the recommended plugin at once, go to menu "Appearance" > "<a href="%sthemes.php?page=tgmpa-install-plugins">Install Plugins</a>".', 'i-excel' ), admin_url() );
									echo '</li>';
									
									echo '<li>';
									_e( 'One Click Demo Setup', 'i-excel' );
									printf( __( 'i-excel comes with "<a href="%sthemes.php?page=pt-one-click-demo-import">One Click Demo Setup</a>", You can import and setup copy of any of our demo website in one click.', 'i-excel' ), admin_url() );
									echo '</li>';
									
									echo '<li>';
									_e( 'Start Customizing', 'i-excel' );
									printf( __( 'To start setting up your theme go to menu "<a href="%sadmin.php?page=_options&tab=0">i-spirit Options</a>".".', 'i-spirit' ), admin_url() );
									echo '</li>';								
                            ?>                         
                        </ol>
        			</div>
				<?php		
					} elseif ( $active_tab == 'ispirit_kick' )
					{
				?>     
                	<div class="nx-tab-content">
                		<h3><?php echo $kick_start['title']; ?></h3>
                        <?php echo $kick_start['desc'];?>
                        <a class="button button-primary button-hero <?php echo $ocdi_buttont; ?>" href="<?php echo admin_url(); ?>themes.php?page=pt-one-click-demo-import"><?php echo $kick_start['linktext']; ?></a>
                	</div>      
                        
				<?php						
					} elseif ( $active_tab == 'ispirit_plugins' )
					{
				?>     
                	<div class="nx-tab-content"> 
                		<p>&nbsp;</p>
                        <ol>
							<?php
			
								foreach ($tx_plugins as $plugin) {
									
									$pluginLocation = rawurlencode($plugin['slug'].'/'.$plugin['pluginfile']);
									$pluginLink = ispirit_plugin_activation( $pluginLocation, $plugin['slug'], $plugin['pluginfile'] );
									$nonce_install = ispirit_plugin_install($plugin['slug'], $plugin['wprepo'], $plugin['repourl']);
															
									
									echo '<li><b>'.$plugin['name'].'</b><br />';
									echo $plugin['desc'].'<br />';
									
									if(!empty($plugin['pluginurl']))
									{
										echo _e( 'Plugin URL : ', 'i-spirit' ).'<a href="'.$plugin['pluginurl'].'" target="_blank">'.$plugin['pluginurl'].'</a><br />';
									}
									if(!empty($plugin['tutorial']))
									{
										echo _e( 'Tutorial : ', 'i-spirit' ).'<a href="'.$plugin['tutorial'].'" target="_blank">'.$plugin['tutorial'].'</a><br />';   
									}
									if( $plugin['wprepo'] != 0 )
									{
										$pluginTitle = $plugin['title'];
										if ( is_plugin_active( $plugin['slug'].'/'.$plugin['pluginfile'] ) ) {
											echo '<a href="#" class="button disabled">' . __( 'Plugin installed and active', 'i-spirit' ) . '</a>';  
										} elseif( ispirit_is_plugin_installed($pluginTitle) == false )
										{
											echo '<a data-slug="' . $plugin['slug'] . '" data-active-lebel="' . __( 'Installing...', 'i-spirit' ) . '" class="install-now button" href="' . esc_url( $nonce_install ) . '" data-name="' . $plugin['slug'] . '" aria-label="Install ' . $plugin['slug'] . '">' . __( 'Install and activate', 'i-spirit' ) . '</a>';
										} else
										{
											echo '<a class="button activate-now button-primary" data-active-lebel="' . __( 'Activating...', 'i-spirit' ) . '" data-slug="' . $plugin['slug'] . '" href="' . esc_url( $pluginLink ) . '" aria-label="Activate ' . $plugin['slug'] . '">Activate</a>';
										}
									} else
									{
										printf( __( '<p>Manual installation required from menu "Appearance" > "<a href="%s">Install Plugins</a>"</p>', 'i-excel' ), admin_url().'themes.php?page=tgmpa-install-plugins' );
										?>
                                            <div class="tx-wspace-24"></div>
                                        <?php
									}
									
									echo '</li>';
									
								}
                            ?>                    
                        </ol>
        			</div>       
                        
				<?php	
					} elseif ( $active_tab == 'ispirit_faq' )
					{
				?>     
                	<div class="nx-tab-content"> 
                		<p>&nbsp;</p>
                        <?php
							foreach ($tx_faqs as $faq) {
								echo '<b>'._e( 'Q. ', 'i-spirit' ).$faq['question'].'</b><br />';
								echo _e( 'A. ', 'i-spirit' ).$faq['answeer'].'<br /><br />';									   
							}
                        ?>                    
                        
        			</div>      
                        
				<?php	
					}
				?>
  
                <div class="tx-wspace-24"></div><div class="tx-wspace-24"></div>    
 	
            </div>
        	<div class="welcome-logo"><img src="<?php echo $logo_url; ?>" alt="" class="welcome-logo-img" width="" /></div>            
        </div>
        
  	</div>
  
  	<?php
}

add_action( 'admin_head', 'welcome_screen_remove_menus' );
function welcome_screen_remove_menus() {
    remove_submenu_page( 'index.php', 'welcome-screen-about' );
}


// Add Stylesheet
add_action( 'admin_enqueue_scripts', 'ispirit_welcome_scripts' );
function ispirit_welcome_scripts() {
	wp_enqueue_style( 'nx-welcome-style', get_template_directory_uri() . '/inc/theme-welcome/css/nx-welcome.css', array(), '1.01' );
	wp_enqueue_script( 'nx-welcome-script', get_template_directory_uri() . '/inc/theme-welcome/js/nx-welcome.js' );
}
