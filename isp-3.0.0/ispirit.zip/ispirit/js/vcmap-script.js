
!function($) {

	/* Select an icon select out of text input */
	$('.isp-iselect').iconpicker(".isp-iselect");

}(window.jQuery);