<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 */

function wpr_optionsframework_option_name() {
	$wpr_optionsframework_settings = get_option( 'wpr_optionsframework' );
	$wpr_optionsframework_settings['id'] = 'nxrmenu_options';
	update_option( 'wpr_optionsframework', $wpr_optionsframework_settings );
}

add_filter( 'wpr_optionsframework_menu', 'wpr_add_responsive_menu' );

function wpr_add_responsive_menu( $menu ) {
	$menu['page_title']  = 'Nx Responsive Menu';
	$menu['menu_title']  = 'Responsive Menu';
	$menu['mode']		 = 'menu';
	$menu['menu_slug']   = 'nx-responsive-menu';
	$menu['position']    = '200';
	return $menu;
}
/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'options_framework_theme'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
 */
$options = get_option('nxrmenu_options');
function wpr_optionsframework_options() {

    $options = array();

    $options[] = array('name' => __('General Settings', 'nxrmenu'),
        'type' => 'heading');
		
	$options[] = array('name' => __('Enable Mobile Navigation', 'nxrmenu'),
		'desc' => __('Check if you want to activate mobile navigation.', 'nxrmenu'),
		'id' => 'enabled',
		'std' => '1',
		'type' => 'checkbox');
	/*	
	$menus = get_terms('nav_menu',array('hide_empty'=>false));
	$menu = array();
	foreach( $menus as $m ) {
		$menu[$m->term_id] = $m->name;
	}
	$options[] = array('name' => __('Select Menu', 'nxrmenu'),
	'desc' => __('Select the menu you want to display for mobile devices.', 'nxrmenu'),
	'id' => 'menu',
	'std' => '',
	'class' => 'mini',
	'options' => $menu,
	'type' => 'select');
	*/
	$options[] = array('name' => __('Elements to hide in mobile:', 'nxrmenu'),
	'desc' => __('Enter the css class/ids for different elements you want to hide on mobile separeted by a comma(,). Example: .nav,#main-menu ', 'nxrmenu'),
	'id' => 'hide',
	'std' => '.sidr-menu .menu-toggle, .sidr-menu .alt-menu-toggle, .classic-menu .menu-toggle',
	'type' => 'text');
	
	$options[] = array('name' => __('Enable Swipe', 'nxrmenu'),
		'desc' => __('Enable swipe gesture to open/close menus, Only applicable for left/right menu.', 'nxrmenu'),
		'id' => 'swipe',
		'std' => 'yes',
		'options' => array('yes' => 'Yes','no' => 'No'),
		'type' => 'radio');
	
	$options[] = array('name' => __(' Search Box', 'nxrmenu'),
	'desc' => __(' Select the position of search box or simply hide the search box if you donot need it.', 'nxrmenu'),
	'id' => 'search_box',
	'std' => 'below_menu',
	'options' => array('above_menu' => 'Above Menu','below_menu' => 'Below Menu', 'hide'=> 'Hide search box' ),
	'type' => 'select');

	$options[] = array('name' => __(' Search Box Text', 'nxrmenu'),
	'desc' => __('Enter the text that would be displayed on the search box placeholder.', 'nxrmenu'),
	'id' => 'search_box_text',
	'std' => 'Search...',
	'type' => 'text');
		
	$options[] = array('name' => __('Allow zoom on mobile devices', 'nxrmenu'),
		'desc' => __('', 'nxrmenu'),
		'id' => 'zooming',
		'std' => 'yes',
		'options' => array('yes' => 'Yes','no' => 'No'),
		'type' => 'radio');
		
	$options[] = array('name' => __('Menu Appearance', 'nxrmenu'),
		'type' => 'heading');
	
	$options[] = array('name' => __('Menu Symbol Position', 'nxrmenu'),
	'desc' => __('Select menu icon position which will be displayed on the menu bar.', 'nxrmenu'),
	'id' => 'menu_symbol_pos',
	'std' => 'left',
	'class' => 'mini',
	'options' => array('left' => 'Left','right' => 'Right'),
	'type' => 'select');

	$options[] = array('name' => __('Menu Text', 'nxrmenu'),
	'desc' => __('Entet the text you would like to display on the menu bar.', 'nxrmenu'),
	'id' => 'bar_title',
	'std' => 'MENU',
	'class' => 'mini',
	'type' => 'text');

	$options[] = array('name' => __('Menu Logo', 'nxrmenu'),
	'desc' => __('Select menu logo.', 'nxrmenu'),
	'id' => 'bar_logo',
	'std' => '',
	'type' => 'upload');

	$options[] = array('name' => __('Menu Open Direction', 'nxrmenu'),
	'desc' => __('Select the direction from where menu will open.', 'nxrmenu'),
	'id' => 'position',
	'std' => 'left',
	'class' => 'mini',
	'options' => array('left' => 'Left','right' => 'Right', 'top' => 'Top' ),
	'type' => 'select');

	$options[] = array('name' => __('Display menu from width (in px)', 'nxrmenu'),
	'desc' => __(' Enter the width (in px) below which the responsive menu will be visible on screen', 'nxrmenu'),
	'id' => 'from_width',
	'std' => '1069',
	'class' => 'mini',
	'type' => 'text');

	$options[] = array('name' => __('Menu Width', 'nxrmenu'),
	'desc' => __('Enter menu width in (%) only applicable for left and right menu.', 'nxrmenu'),
	'id' => 'how_wide',
	'std' => '80',
	'class' => 'mini',
	'type' => 'text');
	
	$options[] = array('name' => __('Menu bar background color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'bar_bgd',
	'std' => '#0D0D0D',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu bar text color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'bar_color',
	'std' => '#F2F2F2',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu background color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_bgd',
	'std' => '#2E2E2E',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu text color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_color',
	'std' => '#CFCFCF',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu mouse over text color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_color_hover',
	'std' => '#606060',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu icon color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_icon_color',
	'std' => '#FFFFFF',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu borders(top & left) color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_border_top',
	'std' => '#0D0D0D',
	'type' => 'color');
	
	$options[] = array('name' => __('Menu borders(bottom) color', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_border_bottom',
	'std' => '#131212',
	'type' => 'color');
	
	$options[] = array('name' => __('Enable borders for menu items', 'nxrmenu'),
	'desc' => __('', 'nxrmenu'),
	'id' => 'menu_border_bottom_show',
	'std' => 'yes',
	'options' => array('yes' => 'Yes','no' => 'No'),
	'type' => 'radio');

    return $options;
}