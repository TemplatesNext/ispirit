<?php
/**
 * Template for team index
 *
 * @package templatesnext Shortcode
 */
include( 'content-team.php' );	

?>
