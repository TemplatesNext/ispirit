<?php

include( 'content-standard.php' );	

?>