<?php 
	$classes[] = 'nx-col-1-' . $atts['columns'];
	
	$thumb_full_url = "";
	$thumb_post_url = 1;
	$pop_height = 700;
	$pop_width = 1200;
	$image_placeholder = get_template_directory_uri() . '/images/placeholder-1200x1200.png';
	
	if( $atts['columns'] == 1 )
	{
		$th_width = 1200;
		$th_height = 800;		
	} else if( $atts['columns'] == 2 )
	{
		$th_width = 600;
		$th_height = 600;			
	} else if( $atts['columns'] == 3 )
	{
		$th_width = 600;
		$th_height = 600;			
	} else if( $atts['columns'] == 4 )
	{
		$th_width = 600;
		$th_height = 600;		
	}

	                
	if( has_post_thumbnail() )
	{
		$thumb_image_id = get_post_thumbnail_id();
		$thumb_img_url = wp_get_attachment_url( $thumb_image_id,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
		$thumb_resized = nx_image_resize( $thumb_img_url, $th_width, $th_height, true, true ); //resize & crop the image			
		$thumb_full_url = $thumb_img_url;
	}
						
?>

                
<div id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<div class="nx-post-border">
        
        <div class="team-thumbnail">
            <?php

               	if( has_post_thumbnail() && ! post_password_required() )
                {
					echo "<img src=\"".$thumb_resized['url']."\" class=\"post-th-image\" alt=\"\" >";
                }   
            ?>

        </div>

		<div class="nx-post-content">
        	<div class="team-content-wrap">
                <h4 class="entry-title">
                    <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                </h4>
            </div>
		</div><!-- .nx-post-content -->
        
	</div><!-- .nx-post-border -->
    
</div><!-- #post -->
