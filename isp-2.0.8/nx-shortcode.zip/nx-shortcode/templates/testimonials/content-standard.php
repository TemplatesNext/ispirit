<div id="post-<?php the_ID(); ?>" class="nx-testimonials">
    <div class="testi-content">
    	<span class="nx-qtt-start"><i class="fa fa-quote-left"></i></span>
        <?php
            $exc_length = 60;
            echo nx_custom_excerpt($exc_length);
        ?>
        <span class="nx-qtt-end"><i class="fa fa-quote-right"></i></span>
    </div>
</div><!-- #post -->