<div class="nx-posts nx-posts-single-post">
	<?php
		// Prepare marker to show only one post
		$first = true;
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;

				// Show oly first post
				if ( $first ) {
					$first = false;
					?>
					<div id="nx-post-<?php the_ID(); ?>" class="nx-post">
						<h1 class="nx-post-title"><?php the_title(); ?></h1>
						<div class="nx-post-meta"><?php _e( 'Posted', 'nx' ); ?>: <?php the_time( get_option( 'date_format' ) ); ?> | <a href="<?php comments_link(); ?>" class="nx-post-comments-link"><?php comments_number( __( '0 comments', 'nx' ), __( '1 comment', 'nx' ), __( '%n comments', 'nx' ) ); ?></a></div>
						<div class="nx-post-content">
							<?php the_content(); ?>
						</div>
					</div>
					<?php
				}
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_attr__( 'Posts not found', 'nx' ) . '</h4>';
		}
	?>
</div>