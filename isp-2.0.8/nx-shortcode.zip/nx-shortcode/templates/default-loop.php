<div class="nx-posts nx-posts-default-loop">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>

				<div id="nx-post-<?php the_ID(); ?>" class="nx-post">
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="nx-post-thumbnail" href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					<?php endif; ?>
					<h2 class="nx-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<div class="nx-post-meta"><?php _e( 'Posted', 'nx' ); ?>: <?php the_time( get_option( 'date_format' ) ); ?></div>
					<div class="nx-post-excerpt">
						<?php the_excerpt(); ?>
					</div>
					<a href="<?php comments_link(); ?>" class="nx-post-comments-link"><?php comments_number( __( '0 comments', 'nx' ), __( '1 comment', 'nx' ), __( '%n comments', 'nx' ) ); ?></a>
				</div>

				<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_attr__( 'Posts not found', 'nx' ) . '</h4>';
		}
	?>
</div>