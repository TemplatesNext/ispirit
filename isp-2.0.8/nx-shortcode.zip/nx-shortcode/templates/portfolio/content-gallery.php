<?php 
	$classes[] = 'nx-col-1-' . $atts['columns'];
	
	$post_thumb_list = "";
	$thumb_full_url = "";
	$thumb_post_url = 1;
	$pop_height = 700;
	$pop_width = 1200;
	$image_placeholder = get_template_directory_uri() . '/images/placeholder-1200x1200.png';
	
	if( $atts['columns'] == 1 )
	{
		$th_width = 1200;
		$th_height = 800;		
	} else if( $atts['columns'] == 2 )
	{
		$th_width = 600;
		$th_height = 600;			
	} else if( $atts['columns'] == 3 )
	{
		$th_width = 600;
		$th_height = 600;			
	} else if( $atts['columns'] == 4 )
	{
		$th_width = 600;
		$th_height = 600;		
	}

	                
	if( has_post_thumbnail() )
	{
		$thumb_image_id = get_post_thumbnail_id();
		$thumb_img_url = wp_get_attachment_url( $thumb_image_id,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
		$thumb_resized = nx_image_resize( $thumb_img_url, $th_width, $th_height, true, true ); //resize & crop the image		
		$thumb_full_url = $thumb_img_url;
	}
						
?>
<div id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<div class="nx-post-border">
        
        <div class="entry-thumbnail">
            	<?php
					if( has_post_thumbnail() && ! post_password_required() )
                    {
							echo "<img src=\"".$thumb_resized['url']."\" class=\"post-th-image\" alt=\"\" >";
							$thumb_full_url = $thumb_img_url;
                    }
                ?>
        </div>

		<div class="nx-post-content">
        	<div class="folioico">
				<?php if ( $thumb_full_url != "" ) : ?>
            	<a href="<?php echo nx_image_resize( $thumb_full_url, $pop_width, $pop_height, true, true ); ?>" class="nx-popup-link" title="<?php the_title(); ?>">
                	<i class="fa fa-search-plus"></i>
                </a>
                <?php endif; ?>
                <a href="<?php the_permalink(); ?>"><i class="fa fa-link"></i></a>
                
            </div>
        	<div class="folio-content-wrap">
                <h1 class="entry-title">
                    <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                </h1>
                <?php
                    echo "<div class=\"foliocat\">" . ( nx_folio_term( $atts['taxonomy'] ) ) . "</div>";
                ?>                
                <?php if( $atts['layout']==2 ): ?>
                    <div class="entry-summary">
                        <?php
                            $exc_length = 20;
                            echo nx_custom_excerpt($exc_length);
                        ?>
                    </div><!-- .entry-summary -->
                <?php endif; ?>
                

            </div>

		</div><!-- .nx-post-content -->
	</div><!-- .nx-post-border -->
</div><!-- #post -->
