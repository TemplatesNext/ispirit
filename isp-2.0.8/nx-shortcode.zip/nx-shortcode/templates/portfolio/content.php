<?php $classes[] = 'nx-shortcodes-post-box'; ?>
<div id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<div class="nx-shortcodes-post-border">
		<?php if ( $atts['thumbnail'] && has_post_thumbnail() && ! post_password_required() ) : ?>
			<div class="nx-shortcodes-entry-thumbnail">
				<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $atts['size'] ); ?></a>
			</div>
		<?php endif; ?>

		<div class="nx-shortcodes-post-content">
			<?php if ( $atts['title'] ) : ?>
			<div class="nx-shortcodes-entry-header">
				<<?php echo $atts['heading_type']; ?> class="nx-shortcodes-entry-title">
					<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
				</<?php echo $atts['heading_type']; ?>>
			</div><!-- .entry-header -->
			<?php endif; ?>

			<?php if ( $atts['content'] ) : ?>
			<div class="nx-shortcodes-entry-summary">
				<?php the_content(); ?> 
			</div><!-- .entry-summary -->
			<?php endif; ?>

			<?php include('entry-meta.php'); ?>

		</div>
	</div><!-- .nx-post-border -->
</div><!-- #post -->
