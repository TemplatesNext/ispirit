<?php 

$classes[] = 'nx-post-box'; 


	global  $ispirit_data;
	
	$thumb_full_url = "";
	$thumb_class = "nx-entry-thumb";
	
	$archive_layout_type = $atts['blog_layout'];
	$hide_categories = $atts['meta_cat'];
		
	if( $atts['blog_layout'] == '1' ) {
		$total_column = 1;
	} else {
		$total_column = $atts["columns"];
	}
		
	$post_thumb_list = "";

	$th_width = 1200;
	$th_height = 600;
		
	if( $total_column == 1 )
	{
		$th_width = 1200;
		$th_height = 600;		
	} else if( $total_column == 2 )
	{
		$th_width = 600;
		$th_height = 360;			
	} else if( $total_column == 3 )
	{
		$th_width = 400;
		$th_height = 240;			
	} else if( $total_column == 4 )
	{
		$th_width = 300;
		$th_height = 180;		
	}
	
	if( has_post_thumbnail() )
	{
		$thumb_image_id = get_post_thumbnail_id();
		$thumb_img_url = wp_get_attachment_url( $thumb_image_id,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
		$thumb_resized = nx_image_resize( $thumb_img_url, $th_width, $th_height, true, true );
		$thumb_full_url = $thumb_img_url;
	}
	
	if( ! has_post_thumbnail() && $post_thumb_type == 0  )
	{
		$thumb_class = "no-entry-thumb";
	}
	

	//echo "<h3>".$hide_categories."</h3>";
?>

<div id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<div class="nx-post-border">
    	<header class="entry-header">
            <div class="nx-entry-thumbnail <?php echo $thumb_class; ?>">
                <?php
                        if( has_post_thumbnail() && ! post_password_required() )
                        {
                            echo "<img src=\"".$thumb_resized['url']."\" class=\"post-th-image\" alt=\"\" >";
                            $thumb_full_url = $thumb_img_url;
                        }
        
                ?>
                <?php if( $thumb_full_url != "" ) {?>    
                    <div class="nx-blog-overlay"></div>
                    <div class="nx-blog-icons">
                        <a href="<?php echo $thumb_full_url; ?>" class="mag-pop-img"><i class="fa fa-search-plus"></i></a>
                        <a href="<?php the_permalink(); ?>"><i class="fa fa-link"></i></a>
                    </div>
                <?php } ?>
            </div>
			<?php if ( $atts['title'] ) : ?>
				<h1 class="nx-entry-title">
					<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
				</h1>
			<?php endif; ?>
			<?php
				if ( is_sticky() && is_home() && ! is_paged() )
				{
					echo '<span class="nx-featured-post"><span class="genericon genericon-pinned"></span><span class="nx-sticky">' . __( 'Sticky', 'nx' ) . '</span></span>';
				}			
            ?>
                     
		</header>
        
		<div class="nx-post-content">
			<?php if ( $atts['content'] ) : ?>
			<div class="nx-entry-summary">
                <?php
					$exc_length = 32;
					echo nx_custom_excerpt($exc_length);            
				?>
			</div><!-- .entry-summary -->
			<?php endif; ?>

			<?php include('entry-meta.php'); ?>

		</div>
	</div><!-- .nx-post-border -->
</div><!-- #post -->
