<?php
	
	/*
	*
	*	NX Testimonials For Page Builder 
	*	------------------------------------------------
	*	TemplatesNext
	* 	Copyright TemplatesNext 2014 - http://www.TemplatesNext.org
	*/
	
	/*
	*	Plugin Name: NX Testimonials For Page Builder Widget
	*	Plugin URI: http://www.TemplatesNext.org
	*	Description: NX testimonials Widget For Page Builder
	*	Author: templatesNext
	*	Version: 1.0
	*	Author URI: http://www.TemplatesNext.org
	*/		

	class nx_testimonials_widget extends WP_Widget {
		
		//function nx_testimonials_widget() {
		function __construct() {	
			$widget_ops = array( 
			'classname' => 'widget-nx-testimonials', 
			'description' => 'Testimonials widget for pagebuilder',
			'panels_icon' => 'dashicons dashicons-screenoptions',
			'panels_groups' => array('nx')			
		);
        	parent::__construct( 'widget-nx-testimonials', 'NX Testimonials ( for PB )', $widget_ops );				
		}
	
		function form($instance) {
		$defaults = array( 
			'style' => 'default',
			'delay' => 8000,
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
	
	?>
	<div class="nx-widget-content">		
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Testimonials Style', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'style' ); ?>" name="<?php echo $this->get_field_name( 'style' ); ?>" value="<?php echo $instance['style']; ?>" class="nx-widselect nx-pb-input">
              <option value="default"><?php _e('Default', 'nx-admin');?></option>
              <option value="centererd"><?php _e('Center Aligned', 'nx-admin');?></option>
              <option value="centererd-compact"><?php _e('Centered Compact', 'nx-admin');?></option>                            
            </select>            
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Delay', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'delay' ); ?>" name="<?php echo $this->get_field_name( 'delay' ); ?>" value="<?php echo $instance['delay']; ?>" class="nx-widenumber nx-pb-input" type="number" min="1000" max="20000" step="500" />
		</p>         
	</div>		
	<?php	
		}
	
		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance['style'] = strip_tags( $new_instance['style'] );
			$instance['delay'] = strip_tags( $new_instance['delay'] );			
			return $instance;
		}
		
		function widget($args, $instance) {
			
			extract( $args );
	
			$style = $instance['style'];
			$delay = $instance['delay'];			
	
			$output = '';
			
			$output .= '<div>[nx_testimonials style="'.$style.'" delay="'.$delay.'"]</div>';
			
			echo $output;
	
		}
			
	}
	
	add_action( 'widgets_init', 'nx_load_testimonials_widget' );
	
	function nx_load_testimonials_widget() {
		register_widget('nx_testimonials_widget');
	}