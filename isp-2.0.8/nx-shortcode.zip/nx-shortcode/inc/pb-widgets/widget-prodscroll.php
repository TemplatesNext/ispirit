<?php
	/*
	Widget Name: NX Products For Page Builder
	Description: NX WooCommerce Products Scroll Widget For Page Builder.
	Author: templatesNext
	Author URI:Author URI: http://www.TemplatesNext.org
	*/	

	class nx_prodscroll_widget extends WP_Widget {
		
		//function nx_prodscroll_widget() {
		function __construct() {	
			$widget_ops = array( 
				'classname' => 'widget-nx-prodscroll', 
				'description' => 'Product Carousel widget for pagebuilder',
				'panels_icon' => 'dashicons dashicons-screenoptions',
				'panels_groups' => array('nx')				
			);
        	parent::__construct( 'widget-nx-prodscroll', 'NX WooCommerce Products Carousel ( for PB )', $widget_ops );				
		}
	
		function form($instance) {
		$defaults = array( 
			'product_listing_type' => 'recent_products', 
			'number' => '8', 
			'columns' => '4', 
			'prod_ids' => ''
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		
		//[nx_products_carusel prod_ids="21,32,54" product_listing_type="sale_products" columns="3" number="6"]
	?>
	<div class="nx-widget-content">		
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Portfolio Style', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'product_listing_type' ); ?>" name="<?php echo $this->get_field_name( 'product_listing_type' ); ?>" value="<?php echo $instance['product_listing_type']; ?>" class="nx-widselect nx-pb-input">
            
                <option value="recent_products"><?php _e('Recent Products', 'nx-admin');?></option>	
                <option value="product_categories"><?php _e('Product Categories', 'nx-admin');?></option>					
                <option value="featured_products"><?php _e('Featured Products', 'nx-admin');?></option>					
                <option value="sale_products"><?php _e('Products On Sale', 'nx-admin');?></option>					
                <option value="best_selling_products"><?php _e('Best Selling Products', 'nx-admin');?></option>					
                <option value="top_rated_products"><?php _e('Top Rated Products', 'nx-admin');?></option>					
                <option value="products"><?php _e('Products By Ids', 'nx-admin');?></option>
                  
            </select>            
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Number Of Items', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" class="nx-widenumber nx-pb-input nxPrevi" type="text" />
            <input type="range" min="1" max="16" step="1" value="8" class="nxRange nx-range-slider">            
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Number Of Columns', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'columns' ); ?>" name="<?php echo $this->get_field_name( 'columns' ); ?>" value="<?php echo $instance['columns']; ?>" class="nx-widerange nx-pb-input nxPrevi" type="text" />
            <input type="range" min="1" max="6" step="1" value="4" class="nxRange nx-range-slider">         
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Category/Product Ids (optional)', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'prod_ids' ); ?>" name="<?php echo $this->get_field_name( 'prod_ids' ); ?>" value="<?php echo $instance['prod_ids']; ?>" class="nx-widselect nx-pb-input" type="text" />
            <br /><span class="small"><?php _e('Comma separeted category or product ids (works with "Product Categories" and "Products By Ids")', 'nx-admin');?></span>
		</p> 
	</div>
	<script>
        	
		jQuery(document).ready(function($) {
			$( "input.nxRange" ).each(function( index ) {
					
				var nxRange = $(this);
				var nxPrevi = $(this).prev( ".nxPrevi" );
					
				nxRange.bind("input", function() {
					var newRange = nxRange.val(); 
					nxPrevi.val(newRange);
				});				
			});					
		});

    </script>     	
	<?php	
		}
	
		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance['product_listing_type'] = strip_tags( $new_instance['product_listing_type'] );
			$instance['number'] = strip_tags( $new_instance['number'] );
			$instance['columns'] = strip_tags( $new_instance['columns'] );
			$instance['prod_ids'] = strip_tags( $new_instance['prod_ids'] );
			return $instance;
		}
		
		function widget($args, $instance) {
			
			extract( $args );
	
			$product_listing_type = $instance['product_listing_type'];
			$number = $instance['number'];
			$columns = $instance['columns'];
			$prod_ids = $instance['prod_ids'];
	
			$output = '';
			
			$output .= '<div>[nx_products_carusel product_listing_type="'.$product_listing_type.'" number="'.$number.'" columns="'.$columns.'" prod_ids="'.$prod_ids.'"]</div>';
			
			echo $output;
	
		}
			
	}
	
	add_action( 'widgets_init', 'nx_load_prodscroll_widget' );
	
	function nx_load_prodscroll_widget() {
		register_widget('nx_prodscroll_widget');
	}
