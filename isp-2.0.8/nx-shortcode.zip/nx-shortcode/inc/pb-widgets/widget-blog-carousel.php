<?php
	/*
	Widget Name: NX Blog Carousel For Page Builder
	Description: NX Blog Carousel Widget For Page Builder.
	Author: templatesNext
	Author URI:Author URI: http://www.TemplatesNext.org
	*/	

	class nx_blogcarousel_widget extends WP_Widget {
		
		//function nx_blogcarousel_widget() {
		function __construct() {	
			$widget_ops = array( 
				'classname' => 'widget-nx-blogcarousel', 
				'description' => 'Blog Carousel widget for Page Builder', 
				'panels_icon' => 'dashicons dashicons-screenoptions',
				'panels_groups' => array('nx')
			);
        	parent::__construct( 'widget-nx-blogcarousel', 'NX Blog Carousel ( for PB )', $widget_ops );				
		}
	
		function form($instance) {
		$defaults = array( 
			'posts_per_page' => '8',
			'blog_car_layout' => 2,
			'columns' => 4, 
			'meta_cat' => 'no', 
			'read_more' => 'no', 			
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
	?>

	<div class="nx-widget-content">
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Number Of Items', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'posts_per_page' ); ?>" name="<?php echo $this->get_field_name( 'posts_per_page' ); ?>" value="<?php echo $instance['posts_per_page']; ?>" class="nx-widenumber nx-pb-input" type="number" min="1" max="16" step="1" />
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Number Of Columns', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'columns' ); ?>" name="<?php echo $this->get_field_name( 'columns' ); ?>" value="<?php echo $instance['columns']; ?>" class="nx-widerange nx-pb-input" type="number" min="1" max="4" step="1" />
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Layout Type', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'blog_car_layout' ); ?>" name="<?php echo $this->get_field_name( 'blog_car_layout' ); ?>" value="<?php echo $instance['blog_car_layout']; ?>" class="nx-widselect nx-pb-input">
              <option value="1"><?php _e('Standard', 'nx-admin');?></option>
              <option value="2"><?php _e('Masonry', 'nx-admin');?></option>
            </select>       
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Show/Hide Category', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'meta_cat' ); ?>" name="<?php echo $this->get_field_name( 'meta_cat' ); ?>" value="<?php echo $instance['meta_cat']; ?>" class="nx-widselect nx-pb-input">
              <option value="yes"><?php _e('Show', 'nx-admin');?></option>
              <option value="no"><?php _e('Hide', 'nx-admin');?></option>
            </select>            
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Show "Read More"', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" value="<?php echo $instance['read_more']; ?>" class="nx-widselect nx-pb-input">
              <option value="yes"><?php _e('Show', 'nx-admin');?></option>
              <option value="no"><?php _e('Hide', 'nx-admin');?></option>
            </select>            
		</p>         
                                            
	</div>
	<?php	
		}

		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance['blog_car_layout'] = strip_tags( $new_instance['blog_car_layout'] );
			$instance['posts_per_page'] = strip_tags( $new_instance['posts_per_page'] );
			$instance['columns'] = strip_tags( $new_instance['columns'] );
			$instance['meta_cat'] = strip_tags( $new_instance['meta_cat'] );
			$instance['read_more'] = strip_tags( $new_instance['read_more'] );
			$instance['paging'] = strip_tags( $new_instance['paging'] );	
			$instance['pagnav_align'] = strip_tags( $new_instance['pagnav_align'] );																		
			return $instance;
		}
		
		function widget($args, $instance) {
			
			extract( $args );
	
			$blog_car_layout = $instance['blog_car_layout'];
			$posts_per_page = $instance['posts_per_page'];
			$columns = $instance['columns'];
			$meta_cat = $instance['meta_cat'];
			$read_more = $instance['read_more'];
	
	
			$output = '';
			
			$output .= '<div>[nx_blogcarousel blog_car_layout="'.$blog_car_layout.'" posts_per_page="'.$posts_per_page.'" columns="'.$columns.'" meta_cat="'.$meta_cat.'" read_more="'.$read_more.'"]</div>';
			
			echo $output;
	
		}
			
	}
	
	add_action( 'widgets_init', 'nx_load_blogcarousel_widget' );
	
	function nx_load_blogcarousel_widget() {
		register_widget('nx_blogcarousel_widget');
	}

