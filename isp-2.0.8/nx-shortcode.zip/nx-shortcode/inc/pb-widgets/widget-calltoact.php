<?php
	/*
	Widget Name: NX Call To Act For Page Builder
	Description: NX Call To Act Widget For Page Builder.
	Author: templatesNext
	Author URI:Author URI: http://www.TemplatesNext.org
	*/	

	class nx_calltoact_widget extends WP_Widget {
		
		function __construct() {	
			$widget_ops = array( 
				'classname' => 'widget-nx-calltoact', 
				'description' => 'Call To Act widget for Page Builder', 
				'panels_icon' => 'dashicons dashicons-screenoptions',
				'panels_groups' => array('nx')
			);
        	parent::__construct( 'widget-nx-calltoact', 'NX Call To Act ( for PB )', $widget_ops );				
		}
	
		function form($instance) {
		$defaults = array( 
			'fullwidth' => 'no', 
			'cta_bgcolor' => '#dd9933', 
			'cta_textcolor' => 'light',
			'cta_button_text' => 'Know More...',
			'cta_button_url' => 'http://www.google.com/',			
			'class' => '',			
			'content' => 'Call To Act content...', 
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		
		//[nx_calltoact fullwidth="no" cta_bgcolor="#ffec60" cta_textcolor="dark" cta_button_text="Know More..." cta_button_url="https://www.google.com/" class="nxnewwindow"]Call to act text[/nx_calltoact]
	
	?>

	<div class="nx-widget-content">
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Full Width', 'nx-admin');?>:</label>

            <select id="<?php echo $this->get_field_id( 'fullwidth' ); ?>" name="<?php echo $this->get_field_name( 'fullwidth' ); ?>" value="<?php echo $instance['fullwidth']; ?>" class="nx-widselect nx-pb-input">
                <option value="no"><?php _e('No', 'nx-admin');?></option>					
                <option value="yes"><?php _e('Yes', 'nx-admin');?></option>					
            </select>            
		</p>    
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Background Color', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'cta_bgcolor' ); ?>" name="<?php echo $this->get_field_name( 'cta_bgcolor' ); ?>" value="<?php echo $instance['cta_bgcolor']; ?>" class="nx-widenumber nx-pb-input tx-color" type="text" />
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Text Color', 'nx-admin');?>:</label>
            <select id="<?php echo $this->get_field_id( 'cta_textcolor' ); ?>" name="<?php echo $this->get_field_name( 'cta_textcolor' ); ?>" value="<?php echo $instance['cta_textcolor']; ?>" class="nx-widselect nx-pb-input">
                <option value="light"><?php _e('Light', 'nx-admin');?></option>					
                <option value="dark"><?php _e('Dark', 'nx-admin');?></option>					
            </select>            
		</p>   
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Button Text', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'cta_button_text' ); ?>" name="<?php echo $this->get_field_name( 'cta_button_text' ); ?>" value="<?php echo $instance['cta_button_text']; ?>" class="nx-widenumber nx-pb-input" type="text" />            
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Button URL', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'cta_button_url' ); ?>" name="<?php echo $this->get_field_name( 'cta_button_url' ); ?>" value="<?php echo $instance['cta_button_url']; ?>" class="nx-widenumber nx-pb-input" type="url" />            
		</p>        
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Class', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'class' ); ?>" name="<?php echo $this->get_field_name( 'class' ); ?>" value="<?php echo $instance['class']; ?>" class="nx-widenumber nx-pb-input" type="text" />
		</p>                        
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Call To Act Content', 'nx-admin');?>:</label>

            <textarea id="<?php echo $this->get_field_id( 'content' ); ?>" name="<?php echo $this->get_field_name( 'content' ); ?>" value="<?php echo $instance['content']; ?>" class="nx-widselect nx-pb-input"><?php echo $instance['content']; ?></textarea>
		</p> 
	</div>
		<script>
        	
		jQuery(document).ready(function($) {
			$('.tx-color').wpColorPicker();
		});

			
        </script>
    
	<?php	
		}
	
		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance['fullwidth'] = strip_tags( $new_instance['fullwidth'] );
			$instance['cta_bgcolor'] = strip_tags( $new_instance['cta_bgcolor'] );			
			$instance['cta_textcolor'] = strip_tags( $new_instance['cta_textcolor'] );
			$instance['cta_button_text'] = strip_tags( $new_instance['cta_button_text'] );
			$instance['cta_button_url'] = strip_tags( $new_instance['cta_button_url'] );			
			$instance['class'] = strip_tags( $new_instance['class'] );
												
			$instance['content'] = strip_tags( $new_instance['content'] );
																		
			return $instance;
		}
		
		function widget($args, $instance) {
			
			extract( $args );
	
			$fullwidth = $instance['fullwidth'];
			$cta_bgcolor = $instance['cta_bgcolor'];
			$icon_colo = $instance['cta_textcolor'];
			$cta_button_text = $instance['cta_button_text'];
			$cta_button_url = $instance['cta_button_url'];			
			$class = $instance['class'];
									
			$content = $instance['content'];
	
			$output = '';
			
			$output .= '<div>[nx_calltoact fullwidth="'.$fullwidth.'" cta_bgcolor="'.$cta_bgcolor.'" cta_textcolor="'.$icon_colo.'" cta_button_text="'.$cta_button_text.'" cta_button_url="'.$cta_button_url.'" class="'.$class.'"]'.$content.'[/nx_calltoact]</div>';
			
			echo $output;
	
		}
			
	}
	
	add_action( 'widgets_init', 'nx_load_calltoact_widget' );
	
	function nx_load_calltoact_widget() {
		register_widget('nx_calltoact_widget');
	}

