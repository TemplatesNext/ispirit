<?php
	/*
	Widget Name: NX Pie Chart For Page Builder
	Description: NX Pie Chart Widget For Page Builder.
	Author: templatesNext
	Author URI:Author URI: http://www.TemplatesNext.org
	*/	

	class nx_piechart_widget extends WP_Widget {
		
		function __construct() {	
			$widget_ops = array( 
				'classname' => 'widget-nx-piechart', 
				'description' => 'Pie Chart widget for Page Builder', 
				'panels_icon' => 'dashicons dashicons-screenoptions',
				'panels_groups' => array('nx')
			);
        	parent::__construct( 'widget-nx-piechart', 'NX Pie Chart ( for PB )', $widget_ops );				
		}
	
		function form($instance) {
		$defaults = array( 
			'title' => 'Pie Chart Title', 
			'percent' => 64,
			'barcolor' => '#77bd32', 
			'trackcolor' => '#dd9933', 			
			'linewidth' => 6,
			'piesize' => 160,
			'class' => '',			
			'content' => 'Pie Chart content...', 
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		
		//[nx_piechart title="no" trackcolor="#ffec60" linewidth="dark" piesize="Know More..." cta_button_url="https://www.google.com/" class="nxnewwindow"]Call to act text[/nx_piechart]
	
	?>

	<div class="nx-widget-content">
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Pie Chart Title', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="nx-widenumber nx-pb-input" type="text" />          
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Percent', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'percent' ); ?>" name="<?php echo $this->get_field_name( 'percent' ); ?>" value="<?php echo $instance['percent']; ?>" class="nx-widenumber nx-pb-input"  type="number" min="1" max="100" step="1" />
		</p>           
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Bar Color', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'barcolor' ); ?>" name="<?php echo $this->get_field_name( 'barcolor' ); ?>" value="<?php echo $instance['barcolor']; ?>" class="nx-widenumber nx-pb-input tx-color" type="text" />
		</p> 
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Track Color', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'trackcolor' ); ?>" name="<?php echo $this->get_field_name( 'trackcolor' ); ?>" value="<?php echo $instance['trackcolor']; ?>" class="nx-widenumber nx-pb-input tx-color" type="text" />
		</p>         
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Line Width', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'linewidth' ); ?>" name="<?php echo $this->get_field_name( 'linewidth' ); ?>" value="<?php echo $instance['linewidth']; ?>" class="nx-widenumber nx-pb-input"  type="number" min="6" max="20" step="1" />            
		</p>   
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Pie Size', 'nx-admin');?>:</label>
			<input id="<?php echo $this->get_field_id( 'piesize' ); ?>" name="<?php echo $this->get_field_name( 'piesize' ); ?>" value="<?php echo $instance['piesize']; ?>" class="nx-widenumber nx-pb-input"  type="number" min="100" max="200" step="10" />
		</p>
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Class', 'nx-admin');?>:</label>
            <input id="<?php echo $this->get_field_id( 'class' ); ?>" name="<?php echo $this->get_field_name( 'class' ); ?>" value="<?php echo $instance['class']; ?>" class="nx-widenumber nx-pb-input" type="text" />
		</p>                        
		<p class="nx-pb-para">
			<label class="nx-pb-lebel"><?php _e('Pie Chart Content', 'nx-admin');?>:</label>

            <textarea id="<?php echo $this->get_field_id( 'content' ); ?>" name="<?php echo $this->get_field_name( 'content' ); ?>" value="<?php echo $instance['content']; ?>" class="nx-widselect nx-pb-input"><?php echo $instance['content']; ?></textarea>
		</p> 
	</div>
		<script>
        	
		jQuery(document).ready(function($) {
			$('.tx-color').wpColorPicker();
		});

			
        </script>
    
	<?php	
		}
	
		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance['title'] = strip_tags( $new_instance['title'] );
			$instance['percent'] = strip_tags( $new_instance['percent'] );			
			$instance['barcolor'] = strip_tags( $new_instance['barcolor'] );
			$instance['trackcolor'] = strip_tags( $new_instance['trackcolor'] );			
			$instance['linewidth'] = strip_tags( $new_instance['linewidth'] );
			$instance['piesize'] = strip_tags( $new_instance['piesize'] );
			$instance['class'] = strip_tags( $new_instance['class'] );
												
			$instance['content'] = strip_tags( $new_instance['content'] );
																		
			return $instance;
		}
		
		function widget($args, $instance) {
			
			extract( $args );
	
			$title = $instance['title'];
			$percent = $instance['percent'];
			$barcolor = $instance['barcolor'];
			$trackcolor = $instance['trackcolor'];			
			$linewidth = $instance['linewidth'];
			$piesize = $instance['piesize'];
			$class = $instance['class'];
									
			$content = $instance['content'];
	
			$output = '';
			
			$output .= '<div>[nx_piechart title="'.$title.'" percent="'.$percent.'" barcolor="'.$barcolor.'" trackcolor="'.$trackcolor.'" linewidth="'.$linewidth.'" piesize="'.$piesize.'" class="'.$class.'"]'.$content.'[/nx_piechart]</div>';
			
			echo $output;
	
		}
			
	}
	
	add_action( 'widgets_init', 'nx_load_piechart_widget' );
	
	function nx_load_piechart_widget() {
		register_widget('nx_piechart_widget');
	}

