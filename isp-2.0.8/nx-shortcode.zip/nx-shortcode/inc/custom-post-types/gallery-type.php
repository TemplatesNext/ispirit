<?php

/* ************************************************ */
/* Gallery Post Type Functions */
/* ************************************************ */


add_action('init', 'nx_galleries_register');  
  
function nx_galleries_register() {
		
    $labels = array(
        'name' => _x('Galleries', 'post type general name', "nx-admin"),
        'singular_name' => _x('Gallery', 'post type singular name', "nx-admin"),
        'add_new' => _x('Add New', 'gallery', "nx-admin"),
        'add_new_item' => __('Add New Gallery', "nx-admin"),
        'edit_item' => __('Edit Gallery', "nx-admin"),
        'new_item' => __('New Gallery', "nx-admin"),
        'view_item' => __('View Gallery', "nx-admin"),
        'search_items' => __('Search Galleries', "nx-admin"),
        'not_found' =>  __('No galleries have been added yet', "nx-admin"),
        'not_found_in_trash' => __('Nothing found in Trash', "nx-admin"),
        'parent_item_colon' => ''
    );
		
    $args = array(  
        'labels' => $labels,  
        'public' => true,  
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,
        'hierarchical' => false,
        'rewrite' => false,
        'supports' => array('title', 'thumbnail'),
        'has_archive' => true,
		'menu_icon' => 'dashicons-format-gallery',			
        'taxonomies' => array('gallery-category')
       );  
  
    register_post_type( 'galleries' , $args ); 
	
	 
}  

function nx_create_gallery_taxonomy() {
		
	$atts = array(
		"label" 						=> _x('Gallery Categories', 'category label', "nx-admin"), 
		"singular_label" 				=> _x('Gallery Category', 'category singular label', "nx-admin"), 
		'public'                        => true,
		'hierarchical'                  => true,
		'show_ui'                       => true,
		'show_in_nav_menus'             => false,
		'args'                          => array( 'orderby' => 'term_order' ),
		'rewrite' 						=> false,
		'query_var'                     => true
	);
	
	register_taxonomy( 'gallery-category', 'gallery', $atts );		
		
}
add_action( 'init', 'nx_create_gallery_taxonomy', 0 );

add_filter('manage_edit-galleries_columns', 'nx_galleries_edit_columns');   
  
function nx_galleries_edit_columns($columns){  
        $columns = array(  
            "cb" => "<input type=\"checkbox\" />", 
            "thumbnail" => "",
            "title" => __("Gallery", "nx-admin"),
            "gallery-category" => __("Categories", "nx-admin")  
        );  
  
        return $columns;  
}