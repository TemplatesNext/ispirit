<?php

/* ************************************************ */
/*	Clients Post Type Functions    */
/* ************************************************ */
	
	add_action('init', 'nx_clients_register');  
	  
	function nx_clients_register() {  
	
	    $labels = array(
	        'name' => _x('Clients', 'post type general name', "nx-admin"),
	        'singular_name' => _x('Client', 'post type singular name', "nx-admin"),
	        'add_new' => _x('Add New', 'Client', "nx-admin"),
	        'add_new_item' => __('Add New Client', "nx-admin"),
	        'edit_item' => __('Edit Client', "nx-admin"),
	        'new_item' => __('New Client', "nx-admin"),
	        'view_item' => __('View Client', "nx-admin"),
	        'search_items' => __('Search Clients', "nx-admin"),
	        'not_found' =>  __('No clients have been added yet', "nx-admin"),
	        'not_found_in_trash' => __('Nothing found in Trash', "nx-admin"),
	        'parent_item_colon' => ''
	    );
	
	    $args = array(  
	        'labels' => $labels,  
	        'public' => true,  
	        'show_ui' => true,
	        'show_in_menu' => true,
	        'show_in_nav_menus' => false,
	        'rewrite' => false,
	        'supports' => array('title', 'thumbnail'),
	        'has_archive' => true,
			'menu_icon' => 'dashicons-businessman',				
	        'taxonomies' => array('clients-category', 'post_tag')
	       );  
	  
	    register_post_type( 'clients' , $args );  

	} 
	
	function nx_create_clients_taxonomy() {
			
		$atts = array(
			"label" 						=> __('Client Categories', 'category label', "nx-admin"), 
			"singular_label" 				=> __('Client Category', 'category singular label', "nx-admin"), 
			'public'                        => true,
			'hierarchical'                  => true,
			'show_ui'                       => true,
			'show_in_nav_menus'             => false,
			'args'                          => array( 'orderby' => 'term_order' ),
			'rewrite'                       => false,
			'query_var'                     => true
		);
		
		register_taxonomy( 'clients-category', 'clients', $atts );	
			
	}
	add_action( 'init', 'nx_create_clients_taxonomy', 0 );
	
	
	add_filter('manage_edit-clients_columns', 'nx_clients_edit_columns');   
	  
	function nx_clients_edit_columns($columns){  
	        $columns = array(  
	            "cb" => "<input type=\"checkbox\" />",  
	            "thumbnail" => "",
	            "title" => __("Client", "nx-admin"),
	            "clients-category" => __("Categories", "nx-admin")  
	        );  
	  
	        return $columns;  
	}