<?php

/**
 * Class for managing plugin assets
 */
class Nx_Assets {

	/**
	 * Set of queried assets
	 *
	 * @var array
	 */
	static $assets = array( 'css' => array(), 'js' => array() );

	/**
	 * Constructor
	 */
	function __construct() {
		// Register
		add_action( 'wp_head',                     array( __CLASS__, 'register' ) );
		add_action( 'admin_head',                  array( __CLASS__, 'register' ) );
		add_action( 'nx/generator/preview/before', array( __CLASS__, 'register' ) );
		add_action( 'nx/examples/preview/before',  array( __CLASS__, 'register' ) );
		// Enqueue
		add_action( 'wp_footer',                   array( __CLASS__, 'enqueue' ) );
		add_action( 'admin_footer',                array( __CLASS__, 'enqueue' ) );
		// Print
		add_action( 'nx/generator/preview/after',  array( __CLASS__, 'prnt' ) );
		add_action( 'nx/examples/preview/after',   array( __CLASS__, 'prnt' ) );
		// Custom CSS
		add_action( 'wp_footer',                   array( __CLASS__, 'custom_css' ), 99 );
		add_action( 'nx/generator/preview/after',  array( __CLASS__, 'custom_css' ), 99 );
		add_action( 'nx/examples/preview/after',   array( __CLASS__, 'custom_css' ), 99 );
		// Custom TinyMCE CSS and JS
		// add_filter( 'mce_css',                     array( __CLASS__, 'mce_css' ) );
		// add_filter( 'mce_external_plugins',        array( __CLASS__, 'mce_js' ) );
	}

	/**
	 * Register assets
	 */
	public static function register() {
		// Chart.js
		wp_register_script( 'chartjs', plugins_url( 'assets/js/chart.js', NX_PLUGIN_FILE ), false, '0.2', true );
		// SimpleSlider
		wp_register_script( 'simpleslider', plugins_url( 'assets/js/simpleslider.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.0.0', true );
		wp_register_style( 'simpleslider', plugins_url( 'assets/css/simpleslider.css', NX_PLUGIN_FILE ), false, '1.0.0', 'all' );
		// Owl Carousel
		wp_register_script( 'owl-carousel', plugins_url( 'assets/js/owl-carousel.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.3.2', true );
		
		wp_register_style( 'owl-carousel', plugins_url( 'assets/css/owl-carousel.css', NX_PLUGIN_FILE ), false, '1.3.2', 'all' );
		wp_register_style( 'owl-carousel-transitions', plugins_url( 'assets/css/owl-carousel-transitions.css', NX_PLUGIN_FILE ), false, '1.3.2', 'all' );
		// Font Awesome
		wp_register_style( 'font-awesome', '//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css', false, '4.0.3', 'all' );
		// Animate.css
		wp_register_style( 'animate', plugins_url( 'assets/css/animate.css', NX_PLUGIN_FILE ), false, '1.0.0', 'all' );
		// InView
		wp_register_script( 'inview', plugins_url( 'assets/js/inview.js', NX_PLUGIN_FILE ), array( 'jquery' ), '2.1.1', true );
		// qTip
		wp_register_style( 'qtip', plugins_url( 'assets/css/qtip.css', NX_PLUGIN_FILE ), false, '2.1.1', 'all' );
		wp_register_script( 'qtip', plugins_url( 'assets/js/qtip.js', NX_PLUGIN_FILE ), array( 'jquery' ), '2.1.1', true );
		// jsRender
		wp_register_script( 'jsrender', plugins_url( 'assets/js/jsrender.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.0.0-beta', true );
		
		// jsRender
		wp_register_script( 'isotope', plugins_url( 'assets/js/isotope.pkgd.min.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.0.0-beta', true );
		// easypiechartr
		wp_register_script( 'easypiechart', plugins_url( 'assets/js/jquery.easypiechart.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.0.0-beta', true );
		// counterup
		wp_register_script( 'counterup', plugins_url( 'assets/js/jquery.counterup.min.js', NX_PLUGIN_FILE ), array( 'jquery' ), '1.0.0-beta', true );
							
		
		// Magnific Popup
		wp_register_style( 'magnific-popup', plugins_url( 'assets/css/magnific-popup.css', NX_PLUGIN_FILE ), false, '0.9.7', 'all' );
		wp_register_script( 'magnific-popup', plugins_url( 'assets/js/magnific-popup.js', NX_PLUGIN_FILE ), array( 'jquery' ), '0.9.7', true );
		wp_localize_script( 'magnific-popup', 'nx_magnific_popup', array(
				'close'   => __( 'Close (Esc)', 'nx' ),
				'loading' => __( 'Loading...', 'nx' ),
				'prev'    => __( 'Previous (Left arrow key)', 'nx' ),
				'next'    => __( 'Next (Right arrow key)', 'nx' ),
				'counter' => sprintf( __( '%s of %s', 'nx' ), '%curr%', '%total%' ),
				'error'   => sprintf( __( 'Failed to load this link. %sOpen link%s.', 'nx' ), '<a href="%url%" target="_blank"><u>', '</u></a>' )
			) );
		// Ace
		wp_register_script( 'ace', plugins_url( 'assets/js/ace/ace.js', NX_PLUGIN_FILE ), false, '1.1.01', true );
		// Swiper
		wp_register_script( 'swiper', plugins_url( 'assets/js/swiper.js', NX_PLUGIN_FILE ), array( 'jquery' ), NX_PLUGIN_VERSION, true );
		// jPlayer
		wp_register_script( 'jplayer', plugins_url( 'assets/js/jplayer.js', NX_PLUGIN_FILE ), array( 'jquery' ), NX_PLUGIN_VERSION, true );
		// Options page
		wp_register_style( 'nx-options-page', plugins_url( 'assets/css/options-page.css', NX_PLUGIN_FILE ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_script( 'nx-options-page', plugins_url( 'assets/js/options-page.js', NX_PLUGIN_FILE ), array( 'magnific-popup', 'jquery-ui-sortable', 'ace', 'jsrender' ), NX_PLUGIN_VERSION, true );
		wp_localize_script( 'nx-options-page', 'nx_options_page', array(
				'upload_title'  => __( 'Choose files', 'nx' ),
				'upload_insert' => __( 'Add selected files', 'nx' ),
				'not_clickable' => __( 'This button is not clickable', 'nx' )
			) );
		// Generator
		wp_register_style( 'nx-generator', plugins_url( 'assets/css/generator.css', NX_PLUGIN_FILE ), array( 'farbtastic', 'magnific-popup' ), NX_PLUGIN_VERSION, 'all' );
		wp_register_script( 'nx-generator', plugins_url( 'assets/js/generator.js', NX_PLUGIN_FILE ), array( 'farbtastic', 'magnific-popup', 'qtip' ), NX_PLUGIN_VERSION, true );
		wp_localize_script( 'nx-generator', 'nx_generator', array(
				'upload_title'         => __( 'Choose file', 'nx' ),
				'upload_insert'        => __( 'Insert', 'nx' ),
				'isp_media_title'      => __( 'Select images', 'nx' ),
				'isp_media_insert'     => __( 'Add selected images', 'nx' ),
				'presets_prompt_msg'   => __( 'Please enter a name for new preset', 'nx' ),
				'presets_prompt_value' => __( 'New preset', 'nx' ),
				'last_used'            => __( 'Last used settings', 'nx' )
			) );
		// Shortcodes stylesheets
		wp_register_style( 'nx-content-shortcodes', self::skin_url( 'content-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-box-shortcodes', self::skin_url( 'box-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-media-shortcodes', self::skin_url( 'media-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-other-shortcodes', self::skin_url( 'other-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-galleries-shortcodes', self::skin_url( 'galleries-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-players-shortcodes', self::skin_url( 'players-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );
		wp_register_style( 'nx-blog-shortcodes', self::skin_url( 'blog-shortcodes.css' ), false, NX_PLUGIN_VERSION, 'all' );		
		// Shortcodes scripts
		wp_register_script( 'nx-galleries-shortcodes', plugins_url( 'assets/js/galleries-shortcodes.js', NX_PLUGIN_FILE ), array( 'jquery', 'swiper' ), NX_PLUGIN_VERSION, true );
		wp_register_script( 'nx-players-shortcodes', plugins_url( 'assets/js/players-shortcodes.js', NX_PLUGIN_FILE ), array( 'jquery', 'jplayer' ), NX_PLUGIN_VERSION, true );
		wp_register_script( 'nx-other-shortcodes', plugins_url( 'assets/js/other-shortcodes.js', NX_PLUGIN_FILE ), array( 'jquery' ), NX_PLUGIN_VERSION, true );
		wp_localize_script( 'nx-other-shortcodes', 'nx_other_shortcodes', array( 'no_preview' => __( 'This shortcode doesn\'t work in live preview. Please insert it into editor and preview on the site.', 'nx' ) ) );
		// Hook to deregister assets or add custom
		do_action( 'nx/assets/register' );
	}

	/**
	 * Enqueue assets
	 */
	public static function enqueue() {
		// Get assets query and plugin object
		$assets = self::assets();
		// Enqueue stylesheets
		foreach ( $assets['css'] as $style ) wp_enqueue_style( $style );
		// Enqueue scripts
		foreach ( $assets['js'] as $script ) wp_enqueue_script( $script );
		// Hook to dequeue assets or add custom
		do_action( 'nx/assets/enqueue', $assets );
	}

	/**
	 * Print assets without enqueuing
	 */
	public static function prnt() {
		// Prepare assets set
		$assets = self::assets();
		// Enqueue stylesheets
		wp_print_styles( $assets['css'] );
		// Enqueue scripts
		wp_print_scripts( $assets['js'] );
		// Hook
		do_action( 'nx/assets/print', $assets );
	}

	/**
	 * Print custom CSS
	 */
	public static function custom_css() {
		// Get custom CSS and apply filters to it
		$custom_css = apply_filters( 'nx/assets/custom_css', str_replace( '&#039;', '\'', html_entity_decode( (string) get_option( 'nx_option_custom-css' ) ) ) );
		// Print CSS if exists
		if ( $custom_css ) echo "\n\n<!-- TemplatesNext Shortcode custom CSS - begin -->\n<style type='text/css'>\n" . stripslashes( str_replace( array( '%theme_url%', '%home_url%', '%plugin_url%' ), array( trailingslashit( get_stylesheet_directory_uri() ), trailingslashit( get_option( 'home' ) ), trailingslashit( plugins_url( '', NX_PLUGIN_FILE ) ) ), $custom_css ) ) . "\n</style>\n<!-- TemplatesNext Shortcode custom CSS - end -->\n\n";
	}

	/**
	 * Styles for visualised shortcodes
	 */
	public static function mce_css( $mce_css ) {
		if ( ! empty( $mce_css ) ) $mce_css .= ',';
		$mce_css .= plugins_url( 'assets/css/tinymce.css', NX_PLUGIN_FILE );
		return $mce_css;
	}

	/**
	 * TinyMCE plugin for visualised shortcodes
	 */
	public static function mce_js( $plugins ) {
		$plugins['nxshortcode'] = plugins_url( 'assets/js/tinymce.js', NX_PLUGIN_FILE );
		return $plugins;
	}

	/**
	 * Add asset to the query
	 */
	public static function add( $type, $handle ) {
		// Array with handles
		if ( is_array( $handle ) ) { foreach ( $handle as $h ) self::$assets[$type][$h] = $h; }
		// Single handle
		else self::$assets[$type][$handle] = $handle;
	}
	/**
	 * Get queried assets
	 */
	public static function assets() {
		// Get assets query
		$assets = self::$assets;
		// Apply filters to assets set
		$assets['css'] = array_unique( ( array ) apply_filters( 'nx/assets/css', ( array ) array_unique( $assets['css'] ) ) );
		$assets['js'] = array_unique( ( array ) apply_filters( 'nx/assets/js', ( array ) array_unique( $assets['js'] ) ) );
		// Return set
		return $assets;
	}

	/**
	 * Helper to get full URL of a skin file
	 */
	public static function skin_url( $file = '' ) {
		$shult = nx_shortcode();
		$skin = get_option( 'nx_option_skin' );
		$uploads = wp_upload_dir(); $uploads = $uploads['baseurl'];
		// Prepare url to skin directory
		$url = ( !$skin || $skin === 'default' ) ? plugins_url( 'assets/css/', NX_PLUGIN_FILE ) : $uploads . '/nx-shortcode-skins/' . $skin;
		return trailingslashit( apply_filters( 'nx/assets/skin', $url ) ) . $file;
	}
}

new Nx_Assets;

/**
 * Helper function to add asset to the query
 *
 * @param string  $type   Asset type (css|js)
 * @param mixed   $handle Asset handle or array with handles
 */
function nx_query_asset( $type, $handle ) {
	Nx_Assets::add( $type, $handle );
}

/**
 * Helper function to get current skin url
 *
 * @param string  $file Asset file name. Example value: box-shortcodes.css
 */
function nx_skin_url( $file ) {
	return Nx_Assets::skin_url( $file );
}
