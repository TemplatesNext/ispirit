<?php
/**
 * Shortcode Generator
 */
class Nx_Generator_Views {

	/**
	 * Constructor
	 */
	function __construct() {}

	public static function text( $id, $field ) {
		$field = wp_parse_args( $field, array(
			'default' => ''
		) );
		$return = '<input type="text" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" />';
		return $return;
	}

	public static function textarea( $id, $field ) {
		$field = wp_parse_args( $field, array(
			'rows'    => 3,
			'default' => ''
		) );
		$return = '<textarea name="' . $id . '" id="nx-generator-attr-' . $id . '" rows="' . $field['rows'] . '" class="nx-generator-attr">' . esc_textarea( $field['default'] ) . '</textarea>';
		return $return;
	}

	public static function select( $id, $field ) {
		// Multiple selects
		$multiple = ( isset( $field['multiple'] ) ) ? ' multiple' : '';
		$return = '<select name="' . $id . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr"' . $multiple . '>';
		// Create options
		foreach ( $field['values'] as $option_value => $option_title ) {
			// Is this option selected
			$selected = ( $field['default'] === $option_value ) ? ' selected="selected"' : '';
			// Create option
			$return .= '<option value="' . $option_value . '"' . $selected . '>' . $option_title . '</option>';
		}
		$return .= '</select>';
		return $return;
	}

	public static function bool( $id, $field ) {
		$return = '<span class="nx-generator-switch nx-generator-switch-' . $field['default'] . '"><span class="nx-generator-yes">' . __( 'Yes', 'nx' ) . '</span><span class="nx-generator-no">' . __( 'No', 'nx' ) . '</span></span><input type="hidden" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr nx-generator-switch-value" />';
		return $return;
	}

	public static function upload( $id, $field ) {
		$return = '<input type="text" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr nx-generator-upload-value" /><div class="nx-generator-field-actions"><a href="javascript:;" class="button nx-generator-upload-button"><img src="' . admin_url( '/images/media-button.png' ) . '" alt="' . __( 'Media manager', 'nx' ) . '" />' . __( 'Media manager', 'nx' ) . '</a></div>';
		return $return;
	}

	public static function icon( $id, $field ) {
		$return = '<input type="text" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr nx-generator-icon-picker-value" /><div class="nx-generator-field-actions"><a href="javascript:;" class="button nx-generator-upload-button nx-generator-field-action"><img src="' . admin_url( '/images/media-button.png' ) . '" alt="' . __( 'Media manager', 'nx' ) . '" />' . __( 'Media manager', 'nx' ) . '</a> <a href="javascript:;" class="button nx-generator-icon-picker-button nx-generator-field-action"><img src="' . admin_url( '/images/media-button-other.gif' ) . '" alt="' . __( 'Icon picker', 'nx' ) . '" />' . __( 'Icon picker', 'nx' ) . '</a></div><div class="nx-generator-icon-picker nx-generator-clearfix"><input type="text" class="widefat" placeholder="' . __( 'Filter icons', 'nx' ) . '" /></div>';
		return $return;
	}

	public static function color( $id, $field ) {
		$return = '<span class="nx-generator-select-color"><span class="nx-generator-select-color-wheel"></span><input type="text" name="' . $id . '" value="' . $field['default'] . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr nx-generator-select-color-value" /></span>';
		return $return;
	}

	public static function gallery( $id, $field ) {
		$shult = nx_shortcode();
		// Prepare galleries list
		$galleries = $shult->get_option( 'galleries' );
		$created = ( is_array( $galleries ) && count( $galleries ) ) ? true : false;
		$return = '<select name="' . $id . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" data-loading="' . __( 'Please wait', 'nx' ) . '">';
		// Check that galleries is set
		if ( $created ) // Create options
			foreach ( $galleries as $g_id => $gallery ) {
				// Is this option selected
				$selected = ( $g_id == 0 ) ? ' selected="selected"' : '';
				// Prepare title
				$gallery['name'] = ( $gallery['name'] == '' ) ? __( 'Untitled gallery', 'nx' ) : stripslashes( $gallery['name'] );
				// Create option
				$return .= '<option value="' . ( $g_id + 1 ) . '"' . $selected . '>' . $gallery['name'] . '</option>';
			}
		// Galleries not created
		else
			$return .= '<option value="0" selected>' . __( 'Galleries not found', 'nx' ) . '</option>';
		$return .= '</select><small class="description"><a href="' . $shult->admin_url . '#tab-3" target="_blank">' . __( 'Manage galleries', 'nx' ) . '</a>&nbsp;&nbsp;&nbsp;<a href="javascript:;" class="nx-generator-reload-galleries">' . __( 'Reload galleries', 'nx' ) . '</a></small>';
		return $return;
	}

	public static function number( $id, $field ) {
		$return = '<input type="number" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" min="' . $field['min'] . '" max="' . $field['max'] . '" step="' . $field['step'] . '" class="nx-generator-attr" />';
		return $return;
	}

	public static function slider( $id, $field ) {
		$return = '<div class="nx-generator-range-picker nx-generator-clearfix"><input type="number" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" min="' . $field['min'] . '" max="' . $field['max'] . '" step="' . $field['step'] . '" class="nx-generator-attr" /></div>';
		return $return;
	}

	public static function shadow( $id, $field ) {
		$defaults = ( $field['default'] === 'none' ) ? array ( '0', '0', '0', '#000000' ) : explode( ' ', str_replace( 'px', '', $field['default'] ) );
		$return = '<div class="nx-generator-shadow-picker"><span class="nx-generator-shadow-picker-field"><input type="number" min="-1000" max="1000" step="1" value="' . $defaults[0] . '" class="nx-generator-sp-hoff" /><small>' . __( 'Horizontal offset', 'nx' ) . ' (px)</small></span><span class="nx-generator-shadow-picker-field"><input type="number" min="-1000" max="1000" step="1" value="' . $defaults[1] . '" class="nx-generator-sp-voff" /><small>' . __( 'Vertical offset', 'nx' ) . ' (px)</small></span><span class="nx-generator-shadow-picker-field"><input type="number" min="-1000" max="1000" step="1" value="' . $defaults[2] . '" class="nx-generator-sp-blur" /><small>' . __( 'Blur', 'nx' ) . ' (px)</small></span><span class="nx-generator-shadow-picker-field nx-generator-shadow-picker-color"><span class="nx-generator-shadow-picker-color-wheel"></span><input type="text" value="' . $defaults[3] . '" class="nx-generator-shadow-picker-color-value" /><small>' . __( 'Color', 'nx' ) . '</small></span><input type="hidden" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" /></div>';
		return $return;
	}

	public static function border( $id, $field ) {
		$defaults = ( $field['default'] === 'none' ) ? array ( '0', 'solid', '#000000' ) : explode( ' ', str_replace( 'px', '', $field['default'] ) );
		$borders = Nx_Tools::select( array(
				'options' => Nx_Data::borders(),
				'class' => 'nx-generator-bp-style',
				'selected' => $defaults[1]
			) );
		$return = '<div class="nx-generator-border-picker"><span class="nx-generator-border-picker-field"><input type="number" min="-1000" max="1000" step="1" value="' . $defaults[0] . '" class="nx-generator-bp-width" /><small>' . __( 'Border width', 'nx' ) . ' (px)</small></span><span class="nx-generator-border-picker-field">' . $borders . '<small>' . __( 'Border style', 'nx' ) . '</small></span><span class="nx-generator-border-picker-field nx-generator-border-picker-color"><span class="nx-generator-border-picker-color-wheel"></span><input type="text" value="' . $defaults[2] . '" class="nx-generator-border-picker-color-value" /><small>' . __( 'Border color', 'nx' ) . '</small></span><input type="hidden" name="' . $id . '" value="' . esc_attr( $field['default'] ) . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" /></div>';
		return $return;
	}

	public static function image_source( $id, $field ) {
		$field = wp_parse_args( $field, array(
				'default' => 'none'
			) );
		$sources = Nx_Tools::select( array(
				'options'  => array(
					'media'         => __( 'Media library', 'nx' ),
					'posts: recent' => __( 'Recent posts', 'nx' ),
					'category'      => __( 'Category', 'nx' ),
					'taxonomy'      => __( 'Taxonomy', 'nx' )
				),
				'selected' => '0',
				'none'     => __( 'Select images source', 'nx' ) . '&hellip;',
				'class'    => 'nx-generator-isp-sources'
			) );
		$categories = Nx_Tools::select( array(
				'options'  => Nx_Tools::get_terms( 'category' ),
				'multiple' => true,
				'size'     => 10,
				'class'    => 'nx-generator-isp-categories'
			) );
		$taxonomies = Nx_Tools::select( array(
				'options'  => Nx_Tools::get_taxonomies(),
				'none'     => __( 'Select taxonomy', 'nx' ) . '&hellip;',
				'selected' => '0',
				'class'    => 'nx-generator-isp-taxonomies'
			) );
		$terms = Nx_Tools::select( array(
				'class'    => 'nx-generator-isp-terms',
				'multiple' => true,
				'size'     => 10,
				'disabled' => true,
				'style'    => 'display:none'
			) );
		$return = '<div class="nx-generator-isp">' . $sources . '<div class="nx-generator-isp-source nx-generator-isp-source-media"><div class="nx-generator-clearfix"><a href="javascript:;" class="button button-primary nx-generator-isp-add-media"><i class="fa fa-plus"></i>&nbsp;&nbsp;' . __( 'Add images', 'nx' ) . '</a></div><div class="nx-generator-isp-images nx-generator-clearfix"><em class="description">' . __( 'Click the button above and select images.<br>You can select multimple images with Ctrl (Cmd) key', 'nx' ) . '</em></div></div><div class="nx-generator-isp-source nx-generator-isp-source-category"><em class="description">' . __( 'Select categories to retrieve posts from.<br>You can select multiple categories with Ctrl (Cmd) key', 'nx' ) . '</em>' . $categories . '</div><div class="nx-generator-isp-source nx-generator-isp-source-taxonomy"><em class="description">' . __( 'Select taxonomy and it\'s terms.<br>You can select multiple terms with Ctrl (Cmd) key', 'nx' ) . '</em>' . $taxonomies . $terms . '</div><input type="hidden" name="' . $id . '" value="' . $field['default'] . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" /></div>';
		return $return;
	}

	public static function image_media( $id, $field ) {
		$field = wp_parse_args( $field, array(
				'default' => 'none'
			) );
		$return = '<div class="nx-generator-isp"><input type="hidden" class="nx-generator-isp-sources" value="media" /><div class="nx-generator-isp-source nx-generator-isp-source-media nx-generator-isp-source-open"><div class="nx-generator-clearfix"><a href="javascript:;" class="button button-primary nx-generator-isp-add-media"><i class="fa fa-plus"></i>&nbsp;&nbsp;' . __( 'Add images', 'nx' ) . '</a></div><div class="nx-generator-isp-images nx-generator-clearfix"><em class="description">' . __( 'Click the button above and select images.<br>You can select multimple images with Ctrl (Cmd) key', 'nx' ) . '</em></div></div><input type="hidden" name="' . $id . '" value="' . $field['default'] . '" id="nx-generator-attr-' . $id . '" class="nx-generator-attr" /></div>';
		return $return;
	}
	



}
