<?php

class Nx_Counter_Examples {

	static $option = 'nx_counter_examples';

	function __construct() {

	}
}

// new Nx_Counter_Examples;

class Nx_Counter_Extra_Addon {

	static $option = 'nx_counter_extra_addon';

	function __construct() {
		add_filter( 'nx/menu/shortcodes',  array( __CLASS__, 'display' ) );
		add_filter( 'nx/menu/addons',      array( __CLASS__, 'display' ) );
		add_action( 'sunrise/page/before', array( __CLASS__, 'disable' ) );
	}

	public static function display( $title ) {
		if ( get_option( self::$option ) ) return $title;
		return sprintf(
			'%s <span class="update-plugins count-1" title="%s"><span class="update-count">%s</span></span>',
			$title,
			__( '1 new add-on for TemplatesNext Shortcode', 'nx' ),
			'1'
		);
	}

	public static function disable() {
		if ( $_GET['page'] === 'nx-shortcode-addons' ) update_option( self::$option, true );
	}
}

new Nx_Counter_Extra_Addon;
