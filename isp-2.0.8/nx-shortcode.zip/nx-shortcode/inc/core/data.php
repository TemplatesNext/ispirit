<?php
/**
 * Class for managing plugin data
 */
class Nx_Data {

	/**
	 * Constructor
	 */
	function __construct() {}

	/**
	 * Shortcode groups
	 */
	public static function groups() {
		return ( array ) apply_filters( 'nx/data/groups', array(
				'all'     => __( 'All', 'nx' ),
				'content' => __( 'Content', 'nx' ),
				'box'     => __( 'Box', 'nx' ),
				'media'   => __( 'Media', 'nx' ),
				'gallery' => __( 'Gallery', 'nx' ),
				'data'    => __( 'Data', 'nx' ),
				'other'   => __( 'Other', 'nx' )
			) );
	}

	/**
	 * Border styles
	 */
	public static function borders() {
		return ( array ) apply_filters( 'nx/data/borders', array(
				'none'   => __( 'None', 'nx' ),
				'solid'  => __( 'Solid', 'nx' ),
				'dotted' => __( 'Dotted', 'nx' ),
				'dashed' => __( 'Dashed', 'nx' ),
				'double' => __( 'Double', 'nx' ),
				'groove' => __( 'Groove', 'nx' ),
				'ridge'  => __( 'Ridge', 'nx' )
			) );
	}

	/**
	 * Font-Awesome icons
	 */
	public static function icons() {
		return apply_filters( 'nx/data/icons', array( 'glass', 'music', 'search', 'envelope-o', 'heart', 'star', 'star-o', 'user', 'film', 'th-large', 'th', 'th-list', 'check', 'times', 'search-plus', 'search-minus', 'power-off', 'signal', 'cog', 'trash-o', 'home', 'file-o', 'clock-o', 'road', 'download', 'arrow-circle-o-down', 'arrow-circle-o-up', 'inbox', 'play-circle-o', 'repeat', 'refresh', 'list-alt', 'lock', 'flag', 'headphones', 'volume-off', 'volume-down', 'volume-up', 'qrcode', 'barcode', 'tag', 'tags', 'book', 'bookmark', 'print', 'camera', 'font', 'bold', 'italic', 'text-height', 'text-width', 'align-left', 'align-center', 'align-right', 'align-justify', 'list', 'outdent', 'indent', 'video-camera', 'picture-o', 'pencil', 'map-marker', 'adjust', 'tint', 'pencil-square-o', 'share-square-o', 'check-square-o', 'arrows', 'step-backward', 'fast-backward', 'backward', 'play', 'pause', 'stop', 'forward', 'fast-forward', 'step-forward', 'eject', 'chevron-left', 'chevron-right', 'plus-circle', 'minus-circle', 'times-circle', 'check-circle', 'question-circle', 'info-circle', 'crosshairs', 'times-circle-o', 'check-circle-o', 'ban', 'arrow-left', 'arrow-right', 'arrow-up', 'arrow-down', 'share', 'expand', 'compress', 'plus', 'minus', 'asterisk', 'exclamation-circle', 'gift', 'leaf', 'fire', 'eye', 'eye-slash', 'exclamation-triangle', 'plane', 'calendar', 'random', 'comment', 'magnet', 'chevron-up', 'chevron-down', 'retweet', 'shopping-cart', 'folder', 'folder-open', 'arrows-v', 'arrows-h', 'bar-chart-o', 'twitter-square', 'facebook-square', 'camera-retro', 'key', 'cogs', 'comments', 'thumbs-o-up', 'thumbs-o-down', 'star-half', 'heart-o', 'sign-out', 'linkedin-square', 'thumb-tack', 'external-link', 'sign-in', 'trophy', 'github-square', 'upload', 'lemon-o', 'phone', 'square-o', 'bookmark-o', 'phone-square', 'twitter', 'facebook', 'github', 'unlock', 'credit-card', 'rss', 'hdd-o', 'bullhorn', 'bell', 'certificate', 'hand-o-right', 'hand-o-left', 'hand-o-up', 'hand-o-down', 'arrow-circle-left', 'arrow-circle-right', 'arrow-circle-up', 'arrow-circle-down', 'globe', 'wrench', 'tasks', 'filter', 'briefcase', 'arrows-alt', 'users', 'link', 'cloud', 'flask', 'scissors', 'files-o', 'paperclip', 'floppy-o', 'square', 'bars', 'list-ul', 'list-ol', 'strikethrough', 'underline', 'table', 'magic', 'truck', 'pinterest', 'pinterest-square', 'google-plus-square', 'google-plus', 'money', 'caret-down', 'caret-up', 'caret-left', 'caret-right', 'columns', 'sort', 'sort-asc', 'sort-desc', 'envelope', 'linkedin', 'undo', 'gavel', 'tachometer', 'comment-o', 'comments-o', 'bolt', 'sitemap', 'umbrella', 'clipboard', 'lightbulb-o', 'exchange', 'cloud-download', 'cloud-upload', 'user-md', 'stethoscope', 'suitcase', 'bell-o', 'coffee', 'cutlery', 'file-text-o', 'building-o', 'hospital-o', 'ambulance', 'medkit', 'fighter-jet', 'beer', 'h-square', 'plus-square', 'angle-double-left', 'angle-double-right', 'angle-double-up', 'angle-double-down', 'angle-left', 'angle-right', 'angle-up', 'angle-down', 'desktop', 'laptop', 'tablet', 'mobile', 'circle-o', 'quote-left', 'quote-right', 'spinner', 'circle', 'reply', 'github-alt', 'folder-o', 'folder-open-o', 'smile-o', 'frown-o', 'meh-o', 'gamepad', 'keyboard-o', 'flag-o', 'flag-checkered', 'terminal', 'code', 'reply-all', 'mail-reply-all', 'star-half-o', 'location-arrow', 'crop', 'code-fork', 'chain-broken', 'question', 'info', 'exclamation', 'superscript', 'subscript', 'eraser', 'puzzle-piece', 'microphone', 'microphone-slash', 'shield', 'calendar-o', 'fire-extinguisher', 'rocket', 'maxcdn', 'chevron-circle-left', 'chevron-circle-right', 'chevron-circle-up', 'chevron-circle-down', 'html5', 'css3', 'anchor', 'unlock-alt', 'bullseye', 'ellipsis-h', 'ellipsis-v', 'rss-square', 'play-circle', 'ticket', 'minus-square', 'minus-square-o', 'level-up', 'level-down', 'check-square', 'pencil-square', 'external-link-square', 'share-square', 'compass', 'caret-square-o-down', 'caret-square-o-up', 'caret-square-o-right', 'eur', 'gbp', 'usd', 'inr', 'jpy', 'rub', 'krw', 'btc', 'file', 'file-text', 'sort-alpha-asc', 'sort-alpha-desc', 'sort-amount-asc', 'sort-amount-desc', 'sort-numeric-asc', 'sort-numeric-desc', 'thumbs-up', 'thumbs-down', 'youtube-square', 'youtube', 'xing', 'xing-square', 'youtube-play', 'dropbox', 'stack-overflow', 'instagram', 'flickr', 'adn', 'bitbucket', 'bitbucket-square', 'tumblr', 'tumblr-square', 'long-arrow-down', 'long-arrow-up', 'long-arrow-left', 'long-arrow-right', 'apple', 'windows', 'android', 'linux', 'dribbble', 'skype', 'foursquare', 'trello', 'female', 'male', 'gittip', 'sun-o', 'moon-o', 'archive', 'bug', 'vk', 'weibo', 'renren', 'pagelines', 'stack-exchange', 'arrow-circle-o-right', 'arrow-circle-o-left', 'caret-square-o-left', 'dot-circle-o', 'wheelchair', 'vimeo-square', 'try', 'plus-square-o' ) );
	}

	/**
	 * Animate.css animations
	 */
	public static function animations() {
		return apply_filters( 'nx/data/animations', array( 'flash', 'bounce', 'shake', 'tada', 'swing', 'wobble', 'pulse', 'flip', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInDown', 'fadeInLeft', 'fadeInRight', 'fadeInUpBig', 'fadeInDownBig', 'fadeInLeftBig', 'fadeInRightBig', 'bounceIn', 'bounceInDown', 'bounceInUp', 'bounceInLeft', 'bounceInRight', 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight', 'lightSpeedIn', 'lightSpeedOut', 'hinge', 'rollIn' ) );
	}

	/**
	 * Examples section
	 */
	public static function examples() {
		return ( array ) apply_filters( 'nx/data/examples', array(
				'basic' => array(
					'title' => __( 'Basic examples', 'nx' ),
					'items' => array(
						array(
							'name' => __( 'Accordions, spoilers, different styles, anchors', 'nx' ),
							'id'   => 'spoilers',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/spoilers.example',
							'icon' => 'tasks'
						),
						array(
							'name' => __( 'Tabs, vertical tabs, tab anchors', 'nx' ),
							'id'   => 'tabs',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/tabs.example',
							'icon' => 'folder'
						),
						array(
							'name' => __( 'Column layouts', 'nx' ),
							'id'   => 'columns',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/columns.example',
							'icon' => 'th-large'
						),
						array(
							'name' => __( 'Media elements, YouTube, Vimeo, Screenr and self-hosted videos, audio player', 'nx' ),
							'id'   => 'media',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/media.example',
							'icon' => 'play-circle'
						),
						array(
							'name' => __( 'Unlimited buttons', 'nx' ),
							'id'   => 'buttons',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/buttons.example',
							'icon' => 'heart'
						),
						array(
							'name' => __( 'Animations', 'nx' ),
							'id'   => 'animations',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/animations.example',
							'icon' => 'bolt'
						),
					)
				),
				'advanced' => array(
					'title' => __( 'Advanced examples', 'nx' ),
					'items' => array(
						array(
							'name' => __( 'Interacting with posts shortcode', 'nx' ),
							'id' => 'posts',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/posts.example',
							'icon' => 'list'
						),
						array(
							'name' => __( 'Nested shortcodes, shortcodes inside of attributes', 'nx' ),
							'id' => 'nested',
							'code' => plugin_dir_path( NX_PLUGIN_FILE ) . '/inc/examples/nested.example',
							'icon' => 'indent'
						),
					)
				),
			) );
	}

	/**
	 * Shortcodes
	 */
	public static function shortcodes( $shortcode = false ) {
		$shortcodes = apply_filters( 'nx/data/shortcodes', array(
				// heading
				'heading' => array(
					'name' => __( 'Heading', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
					
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'underlined' => __( 'Underlined', 'nx' ),
								'centerlined' => __( 'Middlelined', 'nx' ),
								'coloredline' => __( 'Short Underlined Colored', 'nx' ),																
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Choose style for this heading', 'nx' )
						),
						'heading_tag' => array(
							'type' => 'select',
							'values' => array(
								'div' => __( 'Default-div', 'nx' ),
								'h1' => __( 'h1', 'nx' ),
								'h2' => __( 'h2', 'nx' ),
								'h3' => __( 'h3', 'nx' ),																
								'h4' => __( 'h4', 'nx' ),
								'h5' => __( 'h5', 'nx' ),
								'h6' => __( 'h6', 'nx' ),																

							),
							'default' => 'div',
							'name' => __( 'Heading Tag', 'nx' ),
							'desc' => __( 'Choose a heading tag', 'nx' )
						),						
					/**/	
						'size' => array(
							'type' => 'slider',
							'min' => 7,
							'max' => 48,
							'step' => 1,
							'default' => 24,
							'name' => __( 'Size', 'nx' ),
							'desc' => __( 'Select heading size (pixels)', 'nx' )
						),
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'center' => __( 'Center', 'nx' ),
								'right' => __( 'Right', 'nx' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'nx' ),
							'desc' => __( 'Heading text alignment', 'nx' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 2,
							'default' => 16,
							'name' => __( 'Margin', 'nx' ),
							'desc' => __( 'Bottom margin (pixels)', 'nx' )
						),
						'linktext' => array(
							'default' => __( '', 'nx' ),
							'name' => __( 'Link Text', 'nx' ),
							'desc' => __( 'Optional hyper link to another page or section, including http://', 'nx' )
						),
						'linkurl' => array(
							'default' => __( '', 'nx' ),
							'name' => __( 'Link URL', 'nx' ),
							'desc' => __( 'URL for the optional link', 'nx' )
						),												
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Heading text', 'nx' ),
					'desc' => __( 'Styled heading', 'nx' ),
					'icon' => 'h-square'
				),
				// tabs
				'tabs' => array(
					'name' => __( 'Tabs', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Choose style for this tabs', 'nx' )
						),
						'active' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Active tab', 'nx' ),
							'desc' => __( 'Select which tab is open by default', 'nx' )
						),
						'vertical' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Vertical', 'nx' ),
							'desc' => __( 'Show tabs vertically', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "[%prefix_tab title=\"Title 1\"]Content 1[/%prefix_tab]\n[%prefix_tab title=\"Title 2\"]Content 2[/%prefix_tab]\n[%prefix_tab title=\"Title 3\"]Content 3[/%prefix_tab]", 'nx' ),
					'desc' => __( 'Tabs container', 'nx' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// tab
				'tab' => array(
					'name' => __( 'Tab', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Tab name', 'nx' ),
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Enter tab name', 'nx' )
						),
						'disabled' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Disabled', 'nx' ),
							'desc' => __( 'Is this tab disabled', 'nx' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'nx' ),
							'desc' => __( 'You can use unique anchor for this tab to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This tab will be activated and scrolled in', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Tab content', 'nx' ),
					'desc' => __( 'Single tab', 'nx' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// spoiler
				'spoiler' => array(
					'name' => __( 'Spoiler', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Spoiler title', 'nx' ),
							'name' => __( 'Title', 'nx' ), 'desc' => __( 'Text in spoiler title', 'nx' )
						),
						'open' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Open', 'nx' ),
							'desc' => __( 'Is spoiler content visible by default', 'nx' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'fancy' => __( 'Fancy', 'nx' ),
								'simple' => __( 'Simple', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Choose style for this spoiler', 'nx' )
						),
						'icon' => array(
							'type' => 'select',
							'values' => array(
								'plus'           => __( 'Plus', 'nx' ),
								'plus-circle'    => __( 'Plus circle', 'nx' ),
								'plus-square-1'  => __( 'Plus square 1', 'nx' ),
								'plus-square-2'  => __( 'Plus square 2', 'nx' ),
								'arrow'          => __( 'Arrow', 'nx' ),
								'arrow-circle-1' => __( 'Arrow circle 1', 'nx' ),
								'arrow-circle-2' => __( 'Arrow circle 2', 'nx' ),
								'chevron'        => __( 'Chevron', 'nx' ),
								'chevron-circle' => __( 'Chevron circle', 'nx' ),
								'caret'          => __( 'Caret', 'nx' ),
								'caret-square'   => __( 'Caret square', 'nx' ),
								'folder-1'       => __( 'Folder 1', 'nx' ),
								'folder-2'       => __( 'Folder 2', 'nx' )
							),
							'default' => 'plus',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'Icons for spoiler', 'nx' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'nx' ),
							'desc' => __( 'You can use unique anchor for this spoiler to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This spoiler will be open and scrolled in', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Hidden content', 'nx' ),
					'desc' => __( 'Spoiler with hidden content', 'nx' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'nx' ),
					'example' => 'spoilers',
					'icon' => 'list-ul'
				),
				// accordion
				'accordion' => array(
					'name' => __( 'Accordion', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]", 'nx' ),
					'desc' => __( 'Accordion with spoilers', 'nx' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'nx' ),
					'example' => 'spoilers',
					'icon' => 'list'
				),
				// divider
				'divider' => array(
					'name' => __( 'Divider', 'nx' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'top' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show TOP link', 'nx' ),
							'desc' => __( 'Show link to top of the page or not', 'nx' )
						),
						'text' => array(
							'values' => array( ),
							'default' => __( 'Go to top', 'nx' ),
							'name' => __( 'Link text', 'nx' ), 'desc' => __( 'Text for the GO TOP link', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Content divider with optional TOP link', 'nx' ),
					'icon' => 'ellipsis-h'
				),
				// spacer
				'spacer' => array(
					'name' => __( 'Spacer', 'nx' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 800,
							'step' => 10,
							'default' => 20,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Height of the spacer in pixels', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Empty space with adjustable height', 'nx' ),
					'icon' => 'arrows-v'
				),
				// highlight
				'highlight' => array(
					'name' => __( 'Highlight', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#DDFF99',
							'name' => __( 'Background', 'nx' ),
							'desc' => __( 'Highlighted text background color', 'nx' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Text color', 'nx' ), 'desc' => __( 'Highlighted text color', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Highlighted text', 'nx' ),
					'desc' => __( 'Highlighted text', 'nx' ),
					'icon' => 'pencil'
				),
				// label
				'label' => array(
					'name' => __( 'Label', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'success' => __( 'Success', 'nx' ),
								'warning' => __( 'Warning', 'nx' ),
								'important' => __( 'Important', 'nx' ),
								'black' => __( 'Black', 'nx' ),
								'info' => __( 'Info', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Type', 'nx' ),
							'desc' => __( 'Style of the label', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Label', 'nx' ),
					'desc' => __( 'Styled label', 'nx' ),
					'icon' => 'tag'
				),
				// quote
				'quote' => array(
					'name' => __( 'Quote', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Choose style for this quote', 'nx' )
						),
						'cite' => array(
							'default' => '',
							'name' => __( 'Cite', 'nx' ),
							'desc' => __( 'Quote author name', 'nx' )
						),
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Cite url', 'nx' ),
							'desc' => __( 'Url of the quote author. Leave empty to disable link', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Quote', 'nx' ),
					'desc' => __( 'Blockquote alternative', 'nx' ),
					'icon' => 'quote-right'
				),
				// pullquote
				'pullquote' => array(
					'name' => __( 'Pullquote', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'right' => __( 'Right', 'nx' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'nx' ), 'desc' => __( 'Pullquote alignment (float)', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Pullquote', 'nx' ),
					'desc' => __( 'Pullquote', 'nx' ),
					'icon' => 'quote-left'
				),
				// dropcap
				'dropcap' => array(
					'name' => __( 'Dropcap', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'flat' => __( 'Flat', 'nx' ),
								'light' => __( 'Light', 'nx' ),
								'simple' => __( 'Simple', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ), 'desc' => __( 'Dropcap style preset', 'nx' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 5,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'nx' ),
							'desc' => __( 'Choose dropcap size', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'D', 'nx' ),
					'desc' => __( 'Dropcap', 'nx' ),
					'icon' => 'bold'
				),
				// frame
				'frame' => array(
					'name' => __( 'Frame', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'center' => __( 'Center', 'nx' ),
								'right' => __( 'Right', 'nx' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'nx' ),
							'desc' => __( 'Frame alignment', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => '<img src="http://lorempixel.com/g/400/200/" />',
					'desc' => __( 'Styled image frame', 'nx' ),
					'icon' => 'picture-o'
				),
				// row
				'row' => array(
					'name' => __( 'Row', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'fullwidth' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( 'No', 'nx' ),
								'yes' => __( 'Yes', 'nx' )
							),
							'default' => 'no',
							'name' => __( 'Fullwidth', 'nx' ),
							'desc' => __( 'Force the row full width, works only with pages without sidebars', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]", 'nx' ),
					'desc' => __( 'Row for flexible columns', 'nx' ),
					'icon' => 'columns'
				),
				// column
				'column' => array(
					'name' => __( 'Column', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'size' => array(
							'type' => 'select',
							'values' => array(
								'1/1' => __( 'Full width', 'nx' ),
								'1/2' => __( 'One half', 'nx' ),
								'1/3' => __( 'One third', 'nx' ),
								'2/3' => __( 'Two third', 'nx' ),
								'1/4' => __( 'One fourth', 'nx' ),
								'3/4' => __( 'Three fourth', 'nx' ),
								'1/5' => __( 'One fifth', 'nx' ),
								'2/5' => __( 'Two fifth', 'nx' ),
								'3/5' => __( 'Three fifth', 'nx' ),
								'4/5' => __( 'Four fifth', 'nx' ),
								'1/6' => __( 'One sixth', 'nx' ),
								'5/6' => __( 'Five sixth', 'nx' )
							),
							'default' => '1/2',
							'name' => __( 'Size', 'nx' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'nx' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'nx' ),
							'desc' => __( 'Is this column centered on the page', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Column content', 'nx' ),
					'desc' => __( 'Flexible and responsive columns', 'nx' ),
					'note' => __( 'Did you know that you need to wrap columns with [row] shortcode?', 'nx' ),
					'example' => 'columns',
					'icon' => 'columns'
				),
				// list
				'list' => array(
					'name' => __( 'List', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'You can upload custom icon for this list or pick a built-in icon', 'nx' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'nx' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "<ul>\n<li>List item</li>\n<li>List item</li>\n<li>List item</li>\n</ul>", 'nx' ),
					'desc' => __( 'Styled unordered list', 'nx' ),
					'icon' => 'list-ol'
				),
				// button
				'button' => array(
					'name' => __( 'Button', 'nx' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
					
						'url' => array(
							'values' => array( ),
							'default' => get_option( 'home' ),
							'name' => __( 'Link', 'nx' ),
							'desc' => __( 'Button link', 'nx' )
						),
					/**/	
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'nx' ),
								'blank' => __( 'New tab', 'nx' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'nx' ),
							'desc' => __( 'Button link target', 'nx' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'flat' => __( 'Flat', 'nx' ),
								'soft' => __( 'Soft', 'nx' ),
								'glass' => __( 'Glass', 'nx' ),
								'bubbles' => __( 'Bubbles', 'nx' ),
								'noise' => __( 'Noise', 'nx' ),
								'stroked' => __( 'Stroked', 'nx' ),
								'transparent' => __( 'transparent', 'nx' ),								
								'3d' => __( '3D', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ), 'desc' => __( 'Button background style preset', 'nx' )
						),
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77be32',
							'name' => __( 'Background', 'nx' ), 'desc' => __( 'Button background color', 'nx' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Text color', 'nx' ),
							'desc' => __( 'Button text color', 'nx' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'nx' ),
							'desc' => __( 'Button size', 'nx' )
						),
						'wide' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Fluid', 'nx' ), 'desc' => __( 'Fluid buttons has 100% width', 'nx' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'nx' ), 'desc' => __( 'Is button centered on the page', 'nx' )
						),
						'radius' => array(
							'type' => 'select',
							'values' => array(
								'auto' => __( 'Auto', 'nx' ),
								'round' => __( 'Round', 'nx' ),
								'0' => __( 'Square', 'nx' ),
								'3' => '3px',
								'5' => '5px',
								'10' => '10px',
								'20' => '20px'
							),
							'default' => 'auto',
							'name' => __( 'Radius', 'nx' ),
							'desc' => __( 'Radius of button corners. Auto-radius calculation based on button size', 'nx' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'You can upload custom icon for this button or pick a built-in icon', 'nx' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#FFFFFF',
							'name' => __( 'Icon color', 'nx' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'nx' )
						),
						'text_shadow' => array(
							'type' => 'shadow',
							'default' => 'none',
							'name' => __( 'Text shadow', 'nx' ),
							'desc' => __( 'Button text shadow', 'nx' )
						),
						'desc' => array(
							'default' => '',
							'name' => __( 'Description', 'nx' ),
							'desc' => __( 'Small description under button text. This option is incompatible with icon.', 'nx' )
						),
						'onclick' => array(
							'default' => '',
							'name' => __( 'onClick', 'nx' ),
							'desc' => __( 'Advanced JavaScript code for onClick action', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Button text', 'nx' ),
					'desc' => __( 'Styled button', 'nx' ),
					'example' => 'buttons',
					'icon' => 'heart'
				),
				// service
				'service' => array(
					'name' => __( 'Service', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'round' => __( 'Round background', 'nx' ),
								'square' => __( 'Square background', 'nx' ),
								'curved' => __( 'Curved background', 'nx' ),
								'fancyflip' => __( 'Fancy Flip', 'nx' ),																
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ), 'desc' => __( 'Service icon style', 'nx' )
						),					
						'title' => array(
							'values' => array( ),
							'default' => __( 'Service title', 'nx' ),
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Service name', 'nx' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'You can upload custom icon for this box', 'nx' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color or background color', 'nx' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'nx' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 2,
							'default' => 32,
							'name' => __( 'Icon size', 'nx' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Service description', 'nx' ),
					'desc' => __( 'Service box with title', 'nx' ),
					'icon' => 'check-square-o'
				),
				
				// iconbox
				'iconbox' => array(
					'name' => __( 'Icon Box', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'top' => 'Round icon on top',
								'left' => 'Round icon on left',
								'topcurved' => 'Curved icon on top (reversed color)',
								'topsquare' => 'Square Icon on top (reversed color)'								
							),
							'default' => 'top',
							'name' => __( 'Icon Postion', 'nx' ),
							'desc' => __( 'Icon position in the box', 'nx' )
						),					
						'title' => array(
							'values' => array( ),
							'default' => __( 'Icon box title', 'nx' ),
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Icon box name', 'nx' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'You can upload custom icon for this box', 'nx' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 2,
							'default' => 32,
							'name' => __( 'Icon size', 'nx' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Service description', 'nx' ),
					'desc' => __( 'Service box with title', 'nx' ),
					'icon' => 'check-square-o'
				),
				
				// Slide Down Menu Box
				'slidedownmenubox' => array(
					'name' => __( 'Slide Down Menu Box', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'values' => array( ),
							'default' => __( 'Menu Title', 'nx' ),
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Slide Down Menu Box Title', 'nx' )
						),
						'subtitle' => array(
							'values' => array( ),
							'default' => __( 'Menu Subtitle', 'nx' ),
							'name' => __( 'Sub Title', 'nx' ),
							'desc' => __( 'Slide down menu box subtitle', 'nx' )
						),
						'url' => array(
							'values' => array( ),
							'default' => __( '', 'nx' ),
							'name' => __( 'Menu URL', 'nx' ),
							'desc' => __( 'Slide down menu URL', 'nx' )
						),																	
						'background_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#575757',
							'name' => __( 'Menu Background Color', 'nx' ),
							'desc' => __( 'Select menu background color', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Image Size', 'nx' ),
							'desc' => __( 'select a size to optimize image size', 'nx' )
						),						
						'menu_image' => array(
							'type' => 'upload',						
							'default' => '',
							'name' => __( 'Menu Image Upload', 'nx' ),
							'desc' => __( 'Select/Upload a menu image', 'nx' )
						),
						'direction' => array(
							'type' => 'select',
							'values' => array(
								'right' => 'Right',
								'left' => 'Left'
							),
							'default' => 'right',
							'name' => __( 'Sub Menu/Content Slide Direction', 'nx' ),
							'desc' => __( 'Set direction for the slide containing sublinks or short description', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Slide Down Menu Box content', 'nx' ),
					'desc' => __( 'Slide Down Menu Box', 'nx' ),
					'icon' => 'film'
				),					
				
				
				// Video Parallax
				'videoparallax' => array(
					'name' => __( 'Video Parallax', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'fullwidth' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Full Width', 'nx' ),
							'desc' => __( 'Full width option only works with out sidebars', 'nx' )
						),
						'overlay_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Overlay Color', 'nx' ),
							'desc' => __( 'Color for overlay', 'nx' )
						),
						'overlay_opacity' => array(
							'type' => 'slider',
							'min' => 0.1,
							'max' => 0.9,
							'step' => 0.1,
							'default' => 0.6,
							'name' => __( 'Overlay Opacity', 'nx' ),
							'desc' => __( 'Opacity of the overlay layer', 'nx' )
						),						
						'poster_url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Poster Url', 'nx' ),
							'desc' => __( 'Url of the background image that apears before loading or once browser fails to load video', 'nx' )
						),
						'mp4_url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'mp4 Url', 'nx' ),
							'desc' => __( 'Url of the video in mp4 format', 'nx' )
						),
						'webm_url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'webm Url', 'nx' ),
							'desc' => __( 'Url of the video in webm format', 'nx' )
						),
						'ogg_url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'ogg Url', 'nx' ),
							'desc' => __( 'Url of the video in ogg format', 'nx' )
						),
						'padding' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 100,
							'step' => 1,
							'default' => 72,
							'name' => __( 'Top And Bottom Padding', 'nx' ),
							'desc' => __( 'Top and bottom padding of the parallax container', 'nx' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Text Color', 'nx' ),
							'desc' => __( 'Container text color', 'nx' )
						),
						'text_align' => array(
							'type' => 'select',
							'values' => array(
								'center' => 'Center',
								'left' => 'Left',
								'right' => 'right'
							),
							'default' => 'center',
							'name' => __( 'Text Align', 'nx' ),
							'desc' => __( 'Text alignment in container', 'nx' )
						),																																								
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Video parallax content', 'nx' ),
					'desc' => __( 'Video parallax', 'nx' ),
					'icon' => 'film'
				),				

				// Image Parallax
				'imageparallax' => array(
					'name' => __( 'Image Parallax', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'fullwidth' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Full Width', 'nx' ),
							'desc' => __( 'Full width option only works with out sidebars', 'nx' )
						),
						'overlay_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Overlay Color', 'nx' ),
							'desc' => __( 'Color for overlay', 'nx' )
						),
						'overlay_opacity' => array(
							'type' => 'slider',
							'min' => 0.1,
							'max' => 0.9,
							'step' => 0.1,
							'default' => 0.6,
							'name' => __( 'Overlay Opacity', 'nx' ),
							'desc' => __( 'Opacity of the overlay layer', 'nx' )
						),						
						'prallax_image_url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Poster Url', 'nx' ),
							'desc' => __( 'Url of the background image, skip this option if you are uploading or selecting image from gallery in next step', 'nx' )
						),
						'prallax_image_poster' => array(
							'type' => 'upload',						
							'default' => '',
							'name' => __( 'Poster Image Upload', 'nx' ),
							'desc' => __( 'Select/Upload a background parrallax image, will override "Poster Url"', 'nx' )
						),						
						'image_repeat' => array(
							'type' => 'select',
							'values' => array(
								'cover' => 'Cover',
								'repeat' => 'Repeat'
							),
							'default' => 'cover',
							'name' => __( 'Parallax Image Repeat', 'nx' ),
							'desc' => __( 'Parallax Image Repeat', 'nx' )
						),
						'image_move' => array(
							'type' => 'select',
							'values' => array(
								'dynamic' => 'Dynamic',
								'fixed' => 'Fixed'
							),
							'default' => 'cover',
							'name' => __( 'Parallax Movement', 'nx' ),
							'desc' => __( 'Choose between a dynamic background image or fixed background parallax image', 'nx' )
						),
						'padding' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 100,
							'step' => 1,
							'default' => 72,
							'name' => __( 'Top And Bottom Padding', 'nx' ),
							'desc' => __( 'Top and bottom padding of the parallax container', 'nx' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Text Color', 'nx' ),
							'desc' => __( 'Container text color', 'nx' )
						),
						'text_align' => array(
							'type' => 'select',
							'values' => array(
								'center' => 'Center',
								'left' => 'Left',
								'right' => 'right'
							),
							'default' => 'center',
							'name' => __( 'Text Align', 'nx' ),
							'desc' => __( 'Text alignment in container', 'nx' )
						),																																		
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Image parallax content', 'nx' ),
					'desc' => __( 'Image parallax', 'nx' ),
					'icon' => 'film'
				),				


				// call to act
				'calltoact' => array(
					'name' => __( 'Call To Act', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'fullwidth' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Full Width', 'nx' ),
							'desc' => __( 'Full width option only works with out sidebars', 'nx' )
						),
						'cta_bgcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77be32',
							'name' => __( 'Background Color', 'nx' ),
							'desc' => __( 'Color for overlay', 'nx' )
						),
						'cta_textcolor' => array(
							'type' => 'select',
							'values' => array(
								'dark' 		=> 'Dark',
								'light' 	=> 'light'
							),
							'default' => 'light',
							'name' => __( 'Text Color', 'nx' )
						),												
						'cta_button_text' => array(
							'default' => __( 'Know More', 'nx' ),
							'name' => __( 'Button Text', 'nx' ),
							'desc' => __( 'Enter button text', 'nx' )
						),
						'cta_button_url' => array(
							'default' => '',
							'name' => __( 'Button URL', 'nx' ),
							'desc' => __( 'Enter button URL', 'nx' )
						),																								
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Call to act text', 'nx' ),
					'desc' => __( 'Call To Act', 'nx' ),
					'icon' => 'minus'
				),	
											
				// box
				'box' => array(
					'name' => __( 'Box', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'values' => array( ),
							'default' => __( 'Box title', 'nx' ),
							'name' => __( 'Title', 'nx' ), 'desc' => __( 'Text for the box title', 'nx' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'soft' => __( 'Soft', 'nx' ),
								'glass' => __( 'Glass', 'nx' ),
								'bubbles' => __( 'Bubbles', 'nx' ),
								'noise' => __( 'Noise', 'nx' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Box style preset', 'nx' )
						),
						'box_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Color', 'nx' ),
							'desc' => __( 'Color for the box title and borders', 'nx' )
						),
						'title_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Title text color', 'nx' ), 'desc' => __( 'Color for the box title text', 'nx' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'nx' ),
							'desc' => __( 'Box corners radius', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Box content', 'nx' ),
					'desc' => __( 'Colored box with caption', 'nx' ),
					'icon' => 'list-alt'
				),
				// note
				'note' => array(
					'name' => __( 'Note', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'note_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFF66',
							'name' => __( 'Background', 'nx' ), 'desc' => __( 'Note background color', 'nx' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Text color', 'nx' ),
							'desc' => __( 'Note text color', 'nx' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'nx' ), 
							'desc' => __( 'Note corners radius', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Note text', 'nx' ),
					'desc' => __( 'Colored box', 'nx' ),
					'icon' => 'list-alt'
				),
				// lightbox
				'lightbox' => array(
					'name' => __( 'Lightbox', 'nx' ),
					'type' => 'wrap',
					'group' => 'gallery',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'iframe' => __( 'Iframe', 'nx' ),
								'image' => __( 'Image', 'nx' ),
								'inline' => __( 'Inline (html content)', 'nx' )
							),
							'default' => 'iframe',
							'name' => __( 'Content type', 'nx' ),
							'desc' => __( 'Select type of the lightbox window content', 'nx' )
						),
						'src' => array(
							'default' => '',
							'name' => __( 'Content source', 'nx' ),
							'desc' => __( 'Insert here URL or CSS selector. Use URL for Iframe and Image content types. Use CSS selector for Inline content type.<br />Example values:<br /><b%value>http://www.youtube.com/watch?v=XXXXXXXXX</b> - YouTube video (iframe)<br /><b%value>http://example.com/wp-content/uploads/image.jpg</b> - uploaded image (image)<br /><b%value>http://example.com/</b> - any web page (iframe)<br /><b%value>#contact-form</b> - any HTML content (inline)', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( '[%prefix_button] Click Here to Watch the Video [/%prefix_button]', 'nx' ),
					'desc' => __( 'Lightbox window with custom content', 'nx' ),
					'icon' => 'external-link'
				),
				// tooltip
				'tooltip' => array(
					'name' => __( 'Tooltip', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'light' => __( 'Basic: Light', 'nx' ),
								'dark' => __( 'Basic: Dark', 'nx' ),
								'yellow' => __( 'Basic: Yellow', 'nx' ),
								'green' => __( 'Basic: Green', 'nx' ),
								'red' => __( 'Basic: Red', 'nx' ),
								'blue' => __( 'Basic: Blue', 'nx' ),
								'youtube' => __( 'Youtube', 'nx' ),
								'tipsy' => __( 'Tipsy', 'nx' ),
								'bootstrap' => __( 'Bootstrap', 'nx' ),
								'jtools' => __( 'jTools', 'nx' ),
								'tipped' => __( 'Tipped', 'nx' ),
								'cluetip' => __( 'Cluetip', 'nx' ),
							),
							'default' => 'yellow',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Tooltip window style', 'nx' )
						),
						'position' => array(
							'type' => 'select',
							'values' => array(
								'north' => __( 'Top', 'nx' ),
								'south' => __( 'Bottom', 'nx' ),
								'west' => __( 'Left', 'nx' ),
								'east' => __( 'Right', 'nx' )
							),
							'default' => 'top',
							'name' => __( 'Position', 'nx' ),
							'desc' => __( 'Tooltip position', 'nx' )
						),
						'shadow' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Shadow', 'nx' ),
							'desc' => __( 'Add shadow to tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'nx' )
						),
						'rounded' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Rounded corners', 'nx' ),
							'desc' => __( 'Use rounded for tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'nx' )
						),
						'size' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'1' => 1,
								'2' => 2,
								'3' => 3,
								'4' => 4,
								'5' => 5,
								'6' => 6,
							),
							'default' => 'default',
							'name' => __( 'Font size', 'nx' ),
							'desc' => __( 'Tooltip font size', 'nx' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Tooltip title', 'nx' ),
							'desc' => __( 'Enter title for tooltip window. Leave this field empty to hide the title', 'nx' )
						),
						'content' => array(
							'default' => __( 'Tooltip text', 'nx' ),
							'name' => __( 'Tooltip content', 'nx' ),
							'desc' => __( 'Enter tooltip content here', 'nx' )
						),
						'behavior' => array(
							'type' => 'select',
							'values' => array(
								'hover' => __( 'Show and hide on mouse hover', 'nx' ),
								'click' => __( 'Show and hide by mouse click', 'nx' ),
								'always' => __( 'Always visible', 'nx' )
							),
							'default' => 'hover',
							'name' => __( 'Behavior', 'nx' ),
							'desc' => __( 'Select tooltip behavior', 'nx' )
						),
						'close' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Close button', 'nx' ),
							'desc' => __( 'Show close button', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( '[%prefix_button] Hover me to open tooltip [/%prefix_button]', 'nx' ),
					'desc' => __( 'Tooltip window with custom content', 'nx' ),
					'icon' => 'comment-o'
				),

				// piechart
				'piechart' => array(
					'name' => __( 'Pie Chart', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'title' => array(
							'default' => 'Pie Chart Title',
							'name' => __( 'Pie Chart Title', 'nx' ),
							'desc' => __( 'Enter title for pie chart. Leave this field empty to hide the title', 'nx' )
						),
						'percent' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => '64',
							'name' => __( 'Piechart percent', 'nx' ),
							'desc' => __( 'Enter percent of the chart', 'nx' )
						),
						'barcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77bd32',
							'name' => __( 'Bar Color', 'nx' ),
							'desc' => __( 'Color for the bar', 'nx' )
						),	
						'trackcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77bd32',
							'name' => __( 'Track Color', 'nx' ),
							'desc' => __( 'A semi-transparent value is used, we recommend same color as "Bar Color".', 'nx' )
						),
						'linewidth' => array(
							'type' => 'slider',
							'min' => 6,
							'max' => 20,
							'step' => 1,
							'default' => 6,
							'name' => __( 'Line Width', 'nx' ), 
							'desc' => __( 'Pie chart line width', 'nx' )
						),
						'piesize' => array(
							'type' => 'slider',
							'min' => 100,
							'max' => 200,
							'step' => 10,
							'default' => 200,
							'name' => __( 'Pie size', 'nx' ), 
							'desc' => __( 'Pie chart size', 'nx' )
						),																																	
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Pichart Details text', 'nx' ),
					'desc' => __( 'Pie chart details', 'nx' ),
					'icon' => 'adjust'
				),
				
				// piechart
				'countup' => array(
					'name' => __( 'Counter Up', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'nx' ),
							'desc' => __( 'You can upload custom icon for this box', 'nx' )
						),
						'iconsize' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 2,
							'default' => 32,
							'name' => __( 'Icon size', 'nx' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'nx' )
						),
						'iconcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77bd32',
							'name' => __( 'Icon Color', 'nx' ),
							'desc' => __( 'Select a color', 'nx' )
						),											
						'countto' => array(
							'default' => '3221',
							'name' => __( 'Count Up To', 'nx' ),
							'desc' => __( 'Enter the number for the counter', 'nx' )
						),
						'fontsize' => array(
							'type' => 'slider',
							'min' => 12,
							'max' => 48,
							'step' => 1,
							'default' => 24,
							'name' => __( 'Conter Font Size', 'nx' ), 
							'desc' => __( 'Font size Of the counter', 'nx' )
						),
						'countercolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77bd32',
							'name' => __( 'Counter Color', 'nx' ),
							'desc' => __( 'Select a color', 'nx' )
						),						
						'delay' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 100,
							'step' => 1,
							'default' => 10,
							'name' => __( 'Delay', 'nx' ), 
							'desc' => __( 'Enter delay (duration between counter steps) in miliseconds', 'nx' )
						),
						'ctimer' => array(
							'type' => 'slider',
							'min' => 1000,
							'max' => 4000,
							'step' => 100,
							'default' => 1000,
							'name' => __( 'Timer', 'nx' ), 
							'desc' => __( 'Counting time', 'nx' )
						),												
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Lines of content to appear bellow the counter', 'nx' ),
					'desc' => __( 'Counter up details', 'nx' ),
					'icon' => 'adjust'
				),				
				
				// Skill bar
				'progressbar' => array(
					'name' => __( 'Skill Bar', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'skill_name' => array(
							'default' => 'Skill Name',
							'name' => __( 'Name/label of the skill', 'nx' ),
							'desc' => __( 'Enter the skill/label for the bar', 'nx' )
						),
						'percent' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => '64',
							'name' => __( 'Skill Bar Percent', 'nx' ),
							'desc' => __( 'Enter percent of the bar', 'nx' )
						),
						'barcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77bd32',
							'name' => __( 'Bar Color', 'nx' ),
							'desc' => __( 'Color for the bar', 'nx' )
						),	
						'trackcolor' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#e7e7e7',
							'name' => __( 'Track Color', 'nx' ),
						),
						'barheight' => array(
							'type' => 'slider',
							'min' => 24,
							'max' => 48,
							'step' => 1,
							'default' => 32,
							'name' => __( 'Bar Height', 'nx' ), 
							'desc' => __( 'Height of the bar', 'nx' )
						),
						'candystrip' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Turn Off Candystrip Animation', 'nx' ),
							'desc' => __( 'Turn off candystrip animation', 'nx' )
						),						
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Pie chart details', 'nx' ),
					'icon' => 'adjust'
				),				
				
				// private
				'private' => array(
					'name' => __( 'Private', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Private note text', 'nx' ),
					'desc' => __( 'Private note for post authors', 'nx' ),
					'icon' => 'lock'
				),
				// youtube
				'youtube' => array(
					'name' => __( 'YouTube', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Play video automatically when page is loaded', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'YouTube video', 'nx' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// youtube_advanced
				'youtube_advanced' => array(
					'name' => __( 'YouTube Advanced', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'nx' )
						),
						'playlist' => array(
							'default' => '',
							'name' => __( 'Playlist', 'nx' ),
							'desc' => __( 'Value is a comma-separated list of video IDs to play. If you specify a value, the first video that plays will be the VIDEO_ID specified in the URL path, and the videos specified in the playlist parameter will play thereafter', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'nx' )
						),
						'controls' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Hide controls', 'nx' ),
								'yes' => __( '1 - Show controls', 'nx' ),
								'alt' => __( '2 - Show controls when playback is started', 'nx' )
							),
							'default' => 'yes',
							'name' => __( 'Controls', 'nx' ),
							'desc' => __( 'This parameter indicates whether the video player controls will display', 'nx' )
						),
						'autohide' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Do not hide controls', 'nx' ),
								'yes' => __( '1 - Hide all controls on mouse out', 'nx' ),
								'alt' => __( '2 - Hide progress bar on mouse out', 'nx' )
							),
							'default' => 'alt',
							'name' => __( 'Autohide', 'nx' ),
							'desc' => __( 'This parameter indicates whether the video controls will automatically hide after a video begins playing', 'nx' )
						),
						'showinfo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show title bar', 'nx' ),
							'desc' => __( 'If you set the parameter value to NO, then the player will not display information like the video title and uploader before the video starts playing.', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Play video automatically when page is loaded', 'nx' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'nx' ),
							'desc' => __( 'Setting of YES will cause the player to play the initial video again and again', 'nx' )
						),
						'rel' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Related videos', 'nx' ),
							'desc' => __( 'This parameter indicates whether the player should show related videos when playback of the initial video ends', 'nx' )
						),
						'fs' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show full-screen button', 'nx' ),
							'desc' => __( 'Setting this parameter to NO prevents the fullscreen button from displaying', 'nx' )
						),
						'modestbranding' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => 'modestbranding',
							'desc' => __( 'This parameter lets you use a YouTube player that does not show a YouTube logo. Set the parameter value to YES to prevent the YouTube logo from displaying in the control bar. Note that a small YouTube text label will still display in the upper-right corner of a paused video when the user\'s mouse pointer hovers over the player', 'nx' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'dark' => __( 'Dark theme', 'nx' ),
								'light' => __( 'Light theme', 'nx' )
							),
							'default' => 'dark',
							'name' => __( 'Theme', 'nx' ),
							'desc' => __( 'This parameter indicates whether the embedded player will display player controls (like a play button or volume control) within a dark or light control bar', 'nx' )
						),
						'https' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Force HTTPS', 'nx' ),
							'desc' => __( 'Use HTTPS in player iframe', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'YouTube video player with advanced settings', 'nx' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// vimeo
				'vimeo' => array(
					'name' => __( 'Vimeo', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'nx' ), 'desc' => __( 'Url of Vimeo page with video', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Play video automatically when page is loaded', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Vimeo video', 'nx' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// screenr
				'screenr' => array(
					'name' => __( 'Screenr', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url of Screenr page with video', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Screenr video', 'nx' ),
					'icon' => 'youtube-play'
				),
				// dailymotion
				'dailymotion' => array(
					'name' => __( 'Dailymotion', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url of Dailymotion page with video', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Start the playback of the video automatically after the player load. May not work on some mobile OS versions', 'nx' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#FFC300',
							'name' => __( 'Background color', 'nx' ),
							'desc' => __( 'HTML color of the background of controls elements', 'nx' )
						),
						'foreground' => array(
							'type' => 'color',
							'default' => '#F7FFFD',
							'name' => __( 'Foreground color', 'nx' ),
							'desc' => __( 'HTML color of the foreground of controls elements', 'nx' )
						),
						'highlight' => array(
							'type' => 'color',
							'default' => '#171D1B',
							'name' => __( 'Highlight color', 'nx' ),
							'desc' => __( 'HTML color of the controls elements\' highlights', 'nx' )
						),
						'logo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show logo', 'nx' ),
							'desc' => __( 'Allows to hide or show the Dailymotion logo', 'nx' )
						),
						'quality' => array(
							'type' => 'select',
							'values' => array(
								'240'  => '240',
								'380'  => '380',
								'480'  => '480',
								'720'  => '720',
								'1080' => '1080'
							),
							'default' => '380',
							'name' => __( 'Quality', 'nx' ),
							'desc' => __( 'Determines the quality that must be played by default if available', 'nx' )
						),
						'related' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show related videos', 'nx' ),
							'desc' => __( 'Show related videos at the end of the video', 'nx' )
						),
						'info' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show video info', 'nx' ),
							'desc' => __( 'Show videos info (title/author) on the start screen', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Dailymotion video', 'nx' ),
					'icon' => 'youtube-play'
				),
				// audio
				'audio' => array(
					'name' => __( 'Audio', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'nx' ),
							'desc' => __( 'Audio file url. Supported formats: mp3, ogg', 'nx' )
						),
						'width' => array(
							'values' => array(),
							'default' => '100%',
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width. You can specify width in percents and player will be responsive. Example values: <b%value>200px</b>, <b%value>100&#37;</b>', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Play file automatically when page is loaded', 'nx' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'nx' ),
							'desc' => __( 'Repeat when playback is ended', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Custom audio player', 'nx' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// video
				'video' => array(
					'name' => __( 'Video', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'nx' ),
							'desc' => __( 'Url to mp4/flv video-file', 'nx' )
						),
						'poster' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Poster', 'nx' ),
							'desc' => __( 'Url to poster image, that will be shown before playback', 'nx' )
						),
						'title' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Player title', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Player width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Player height', 'nx' )
						),
						'controls' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Controls', 'nx' ),
							'desc' => __( 'Show player controls (play/pause etc.) or not', 'nx' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Play file automatically when page is loaded', 'nx' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'nx' ),
							'desc' => __( 'Repeat when playback is ended', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Custom video player', 'nx' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// table
				'table' => array(
					'name' => __( 'Table', 'nx' ),
					'type' => 'mixed',
					'group' => 'content',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'CSV file', 'nx' ),
							'desc' => __( 'Upload CSV file if you want to create HTML-table from file', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "<table>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n</table>", 'nx' ),
					'desc' => __( 'Styled table from HTML or CSV file', 'nx' ),
					'icon' => 'table'
				),
				// permalink
				'permalink' => array(
					'name' => __( 'Permalink', 'nx' ),
					'type' => 'mixed',
					'group' => 'content other',
					'atts' => array(
						'id' => array(
							'values' => array( ), 'default' => 1,
							'name' => __( 'ID', 'nx' ),
							'desc' => __( 'Post or page ID', 'nx' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'nx' ),
								'blank' => __( 'New tab', 'nx' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'nx' ),
							'desc' => __( 'Link target. blank - link will be opened in new window/tab', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => '',
					'desc' => __( 'Permalink to specified post/page', 'nx' ),
					'icon' => 'link'
				),
				// members
				'members' => array(
					'name' => __( 'Members', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'message' => array(
							'default' => __( 'This content is for registered users only. Please %login%.', 'nx' ),
							'name' => __( 'Message', 'nx' ), 'desc' => __( 'Message for not logged users', 'nx' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#ffcc00',
							'name' => __( 'Box color', 'nx' ), 'desc' => __( 'This color will applied only to box for not logged users', 'nx' )
						),
						'login_text' => array(
							'default' => __( 'login', 'nx' ),
							'name' => __( 'Login link text', 'nx' ), 'desc' => __( 'Text for the login link', 'nx' )
						),
						'login_url' => array(
							'default' => wp_login_url(),
							'name' => __( 'Login link url', 'nx' ), 'desc' => __( 'Login link url', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Content for logged members', 'nx' ),
					'desc' => __( 'Content for logged in members only', 'nx' ),
					'icon' => 'lock'
				),
				// guests
				'guests' => array(
					'name' => __( 'Guests', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Content for guests', 'nx' ),
					'desc' => __( 'Content for guests only', 'nx' ),
					'icon' => 'user'
				),
				// feed
				'feed' => array(
					'name' => __( 'RSS Feed', 'nx' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url to RSS-feed', 'nx' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Limit', 'nx' ), 'desc' => __( 'Number of items to show', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Feed grabber', 'nx' ),
					'icon' => 'rss'
				),
				// menu
				'menu' => array(
					'name' => __( 'Menu', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'name' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Menu name', 'nx' ), 'desc' => __( 'Custom menu name. Ex: Main menu', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Custom menu by name', 'nx' ),
					'icon' => 'bars'
				),
				// subpages
				'subpages' => array(
					'name' => __( 'Sub pages', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3, 4, 5 ), 'default' => 1,
							'name' => __( 'Depth', 'nx' ),
							'desc' => __( 'Max depth level of children pages', 'nx' )
						),
						'p' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Parent ID', 'nx' ),
							'desc' => __( 'ID of the parent page. Leave blank to use current page', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'List of sub pages', 'nx' ),
					'icon' => 'bars'
				),
				// siblings
				'siblings' => array(
					'name' => __( 'Siblings', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3 ), 'default' => 1,
							'name' => __( 'Depth', 'nx' ),
							'desc' => __( 'Max depth level', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'List of cureent page siblings', 'nx' ),
					'icon' => 'bars'
				),
				// document
				'document' => array(
					'name' => __( 'Document', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Url', 'nx' ),
							'desc' => __( 'Url to uploaded document. Supported formats: doc, xls, pdf etc.', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Viewer width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Viewer height', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make viewer responsive', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Document viewer by Google', 'nx' ),
					'icon' => 'file-text'
				),
				// gmap
				'gmap' => array(
					'name' => __( 'Gmap', 'nx' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Map width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Map height', 'nx' )
						),
						'fullwidth' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Full Width', 'nx' ),
							'desc' => __( 'Full width option only works with out sidebars', 'nx' )
						),						
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make map responsive', 'nx' )
						),
						'address' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Marker', 'nx' ),
							'desc' => __( 'Address for the marker. You can type it in any language', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Maps by Google', 'nx' ),
					'icon' => 'globe'
				),
				// slider
				'slider' => array(
					'name' => __( 'Slider', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'nx' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'nx' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'nx' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'nx' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'nx' ),
								'image'      => __( 'Full-size image', 'nx' ),
								'lightbox'   => __( 'Lightbox', 'nx' ),
								'custom'     => __( 'Slide link (added in media editor)', 'nx' ),
								'attachment' => __( 'Attachment page', 'nx' ),
								'post'       => __( 'Post permalink', 'nx' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'nx' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'nx' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'nx' ),
								'blank' => __( 'New window', 'nx' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'nx' ),
							'desc' => __( 'Open links in', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ), 'desc' => __( 'Slider width (in pixels)', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'nx' ), 'desc' => __( 'Slider height (in pixels)', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make slider responsive', 'nx' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'nx' ), 'desc' => __( 'Display slide titles', 'nx' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'nx' ), 'desc' => __( 'Is slider centered on the page', 'nx' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'nx' ), 'desc' => __( 'Show left and right arrows', 'nx' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Pagination', 'nx' ),
							'desc' => __( 'Show pagination', 'nx' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'nx' ),
							'desc' => __( 'Allow to change slides with mouse wheel', 'nx' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 6000,
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Choose interval between slide animations. Set to 0 to disable autoplay', 'nx' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'nx' ), 'desc' => __( 'Specify animation speed', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Customizable image slider', 'nx' ),
					'icon' => 'picture-o'
				),
				// carousel
				'carousel' => array(
					'name' => __( 'Carousel', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'nx' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'nx' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'nx' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'nx' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'nx' ),
								'image'      => __( 'Full-size image', 'nx' ),
								'lightbox'   => __( 'Lightbox', 'nx' ),
								'custom'     => __( 'Slide link (added in media editor)', 'nx' ),
								'attachment' => __( 'Attachment page', 'nx' ),
								'post'       => __( 'Post permalink', 'nx' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'nx' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'nx' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'nx' ),
								'blank' => __( 'New window', 'nx' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'nx' ),
							'desc' => __( 'Open links in', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 100,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Carousel width (in pixels)', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 20,
							'max' => 1600,
							'step' => 20,
							'default' => 100,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Carousel height (in pixels)', 'nx' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'nx' ),
							'desc' => __( 'Ignore width and height parameters and make carousel responsive', 'nx' )
						),
						'items' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Items to show', 'nx' ),
							'desc' => __( 'How much carousel items is visible', 'nx' )
						),
						'scroll' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1, 'default' => 1,
							'name' => __( 'Scroll number', 'nx' ),
							'desc' => __( 'How much items are scrolled in one transition', 'nx' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'nx' ), 'desc' => __( 'Display titles for each item', 'nx' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'nx' ), 'desc' => __( 'Is carousel centered on the page', 'nx' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'nx' ), 'desc' => __( 'Show left and right arrows', 'nx' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Pagination', 'nx' ),
							'desc' => __( 'Show pagination', 'nx' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'nx' ),
							'desc' => __( 'Allow to rotate carousel with mouse wheel', 'nx' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'nx' ),
							'desc' => __( 'Choose interval between auto animations. Set to 0 to disable autoplay', 'nx' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'nx' ), 'desc' => __( 'Specify animation speed', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Customizable image carousel', 'nx' ),
					'icon' => 'picture-o'
				),
				// custom_gallery
				'custom_gallery' => array(
					'name' => __( 'Gallery', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'nx' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'nx' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'nx' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'nx' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'nx' ),
								'image'      => __( 'Full-size image', 'nx' ),
								'lightbox'   => __( 'Lightbox', 'nx' ),
								'custom'     => __( 'Slide link (added in media editor)', 'nx' ),
								'attachment' => __( 'Attachment page', 'nx' ),
								'post'       => __( 'Post permalink', 'nx' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'nx' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'nx' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'nx' ),
								'blank' => __( 'New window', 'nx' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'nx' ),
							'desc' => __( 'Open links in', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 120,
							'name' => __( 'Width', 'nx' ), 'desc' => __( 'Single item width (in pixels)', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 120,
							'name' => __( 'Height', 'nx' ), 'desc' => __( 'Single item height (in pixels)', 'nx' )
						),
						'title' => array(
							'type' => 'select',
							'values' => array(
								'never' => __( 'Never', 'nx' ),
								'hover' => __( 'On mouse over', 'nx' ),
								'always' => __( 'Always', 'nx' )
							),
							'default' => 'hover',
							'name' => __( 'Show titles', 'nx' ),
							'desc' => __( 'Title display mode', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Customizable image gallery', 'nx' ),
					'icon' => 'picture-o'
				),
				// dummy_text
				'dummy_text' => array(
					'name' => __( 'Dummy text', 'nx' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'what' => array(
							'type' => 'select',
							'values' => array(
								'paras' => __( 'Paragraphs', 'nx' ),
								'words' => __( 'Words', 'nx' ),
								'bytes' => __( 'Bytes', 'nx' ),
							),
							'default' => 'paras',
							'name' => __( 'What', 'nx' ),
							'desc' => __( 'What to generate', 'nx' )
						),
						'amount' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Amount', 'nx' ),
							'desc' => __( 'How many items (paragraphs or words) to generate. Minimum words amount is 5', 'nx' )
						),
						'cache' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Cache', 'nx' ),
							'desc' => __( 'Generated text will be cached. Be careful with this option. If you disable it and insert many dummy_text shortcodes the page load time will be highly increased', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Text placeholder', 'nx' ),
					'icon' => 'text-height'
				),
				
				// dummy_image
				'dummy_image' => array(
					'name' => __( 'Dummy image', 'nx' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 500,
							'name' => __( 'Width', 'nx' ),
							'desc' => __( 'Image width', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 300,
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Image height', 'nx' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'any'       => __( 'Any', 'nx' ),
								'abstract'  => __( 'Abstract', 'nx' ),
								'animals'   => __( 'Animals', 'nx' ),
								'business'  => __( 'Business', 'nx' ),
								'cats'      => __( 'Cats', 'nx' ),
								'city'      => __( 'City', 'nx' ),
								'food'      => __( 'Food', 'nx' ),
								'nightlife' => __( 'Night life', 'nx' ),
								'fashion'   => __( 'Fashion', 'nx' ),
								'people'    => __( 'People', 'nx' ),
								'nature'    => __( 'Nature', 'nx' ),
								'sports'    => __( 'Sports', 'nx' ),
								'technics'  => __( 'Technics', 'nx' ),
								'transport' => __( 'Transport', 'nx' )
							),
							'default' => 'any',
							'name' => __( 'Theme', 'nx' ),
							'desc' => __( 'Select the theme for this image', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Image placeholder with random image', 'nx' ),
					'icon' => 'picture-o'
				),
				
				// animate
				'animate' => array(
					'name' => __( 'Animation', 'nx' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array_combine( self::animations(), self::animations() ),
							'default' => 'bounceIn',
							'name' => __( 'Animation', 'nx' ),
							'desc' => __( 'Select animation type', 'nx' )
						),
						'duration' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 1,
							'name' => __( 'Duration', 'nx' ),
							'desc' => __( 'Animation duration (seconds)', 'nx' )
						),
						'delay' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 0,
							'name' => __( 'Delay', 'nx' ),
							'desc' => __( 'Animation delay (seconds)', 'nx' )
						),
						'inline' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Inline', 'nx' ),
							'desc' => __( 'This parameter determines what HTML tag will be used for animation wrapper. Turn this option to YES and animated element will be wrapped in SPAN instead of DIV. Useful for inline animations, like buttons', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Animated content', 'nx' ),
					'desc' => __( 'Wrapper for animation. Any nested element will be animated', 'nx' ),
					'example' => 'animations',
					'icon' => 'bolt'
				),
				// meta
				'meta' => array(
					'name' => __( 'Meta', 'nx' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'key' => array(
							'default' => '',
							'name' => __( 'Key', 'nx' ),
							'desc' => __( 'Meta key name', 'nx' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'nx' ),
							'desc' => __( 'This text will be shown if data is not found', 'nx' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'nx' ),
							'desc' => __( 'This content will be shown before the value', 'nx' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'nx' ),
							'desc' => __( 'This content will be shown after the value', 'nx' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'nx' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'nx' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'nx' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'nx' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post meta', 'nx' ),
					'icon' => 'info-circle'
				),
				// user
				'user' => array(
					'name' => __( 'User', 'nx' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'display_name'        => __( 'Display name', 'nx' ),
								'ID'                  => __( 'ID', 'nx' ),
								'user_login'          => __( 'Login', 'nx' ),
								'user_nicename'       => __( 'Nice name', 'nx' ),
								'user_email'          => __( 'Email', 'nx' ),
								'user_url'            => __( 'URL', 'nx' ),
								'user_registered'     => __( 'Registered', 'nx' ),
								'user_activation_key' => __( 'Activation key', 'nx' ),
								'user_status'         => __( 'Status', 'nx' )
							),
							'default' => 'display_name',
							'name' => __( 'Field', 'nx' ),
							'desc' => __( 'User data field name', 'nx' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'nx' ),
							'desc' => __( 'This text will be shown if data is not found', 'nx' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'nx' ),
							'desc' => __( 'This content will be shown before the value', 'nx' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'nx' ),
							'desc' => __( 'This content will be shown after the value', 'nx' )
						),
						'user_id' => array(
							'default' => '',
							'name' => __( 'User ID', 'nx' ),
							'desc' => __( 'You can specify custom user ID. Leave this field empty to use an ID of the current user', 'nx' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'nx' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'nx' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'User data', 'nx' ),
					'icon' => 'info-circle'
				),
				// post
				'post' => array(
					'name' => __( 'Post', 'nx' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'ID'                    => __( 'Post ID', 'nx' ),
								'post_author'           => __( 'Post author', 'nx' ),
								'post_date'             => __( 'Post date', 'nx' ),
								'post_date_gmt'         => __( 'Post date', 'nx' ) . ' GMT',
								'post_content'          => __( 'Post content', 'nx' ),
								'post_title'            => __( 'Post title', 'nx' ),
								'post_excerpt'          => __( 'Post excerpt', 'nx' ),
								'post_status'           => __( 'Post status', 'nx' ),
								'comment_status'        => __( 'Comment status', 'nx' ),
								'ping_status'           => __( 'Ping status', 'nx' ),
								'post_name'             => __( 'Post name', 'nx' ),
								'post_modified'         => __( 'Post modified', 'nx' ),
								'post_modified_gmt'     => __( 'Post modified', 'nx' ) . ' GMT',
								'post_content_filtered' => __( 'Filtered post content', 'nx' ),
								'post_parent'           => __( 'Post parent', 'nx' ),
								'guid'                  => __( 'GUID', 'nx' ),
								'menu_order'            => __( 'Menu order', 'nx' ),
								'post_type'             => __( 'Post type', 'nx' ),
								'post_mime_type'        => __( 'Post mime type', 'nx' ),
								'comment_count'         => __( 'Comment count', 'nx' )
							),
							'default' => 'post_title',
							'name' => __( 'Field', 'nx' ),
							'desc' => __( 'Post data field name', 'nx' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'nx' ),
							'desc' => __( 'This text will be shown if data is not found', 'nx' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'nx' ),
							'desc' => __( 'This content will be shown before the value', 'nx' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'nx' ),
							'desc' => __( 'This content will be shown after the value', 'nx' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'nx' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'nx' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'nx' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'nx' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post data', 'nx' ),
					'icon' => 'info-circle'
				),
				// blog
				'blog' => array(
					'name' => __( 'Blog', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'post__in' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the posts that you want to show', 'nx' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Posts per page', 'nx' ),
							'desc' => __( 'Specify number of posts that you want to show. Enter -1 to get all posts', 'nx' )
						),
						/*
						'post_type' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Nx_Tools::get_types(),
							'default' => 'post',
							'name' => __( 'Post types', 'nx' ),
							'desc' => __( 'Select post types. Hold Ctrl key to select multiple post types', 'nx' )
						),
						
						'blog_taxonomy' => array(
							'type' => 'select',
							'values' => Nx_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'nx' ),
							'desc' => __( 'Select taxonomy to show posts from', 'nx' )
						),
						*/
						//'terms' => array(
						'blog_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Nx_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Category', 'nx' ),
							'desc' => __( 'Select terms to show posts from, select none/all (use ctrl+click to select/deselect) for all', 'nx' )
						),
						/*
						'author' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Nx_Tools::get_users(),
							'default' => 'default',
							'name' => __( 'Authors', 'nx' ),
							'desc' => __( 'Choose the authors whose posts you want to show', 'nx' )
						),
						
						'size' => array(
							'type' => 'select',
							'values' => get_intermediate_image_sizes(),
							'default' => '2',
							'name' => __( 'Image Size', 'nx' ),
							'desc' => __( 'Featured image size', 'nx' )
						),						
						
						'postformat' => array(
							'type' => 'select',
							'values' => array(
								'titlenimg' => __( 'Title and Image', 'nx' ),
								'excerpt' => __( 'Excerpt', 'nx' ),
								'fulllength' => __( 'Full Length', 'nx' ),

							),
							'default' => 'excerpt',
							'name' => __( 'Post Output', 'nx' ),
							'desc' => __( 'Post Output Format', 'nx' )
						),
						*/
						'blog_layout' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( 'Standard', 'nx' ),
								'2' => __( 'Masonry', 'nx' ),
								'3' => __( 'Masonry Modern', 'nx' ),
							),
							'default' => '2',
							'name' => __( 'Layout Type', 'nx' ),
							'desc' => __( 'Select blog layout type', 'nx' )
						),						
						'columns' => array(
							'type' => 'select',
							'values' => array(
								'2' => __( '2', 'nx' ),
								'3' => __( '3', 'nx' ),
								'4' => __( '4', 'nx' ),
							),
							'default' => '2',
							'name' => __( 'Number of columns', 'nx' ),
							'desc' => __( 'Number of columns in blog layout', 'nx' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'nx' ),
								'asc' => __( 'Ascending', 'nx' )
							),
							'default' => 'desc',
							'name' => __( 'Order', 'nx' ),
							'desc' => __( 'Posts order', 'nx' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'nx' ),
								'ID' => __( 'Post ID', 'nx' ),
								'author' => __( 'Post author', 'nx' ),
								'title' => __( 'Post title', 'nx' ),
								'name' => __( 'Post slug', 'nx' ),
								'date' => __( 'Date', 'nx' ), 
								'modified' => __( 'Last modified date', 'nx' ),
								'parent' => __( 'Post parent', 'nx' ),
								'rand' => __( 'Random', 'nx' ), 
								'comment_count' => __( 'Comments number', 'nx' ),
								'menu_order' => __( 'Menu order', 'nx' ), 
								'meta_value' => __( 'Meta key values', 'nx' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'nx' ),
							'desc' => __( 'Order posts by', 'nx' )
						),
						/*
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'nx' ),
								'pending' => __( 'Pending', 'nx' ),
								'draft' => __( 'Draft', 'nx' ),
								'auto-draft' => __( 'Auto-draft', 'nx' ),
								'future' => __( 'Future post', 'nx' ),
								'private' => __( 'Private post', 'nx' ),
								'inherit' => __( 'Inherit', 'nx' ),
								'trash' => __( 'Trashed', 'nx' ),
								'any' => __( 'Any', 'nx' ),
							),
							'default' => 'publish',
							'name' => __( 'Post status', 'nx' ),
							'desc' => __( 'Show only posts with selected status', 'nx' )
						),
						*/
						'meta_cat' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Show Catagories', 'nx' ),
							'desc' => __( 'Show or Hide Categories', 'nx' )
						),
						'read_more' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Show "Read More"', 'nx' ),
							'desc' => __( 'Show or Hide Read More link', 'nx' )
						),												
						'paging' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Paging', 'nx' ),
							'desc' => __( 'Use Pagination', 'nx' )
						),							
						/*
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'nx' ),
							'desc' => __( 'Specify offset to start posts loop not from first post', 'nx' )
						),
						*/						
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Ignore sticky', 'nx' ),
							'desc' => __( 'Select Yes to ignore posts that is sticked', 'nx' )
						),
						'pagnav_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'right' => __( 'Right', 'nx' ),
								'center' => __( 'Center', 'nx' ),
							),
							'default' => 'left',
							'name' => __( 'Pagination & filter alignment', 'nx' ),
							'desc' => __( 'Pagination & filter alignment', 'nx' )
						)						
					),
					'desc' => __( 'Custom blog layouts with customizable template', 'nx' ),
					'icon' => 'th-list'
				),
				
				// blog-carousel
				'blogcarousel' => array(
					'name' => __( 'Blog Carousel', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'post__in' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the posts that you want to show', 'nx' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Number of Posts', 'nx' ),
							'desc' => __( 'Specify the number of posts that you want to show.', 'nx' )
						),
						/*
						'post_type' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Nx_Tools::get_types(),
							'default' => 'post',
							'name' => __( 'Post types', 'nx' ),
							'desc' => __( 'Select post types. Hold Ctrl key to select multiple post types', 'nx' )
						),
						
						'blog_taxonomy' => array(
							'type' => 'select',
							'values' => Nx_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'nx' ),
							'desc' => __( 'Select taxonomy to show posts from', 'nx' )
						),
						*/
						//'terms' => array(
						'blog_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Nx_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Category', 'nx' ),
							'desc' => __( 'Select terms to show posts from', 'nx' )
						),
						'columns' => array(
							'type' => 'select',
							'values' => array(
								'2' => __( '2', 'nx' ),
								'3' => __( '3', 'nx' ),
								'4' => __( '4', 'nx' ),
							),
							'default' => '2',
							'name' => __( 'Number of columns', 'nx' ),
							'desc' => __( 'Number of columns in the carousel', 'nx' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'nx' ),
								'asc' => __( 'Ascending', 'nx' )
							),
							'default' => 'desc',
							'name' => __( 'Order', 'nx' ),
							'desc' => __( 'Posts order', 'nx' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'nx' ),
								'ID' => __( 'Post ID', 'nx' ),
								'author' => __( 'Post author', 'nx' ),
								'title' => __( 'Post title', 'nx' ),
								'name' => __( 'Post slug', 'nx' ),
								'date' => __( 'Date', 'nx' ), 
								'modified' => __( 'Last modified date', 'nx' ),
								'parent' => __( 'Post parent', 'nx' ),
								'rand' => __( 'Random', 'nx' ), 
								'comment_count' => __( 'Comments number', 'nx' ),
								'menu_order' => __( 'Menu order', 'nx' ), 
								'meta_value' => __( 'Meta key values', 'nx' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'nx' ),
							'desc' => __( 'Order posts by', 'nx' )
						),
						'blog_car_layout' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( 'Standard', 'nx' ),
								'2' => __( 'Modern', 'nx' ),
							),
							'default' => '1',
							'name' => __( 'Blog Carousel Layout', 'nx' ),
							'desc' => __( 'Select a post layout Type', 'nx' )
						),							
						/*
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'nx' ),
								'pending' => __( 'Pending', 'nx' ),
								'draft' => __( 'Draft', 'nx' ),
								'auto-draft' => __( 'Auto-draft', 'nx' ),
								'future' => __( 'Future post', 'nx' ),
								'private' => __( 'Private post', 'nx' ),
								'inherit' => __( 'Inherit', 'nx' ),
								'trash' => __( 'Trashed', 'nx' ),
								'any' => __( 'Any', 'nx' ),
							),
							'default' => 'publish',
							'name' => __( 'Post status', 'nx' ),
							'desc' => __( 'Show only posts with selected status', 'nx' )
						),
						*/
						'meta_cat' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Show Catagories', 'nx' ),
							'desc' => __( 'Show or Hide Categories', 'nx' )
						),
						'read_more' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Show "Read More"', 'nx' ),
							'desc' => __( 'Show or Hide Read More link', 'nx' )
						),												
						/*
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'nx' ),
							'desc' => __( 'Specify offset to start posts loop not from first post', 'nx' )
						),
						*/						
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Ignore sticky', 'nx' ),
							'desc' => __( 'Select Yes to ignore posts that is sticked', 'nx' )
						)						
					),
					'desc' => __( 'Custom blog layouts with customizable template', 'nx' ),
					'icon' => 'th-list'
				),				
				
				// portfolio
				'portfolio' => array(
					'name' => __( 'Portfolio', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'post__in' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the posts that you want to show', 'nx' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Posts per page', 'nx' ),
							'desc' => __( 'Specify number of posts that you want to show. Enter -1 to get all posts', 'nx' )
						),
						
						
						//'terms' => array(
						'blog_term' => array(
							'type' => 'select',
							//'multiple' => true,
							'values' => Nx_Tools::get_terms_folio( 'portfolio-category' ),
							'default' => '0',
							'name' => __( 'Category', 'nx' ),
							'desc' => __( 'Select terms to show portfolios from', 'nx' )
						),
						/**/
						
						'layout' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( 'Masonry gallery', 'nx' ),
								'2' => __( 'Masonry standard', 'nx' ),
							),
							'default' => '2',
							'name' => __( 'Portfolio Layout', 'nx' ),
							'desc' => __( 'Select a portfolio a layout', 'nx' )
						),						

						'columns' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( '1', 'nx' ),
								'2' => __( '2', 'nx' ),
								'3' => __( '3', 'nx' ),
								'4' => __( '4', 'nx' ),
							),
							'default' => '3',
							'name' => __( 'Number of columns', 'nx' ),
							'desc' => __( 'Number of columns in blog layout', 'nx' )
						),	
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'nx' ),
								'asc' => __( 'Ascending', 'nx' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'nx' ),
							'desc' => __( 'Posts order', 'nx' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'nx' ),
								'ID' => __( 'Post ID', 'nx' ),
								'author' => __( 'Post author', 'nx' ),
								'title' => __( 'Post title', 'nx' ),
								'name' => __( 'Post slug', 'nx' ),
								'date' => __( 'Date', 'nx' ), 
								'modified' => __( 'Last modified date', 'nx' ),
								'parent' => __( 'Post parent', 'nx' ),
								'rand' => __( 'Random', 'nx' ), 
								'comment_count' => __( 'Comments number', 'nx' ),
								'menu_order' => __( 'Menu order', 'nx' ), 
								'meta_value' => __( 'Meta key values', 'nx' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'nx' ),
							'desc' => __( 'Order posts by', 'nx' )
						),
						'filtering' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Category Filter', 'nx' ),
							'desc' => __( 'Use catagory Filter (only available with masonry layout)', 'nx' )
						),					
						'paging' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Paging', 'nx' ),
							'desc' => __( 'Use Pagination', 'nx' )
						),
						'pagnav_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'right' => __( 'Right', 'nx' ),
								'center' => __( 'Center', 'nx' ),
							),
							'default' => 'left',
							'name' => __( 'Pagination & filter alignment', 'nx' ),
							'desc' => __( 'Pagination & filter alignment', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						),												
					),
					'desc' => __( 'Custom portfolio layouts', 'nx' ),
					'icon' => 'th-list'
				),	
				

				// Team
				'team' => array(
					'name' => __( 'Team', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'post__in' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the team member that you want to show', 'nx' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Posts per page', 'nx' ),
							'desc' => __( 'Specify number of posts that you want to show. Enter -1 to get all posts', 'nx' )
						),

						'columns' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( '1', 'nx' ),
								'2' => __( '2', 'nx' ),
								'3' => __( '3', 'nx' ),
								'4' => __( '4', 'nx' ),
							),
							'default' => '4',
							'name' => __( 'Number of columns', 'nx' ),
							'desc' => __( 'Number of columns in blog layout', 'nx' )
						),	
						'paging' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Paging', 'nx' ),
							'desc' => __( 'Use Pagination', 'nx' )
						),
						'pagnav_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'right' => __( 'Right', 'nx' ),
								'center' => __( 'Center', 'nx' ),
							),
							'default' => 'left',
							'name' => __( 'Pagination & filter alignment', 'nx' ),
							'desc' => __( 'Pagination & filter alignment', 'nx' )
						),						
					),
					'desc' => __( 'Custom team layouts', 'nx' ),
					'icon' => 'th-list'
				),
				
				
				// testimonials
				'testimonials' => array(
					'name' => __( 'Testimonials', 'nx' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
								'centererd' => __( 'Center Aligned', 'nx' ),
								'centererd-compact' => __( 'Centered Compact', 'nx' ),
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Testimonial style', 'nx' )
						),
						'delay' => array(
							'type' => 'slider',
							'min' => 1000,
							'max' => 20000,
							'step' => 500,
							'default' => 8000,
							'name' => __( 'Delay', 'nx' ),
							'desc' => __( 'Animation delay (mili seconds)', 'nx' )
						),						
					),
					
					'desc' => __( 'Custom team layouts', 'nx' ),
					'icon' => 'th-list'
				),
				
				// clients
				'clients' => array(
					'name' => __( 'Clients', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'post__in' => array(
							'default' => '',
							'name' => __( 'Client ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the client that you want to show', 'nx' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Number of Clients', 'nx' ),
							'desc' => __( 'Specify number of clients you want to show.', 'nx' )
						),
						'client_border' => array(
							'type' => 'select',
							'values' => array(
								'1' => __( 'Use Border', 'nx' ),
								'2' => __( 'Hide Border', 'nx' ),
							),
							'default' => '1',
							'name' => __( 'Use Border', 'nx' ),
							'desc' => __( 'Use border around logos', 'nx' )
						)										

					),
					'desc' => __( 'Clients Carousel', 'nx' ),
					'icon' => 'th-list'
				),
				
				// Fancy Row
				'fancyrow' => array(
					'name' => __( 'Fancy Blocks', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						/*
						'fullwidth' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Full Width', 'nx' ),
							'desc' => __( 'Full width option only works with out sidebars', 'nx' )
						),
						*/
						'block_height' => array(
							'default' => '',
							'name' => __( 'Height', 'nx' ),
							'desc' => __( 'Height of the block, leave it blank for auto height', 'nx' )
						),
						
						'background_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#77be32',
							'name' => __( 'Background Color', 'nx' ),
							'desc' => __( 'Select a background color', 'nx' )
						),
						'background_opacity' => array(
							'type' => 'slider',
							'min' => 0.0,
							'max' => 1.0,
							'step' => .1,
							'default' => 1,
							'name' => __( 'Background Color Opacity', 'nx' ),
							'desc' => __( 'Background Color Opacity does not work on arrows', 'nx' )
						),								
						'background_image' => array(
							'type' => 'upload',						
							'default' => '',
							'name' => __( 'Background Image', 'nx' ),
							'desc' => __( 'Select/Upload a background image', 'nx' )
						),
						'background_repeat' => array(
							'type' => 'select',
							'values' => array(
								'cover' => 'Cover',
								'repeat' => 'Repeat',
								'no-repeat' => 'No Repeat'
							),
							'default' => 'no-repeat',
							'name' => __( 'Background Repeat/Cover/No Repeat', 'nx' ),
							'desc' => __( 'background image repeat/cover/no repeat', 'nx' )
						),
						'background_position' => array(
							'type' => 'select',
							'values' => array(
								'left top' => 'left top',
								'left center' => 'left center',
								'left bottom' => 'left bottom',
								'right top' => 'right top',
								'right center' => 'right center',
								'right bottom' => 'right bottom',
								'center top' => 'center top',
								'center center' => 'center center',
								'center bottom' => 'center bottom'					
							),
							'default' => 'left top',
							'name' => __( 'Background Position', 'nx' ),
							'desc' => __( 'background image repeat/cover/no repeat', 'nx' )
						),
						'arrow_position' => array(
							'type' => 'select',
							'values' => array(
								'no-arrow' => 'No Arrow',
								'top' => 'Top Arrow',
								'bottom' => 'Bottom Arrow'
							),
							'default' => 'no-arrow',
							'name' => __( 'Select Arrow Position', 'nx' ),
							'desc' => __( 'Select a position for arrowe (only works with background color)', 'nx' )
						),	
						'fullwidth' => array(
							'type' => 'select',
							'values' => array(
								'no' => 'No',
								'yes' => 'Yes'
							),
							'default' => 'no',
							'name' => __( 'Fullwidth', 'nx' ),
							'desc' => __( 'Force the block full width, works only with pages without sidebars', 'nx' )
						),																		
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Fancy Block content, use [nx_spacer size="30"] to add top and bottom padding', 'nx' ),
					'desc' => __( 'Fancy Block', 'nx' ),
					'icon' => 'suitcase'
				),		
				
				// ads Row
				'adsrow' => array(
					'name' => __( 'Ads Row', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( "[%prefix_adscolumn size=\"1-3\"]ads[/%prefix_adscolumn]\n[%prefix_adscolumn size=\"1-3\"]ads[/%prefix_adscolumn]\n[%prefix_adscolumn size=\"1-3\"]ads[/%prefix_adscolumn]", 'nx' ),
					'desc' => __( 'Ads row, use size 1-2 for one half, 1-3 for one third, 2-3 for two third, 1-4 for one fourth', 'nx' ),
					'icon' => 'suitcase'
				),				

				// column
				'adscolumn' => array(
					'name' => __( 'Ads Column', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'size' => array(
							'type' => 'select',
							'values' => array(
								'1-1' => __( 'Full width', 'nx' ),
								'1-2' => __( 'One half', 'nx' ),
								'1-3' => __( 'One third', 'nx' ),
								'2-3' => __( 'Two third', 'nx' ),
								'1-4' => __( 'One fourth', 'nx' ),
								'3-4' => __( 'Three fourth', 'nx' )
							),
							'default' => '1-2',
							'name' => __( 'Size', 'nx' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Column content', 'nx' ),
					'desc' => __( 'Flexible and responsive columns', 'nx' ),
					'note' => __( 'Did you know that you need to wrap Ads columns with [adsrow] shortcode?', 'nx' ),
					'icon' => 'columns'
				),

				// ads block
				'adsblock' => array(
					'name' => __( 'Ads Block', 'nx' ),
					'type' => 'single',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Ads Title', 'nx' ),
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Enter a title', 'nx' )
						),
						'subtitle' => array(
							'default' => __( 'Ads Sub Title', 'nx' ),
							'name' => __( 'Sub Title', 'nx' ),
							'desc' => __( 'Second line of text', 'nx' )
						),
						'buttontext' => array(
							'default' => __( 'View Products', 'nx' ),
							'name' => __( 'Button text', 'nx' ),
							'desc' => __( 'Enter button text', 'nx' )
						),														
						'ads_image' => array(
							'type' => 'upload',						
							'default' => '',
							'name' => __( 'Ads Image', 'nx' ),
							'desc' => __( 'Select/Upload an image', 'nx' )
						),
						'url' => array(
							'values' => array( ),
							'default' => get_option( 'home' ),
							'name' => __( 'Link', 'nx' ),
							'desc' => __( 'Ads link', 'nx' )
						),
						'padding_top' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 240,
							'step' => 1,
							'default' => 120,
							'name' => __( 'Padding Top', 'nx' ),
							'desc' => __( 'Top padding in pixel', 'nx' )
						),																	
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'desc' => __( 'Ads Block', 'nx' ),
					'note' => __( 'Did you know that you need to wrap Adsblock with [adscolumn] and further with [adsrow] shortcode?', 'nx' ),
					'icon' => 'suitcase'
				),							
						
				// column
				'absolutebox' => array(
					'name' => __( 'Absolute Blocks', 'nx' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'nx' ),
							'desc' => __( 'Enter a title', 'nx' )
						),
						'title_size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 72,
							'step' => 1,
							'default' => 24,
							'name' => __( 'Title Font Size', 'nx' ),
							'desc' => __( 'Title Font Size', 'nx' )
						),						
						'title_color' => array(
							'type' => 'color',
							'default' => '#e7e7e7',
							'name' => __( 'Title Color', 'nx' ), 
							'desc' => __( 'This color will applied to title text color', 'nx' )
						),							
						'title_bg_color' => array(
							'type' => 'color',
							'default' => '#373737',
							'name' => __( 'Title Background Color', 'nx' ), 
							'desc' => __( 'This color will applied to title background color', 'nx' )
						),
						'box_state' => array(
							'type' => 'select',
							'values' => array(
								'opened' => 'Opened and Top Fixed (Non Collapsable)',
								'open_from_top' => 'Closed (Collapsable with title) and Top Fixed',								
								'open_from_bottom' => 'Closed (Collapsable with title) and Bottom Fixed'
							),
							'default' => 'opened',
							'name' => __( 'Container Position/State', 'nx' ),
							'desc' => __( 'Select a position and state of the container', 'nx' )
						),
						'top_position' => array(
							'type' => 'number',
							'min' => -1200,
							'max' => 1200,
							'step' => 1,
							'default' => 0,
							'name' => __( 'Top/Bottom Position', 'nx' ),
							'desc' => __( 'Absolute top or bottom position of the container, "Bottom" only in case of "Container Position/State" being "Closed and Bottom Fixed"', 'nx' )
						),
						'box_hposition' => array(
							'type' => 'select',
							'values' => array(
								'left' => 'Position From Left',
								'right' => 'Position From Right'
							),
							'default' => 'left',
							'name' => __( 'Horizontal Position From', 'nx' ),
							'desc' => __( 'Place the container in absolute position from left or right', 'nx' )
						),						
						'h_position' => array(
							'type' => 'number',
							'min' => -1200,
							'max' => 1200,
							'step' => 1,
							'default' => 0,
							'name' => __( 'Left Position', 'nx' ),
							'desc' => __( 'Absolute left position of the container', 'nx' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 100,
							'step' => 1,
							'default' => 25,
							'name' => __( 'Width In Percent', 'nx' ),
							'desc' => __( 'Width In Percent of Parent Container', 'nx' )
						),
						'text_color' => array(
							'type' => 'color',
							'default' => '#373737',
							'name' => __( 'Text Color', 'nx' ), 
							'desc' => __( 'This color will applied to title text color', 'nx' )
						),							
						'bg_color' => array(
							'type' => 'color',
							'default' => '#FFFFFF',
							'name' => __( 'Background Color', 'nx' ), 
							'desc' => __( 'This color will applied to container background color', 'nx' )
						),
						'transparent' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Transparent Background', 'nx' ),
							'desc' => __( 'Background Tranparency', 'nx' )
						),
						/*
						'opacity' => array(
							'type' => 'slider',
							'min' => 0.0,
							'max' => 0.9,
							'step' => 0.1,
							'default' => 0.0,
							'name' => __( 'Background Opacity', 'nx' ),
							'desc' => __( 'If background transparent choose background opacity.', 'nx' )
						),*/						
						'padding' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 32,
							'step' => 1,
							'default' => 16,
							'name' => __( 'Container Padding', 'nx' ),
							'desc' => __( 'Adjust container padding, 16 default', 'nx' )
						),						
						'mobile_device' => array(
							'type' => 'select',
							'values' => array(
								'1' => 'No Change',
								'2' => 'Hide On Mobile Devices',
								'3' => 'Make it Relative'							
							),
							'default' => 'left',
							'name' => __( 'Mobile Device', 'nx' ),
							'desc' => __( 'Mobile device behavour of the container', 'nx' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'nx' ),
							'desc' => __( 'Extra CSS class', 'nx' )
						)
					),
					'content' => __( 'Absolute Container Content', 'nx' ),
					'desc' => __( 'Absolute Positioned Contaiuners', 'nx' ),
					'icon' => 'columns'
				),
									
				// Product carousel
				'products_carusel' => array(
					'name' => __( 'Product Carusel', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'prod_ids' => array(
							'default' => '',
							'name' => __( 'Product or Category ID\'s', 'nx' ),
							'desc' => __( 'Enter comma separated ID\'s of the products/categories that you want to show or keep it blank. Works only with "Products By ID" and "Product Categories"', 'nx' )
						),
						'product_listing_type' => array(
							'type' => 'select',
							'values' => array(
								'product_categories' => __( 'Product Categories', 'nx' ),
								'recent_products' => __( 'Recent Products', 'nx' ),
								'featured_products' => __( 'Featured products', 'nx' ),
								'sale_products' => __( 'Products on Sale', 'nx' ),
								'best_selling_products' => __( 'Best Selling Products', 'nx' ),
								'top_rated_products' => __( 'Top Rated Products', 'nx' ),
								'products' => __( 'Products By ID', 'nx' ),								
							),
							'default' => 'recent_products',
							'name' => __( 'Carusel Listing Type', 'nx' ),
							'desc' => __( 'Select product listing type for the carusel', 'nx' )
						),
						'columns' => array(
							'type' => 'slider',
							'min' => 2,
							'max' => 6,
							'step' => 1,
							'default' => 4,
							'name' => __( 'Number Of Columns', 'nx' ),
							'desc' => __( 'Select number of column to be shown in the carusel', 'nx' )
						),									
						'number' => array(
							'type' => 'slider',
							'min' => 4,
							'max' => 20,
							'step' => 1,
							'default' => 10,
							'name' => __( 'Number Of Product In The carousel', 'nx' ),
							'desc' => __( 'Select number of product to be shown in the carusel', 'nx' )
						),									

					),
					'desc' => __( 'Product Carousel', 'nx' ),
					'icon' => 'th-list'
				),
				
				// itrans Slider
				'itrans_slider' => array(
					'name' => __( 'itrans Slider', 'nx' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'nx' ),
							),
							'default' => 'default',
							'name' => __( 'Style', 'nx' ),
							'desc' => __( 'Slider style', 'nx' )
						),
						'category' => array(
							'type' => 'select',
							'multiple' => false,
							'values' => Nx_Tools::get_terms( 'itrans-slider-category', 'slug' ),
							'default' => '',
							'name' => __( 'Select Slider Category', 'nx' ),
							'desc' => __( 'Select a slider category', 'nx' )
						),						
						'transition' => array(
							'type' => 'select',
							'values' => array(
								'slide' => __( 'Slide', 'nx' ),
								'fade' => __( 'Fade', 'nx' ),
								'backSlide' => __( 'Back Slide', 'nx' ),
								'goDown' => __( 'Go Down', 'nx' ),
								'fadeUp' => __( 'Fade Up', 'nx' ),				
							),
							'default' => 'slide',
							'name' => __( 'Slider Transition', 'nx' ),
							'desc' => __( 'Select slider transition effect', 'nx' )
						),
						'items' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 4,
							'name' => __( 'Number Of Items (slides)', 'nx' ),
							'desc' => __( 'Number of slides in the slider', 'nx' )
						),									
						'delay' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 60,
							'step' => 1,
							'default' => 8,
							'name' => __( 'Delay', 'nx' ),
							'desc' => __( 'Duration between slides in seconds', 'nx' )
						),
						'parallax' => array(
							'type' => 'select',
							'values' => array(
								'yes' => __( 'Yes', 'nx' ),
								'no' => __( 'No', 'nx' ),
							),
							'default' => 'slide',
							'name' => __( 'Parallax Effect', 'nx' ),
							'desc' => __( 'Turn ON/OFF parallax effect', 'nx' )
						),	
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'nx' ),
								'center' => __( 'Center', 'nx' ),
								'right' => __( 'Right', 'nx' ),								
							),
							'default' => 'Left',
							'name' => __( 'Text Alignment', 'nx' )
						),
						'textbg' => array(
							'type' => 'select',
							'values' => array(
								'shadow'	=> __('Shadowed', 'nx'),				
								'transp'	=> __('Semi Transparent', 'nx'),
								'noshad'	=> __('None', 'nx'),															
							),
							'default' => 'Left',
							'name' => __( 'Text Background', 'nx' ),
							'desc' => __( 'Choose a background style for the slide text', 'nx' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 800,
							'step' => 10,
							'default' => 520,
							'name' => __( 'Slide Height in PX', 'nx' ),
							'desc' => __( 'Slide image height in PX', 'nx' )
						),																																	

					),
					'desc' => __( 'Itrans Slider', 'nx' ),
					'icon' => 'th-list'
				),				
				
			
			) );
		// Return result
		return ( is_string( $shortcode ) ) ? $shortcodes[sanitize_text_field( $shortcode )] : $shortcodes;
	}
}

class Nx_Shortcode_Data extends Nx_Data {
	function __construct() {
		parent::__construct();
	}
}