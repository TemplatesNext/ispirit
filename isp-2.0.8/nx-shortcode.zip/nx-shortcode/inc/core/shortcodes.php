<?php
class Nx_Shortcodes {
	static $tabs = array();
	static $tab_count = 0;

	function __construct() {}

	public static function heading( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style'  => 'default',
				'heading_tag'  => 'div',				
				'size'   => 24,
				'align'  => 'left',
				'margin' => '16',
				'linktext' => '',
				'linkurl' => '',								
				'class'  => ''
			), $atts, 'heading' );
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		do_action( 'nx/shortcode/heading', $atts );
		
		$nx_title_more = '';
		if(!empty($atts['linktext']))
		{
			$nx_title_more = '<a class="nx-title-more" href="' . $atts['linkurl'] . '" style="font-size:' . intval( $atts['size']/100*80 ) . 'px;font-weight: 200;">' . $atts['linktext'] . '</a>';
		}
		
		return '<div class="nx-heading nx-heading-style-' . $atts['style'] . ' nx-heading-align-' . $atts['align'] . nx_ecssc( $atts ) . '" style="font-size:' . intval( $atts['size'] ) . 'px;margin-bottom:' . $atts['margin'] . 'px"><'.$atts['heading_tag'].' class="nx-heading-inner">' . do_shortcode( $content ) . '</'.$atts['heading_tag'].'>' . $nx_title_more . '</div>';
	}

	public static function tabs( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'active'   => 1,
				'vertical' => 'no',
				'style'    => 'default', // 3.x
				'class'    => ''
			), $atts, 'tabs' );
		if ( $atts['style'] === '3' ) $atts['vertical'] = 'yes';
		do_shortcode( $content );
		$return = '';
		$tabs = $panes = array();
		if ( is_array( self::$tabs ) ) {
			if ( self::$tab_count < $atts['active'] ) $atts['active'] = self::$tab_count;
			foreach ( self::$tabs as $tab ) {
				$tabs[] = '<span class="' . nx_ecssc( $tab ) . $tab['disabled'] . '"' . $tab['anchor'] . '>' . nx_scattr( $tab['title'] ) . '</span>';
				$panes[] = '<div class="nx-tabs-pane nx-clearfix' . nx_ecssc( $tab ) . '">' . $tab['content'] . '</div>';
			}
			$atts['vertical'] = ( $atts['vertical'] === 'yes' ) ? ' nx-tabs-vertical' : '';
			$return = '<div class="nx-tabs nx-tabs-style-' . $atts['style'] . $atts['vertical'] . nx_ecssc( $atts ) . '" data-active="' . (string) $atts['active'] . '"><div class="nx-tabs-nav">' . implode( '', $tabs ) . '</div><div class="nx-tabs-panes">' . implode( "\n", $panes ) . '</div></div>';
		}
		// Reset tabs
		self::$tabs = array();
		self::$tab_count = 0;
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		do_action( 'nx/shortcode/tabs', $atts );
		return $return;
	}

	public static function tab( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'    => __( 'Tab title', 'nx' ),
				'disabled' => 'no',
				'anchor' => '',
				'class'    => ''
			), $atts, 'tab' );
		$x = self::$tab_count;
		self::$tabs[$x] = array(
			'title' => $atts['title'],
			'content' => do_shortcode( $content ),
			'disabled' => ( $atts['disabled'] === 'yes' ) ? ' nx-tabs-disabled' : '',
			'anchor' => ( $atts['anchor'] ) ? ' data-anchor="' . str_replace( ' ', '', trim( sanitize_text_field( $atts['anchor'] ) ) ) . '"' : '',
			'class' => $atts['class']
		);
		self::$tab_count++;
		do_action( 'nx/shortcode/tab', $atts );
	}

	public static function spoiler( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'  => __( 'Spoiler title', 'nx' ),
				'open'   => 'no',
				'style'  => 'default',
				'icon'   => 'plus',
				'anchor' => '',
				'class'  => ''
			), $atts, 'spoiler' );
		$atts['style'] = str_replace( array( '1', '2' ), array( 'default', 'fancy' ), $atts['style'] );
		$atts['anchor'] = ( $atts['anchor'] ) ? ' data-anchor="' . str_replace( ' ', '', trim( sanitize_text_field( $atts['anchor'] ) ) ) . '"' : '';
		if ( $atts['open'] !== 'yes' ) $atts['class'] .= ' nx-spoiler-closed';
		nx_query_asset( 'css', 'font-awesome' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		do_action( 'nx/shortcode/spoiler', $atts );
		return '<div class="nx-spoiler nx-spoiler-style-' . $atts['style'] . ' nx-spoiler-icon-' . $atts['icon'] . nx_ecssc( $atts ) . '"' . $atts['anchor'] . '><div class="nx-spoiler-title"><span class="nx-spoiler-icon"></span>' . nx_scattr( $atts['title'] ) . '</div><div class="nx-spoiler-content nx-clearfix">' . nx_do_shortcode( $content, 's' ) . '</div></div>';
	}

	public static function accordion( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 'class' => '' ), $atts, 'accordion' );
		do_action( 'nx/shortcode/accordion', $atts );
		return '<div class="nx-accordion' . nx_ecssc( $atts ) . '">' . do_shortcode( $content ) . '</div>';
	}

	public static function divider( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'top'   => 'yes',
				'text'  => __( 'Go to top', 'nx' ),
				'class' => ''
			), $atts, 'divider' );
		$top = ( $atts['top'] === 'yes' ) ? '<a href="#">' . nx_scattr( $atts['text'] ) . '</a>' : '';
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<div class="nx-divider' . nx_ecssc( $atts ) . '">' . $top . '</div>';
	}

	public static function spacer( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'size'  => '20',
				'class' => ''
			), $atts, 'spacer' );
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<div class="nx-spacer' . nx_ecssc( $atts ) . '" style="height:' . (string) $atts['size'] . 'px"></div>';
	}

	public static function highlight( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'background' => '#ddff99',
				'bg'         => null, // 3.x
				'color'      => '#000000',
				'class'      => ''
			), $atts, 'highlight' );
		if ( $atts['bg'] !== null ) $atts['background'] = $atts['bg'];
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<span class="nx-highlight' . nx_ecssc( $atts ) . '" style="background:' . $atts['background'] . ';color:' . $atts['color'] . '">&nbsp;' . do_shortcode( $content ) . '&nbsp;</span>';
	}

	public static function label( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'type'  => 'default',
				'style' => null, // 3.x
				'class' => ''
			), $atts, 'label' );
		if ( $atts['style'] !== null ) $atts['type'] = $atts['style'];
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<span class="nx-label nx-label-type-' . $atts['type'] . nx_ecssc( $atts ) . '">' . do_shortcode( $content ) . '</span>';
	}

	public static function quote( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style' => 'default',
				'cite'  => false,
				'url'   => false,
				'class' => ''
			), $atts, 'quote' );
		$cite_link = ( $atts['url'] && $atts['cite'] ) ? '<a href="' . $atts['url'] . '" target="_blank">' . $atts['cite'] . '</a>'
		: $atts['cite'];
		$cite = ( $atts['cite'] ) ? '<span class="nx-quote-cite">' . $cite_link . '</span>' : '';
		$cite_class = ( $atts['cite'] ) ? ' nx-quote-has-cite' : '';
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		do_action( 'nx/shortcode/quote', $atts );
		return '<div class="nx-quote nx-quote-style-' . $atts['style'] . $cite_class . nx_ecssc( $atts ) . '"><div class="nx-quote-inner nx-clearfix">' . do_shortcode( $content ) . nx_scattr( $cite ) . '</div></div>';
	}

	public static function pullquote( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'align' => 'left',
				'class' => ''
			), $atts, 'pullquote' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		return '<div class="nx-pullquote nx-pullquote-align-' . $atts['align'] . nx_ecssc( $atts ) . '">' . do_shortcode( $content ) . '</div>';
	}

	public static function dropcap( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style' => 'default',
				'size'  => 3,
				'class' => ''
			), $atts, 'dropcap' );
		$atts['style'] = str_replace( array( '1', '2', '3' ), array( 'default', 'light', 'default' ), $atts['style'] ); // 3.x
		// Calculate font-size
		$em = $atts['size'] * 0.5 . 'em';
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<span class="nx-dropcap nx-dropcap-style-' . $atts['style'] . nx_ecssc( $atts ) . '" style="font-size:' . $em . '">' . do_shortcode( $content ) . '</span>';
	}

	public static function frame( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style' => 'default',
				'align' => 'left',
				'class' => ''
			), $atts, 'frame' );
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		return '<span class="nx-frame nx-frame-align-' . $atts['align'] . ' nx-frame-style-' . $atts['style'] . nx_ecssc( $atts ) . '"><span class="nx-frame-inner">' . do_shortcode( $content ) . '</span></span>';
	}

	public static function row( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 
				'fullwidth' => 'no',
				'class' => '' 
			), $atts );
		
		if	( $atts['fullwidth'] == 'yes' )
		{
			return '<div class="fullwidthrow nx-row' . nx_ecssc( $atts ) . '">' . nx_do_shortcode( $content, 'r' ) . '</div>';
		}
		{
			return '<div class="nx-row' . nx_ecssc( $atts ) . '">' . nx_do_shortcode( $content, 'r' ) . '</div>';
		}
	}

	public static function column( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'size'   => '1/2',
				'center' => 'no',
				'last'   => null,
				'class'  => ''
			), $atts, 'column' );
		if ( $atts['last'] !== null && $atts['last'] == '1' ) $atts['class'] .= ' nx-column-last';
		if ( $atts['center'] === 'yes' ) $atts['class'] .= ' nx-column-centered';
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		return '<div class="nx-column nx-column-size-' . str_replace( '/', '-', $atts['size'] ) . nx_ecssc( $atts ) . '"><div class="nx-column-inner nx-clearfix">' . nx_do_shortcode( $content, 'c' ) . '</div></div>';
	}

	public static function nx_list( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'icon' => 'icon: star',
				'icon_color' => '#333',
				'style' => null,
				'class' => ''
			), $atts, 'list' );
		// Backward compatibility // 4.2.3+
		if ( $atts['style'] !== null ) {
			switch ( $atts['style'] ) {
			case 'star':
				$atts['icon'] = 'icon: star';
				$atts['icon_color'] = '#ffd647';
				break;
			case 'arrow':
				$atts['icon'] = 'icon: arrow-right';
				$atts['icon_color'] = '#00d1ce';
				break;
			case 'check':
				$atts['icon'] = 'icon: check';
				$atts['icon_color'] = '#17bf20';
				break;
			case 'cross':
				$atts['icon'] = 'icon: remove';
				$atts['icon_color'] = '#ff142b';
				break;
			case 'thumbs':
				$atts['icon'] = 'icon: thumbs-o-up';
				$atts['icon_color'] = '#8a8a8a';
				break;
			case 'link':
				$atts['icon'] = 'icon: external-link';
				$atts['icon_color'] = '#5c5c5c';
				break;
			case 'gear':
				$atts['icon'] = 'icon: cog';
				$atts['icon_color'] = '#ccc';
				break;
			case 'time':
				$atts['icon'] = 'icon: time';
				$atts['icon_color'] = '#a8a8a8';
				break;
			case 'note':
				$atts['icon'] = 'icon: edit';
				$atts['icon_color'] = '#f7d02c';
				break;
			case 'plus':
				$atts['icon'] = 'icon: plus-sign';
				$atts['icon_color'] = '#61dc3c';
				break;
			case 'guard':
				$atts['icon'] = 'icon: shield';
				$atts['icon_color'] = '#1bbe08';
				break;
			case 'event':
				$atts['icon'] = 'icon: bullhorn';
				$atts['icon_color'] = '#ff4c42';
				break;
			case 'idea':
				$atts['icon'] = 'icon: sun';
				$atts['icon_color'] = '#ffd880';
				break;
			case 'settings':
				$atts['icon'] = 'icon: cogs';
				$atts['icon_color'] = '#8a8a8a';
				break;
			case 'twitter':
				$atts['icon'] = 'icon: twitter-sign';
				$atts['icon_color'] = '#00ced6';
				break;
			}
		}
		if ( strpos( $atts['icon'], 'icon:' ) !== false ) {
			$atts['icon'] = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style="color:' . $atts['icon_color'] . '"></i>';
			nx_query_asset( 'css', 'font-awesome' );
		}
		else $atts['icon'] = '<img src="' . $atts['icon'] . '" alt="" />';
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return '<div class="nx-list nx-list-style-' . $atts['style'] . nx_ecssc( $atts ) . '">' . str_replace( '<li>', '<li>' . $atts['icon'] . ' ', nx_do_shortcode( $content, 'l' ) ) . '</div>';
	}

	public static function button( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'         => get_option( 'home' ),
				'link'        => null, // 3.x
				'target'      => 'self',
				'style'       => 'default',
				'background'  => '#77be32',
				'color'       => '#FFFFFF',
				'dark'        => null, // 3.x
				'size'        => 3,
				'wide'        => 'no',
				'center'      => 'no',
				'radius'      => 'auto',
				'icon'        => false,
				'icon_color'  => '#FFFFFF',
				'ts_color'    => null, // Dep. 4.3.2
				'ts_pos'      => null, // Dep. 4.3.2
				'text_shadow' => 'none',
				'desc'        => '',
				'onclick'     => '',
				'class'       => ''
			), $atts, 'button' );

		if ( $atts['link'] !== null ) $atts['url'] = $atts['link'];
		if ( $atts['dark'] !== null ) {
			$atts['background'] = $atts['color'];
			$atts['color'] = ( $atts['dark'] ) ? '#000' : '#fff';
		}
		if ( is_numeric( $atts['style'] ) ) $atts['style'] = str_replace( array( '1', '2', '3', '4', '5' ), array( 'default', 'glass', 'bubbles', 'noise', 'stroked' ), $atts['style'] ); // 3.x
		// Prepare vars
		$a_css = array();
		$span_css = array();
		$img_css = array();
		$small_css = array();
		$radius = '0px';
		$before = $after = '';
		// Text shadow values
		$shadows = array(
			'none'         => '0 0',
			'top'          => '0 -1px',
			'right'        => '1px 0',
			'bottom'       => '0 1px',
			'left'         => '-1px 0',
			'top-right'    => '1px -1px',
			'top-left'     => '-1px -1px',
			'bottom-right' => '1px 1px',
			'bottom-left'  => '-1px 1px'
		);
		// Common styles for button
		$styles = array(
			'size'     => round( ( $atts['size'] + 7 ) * 1.3 ),
			'ts_color' => ( $atts['ts_color'] === 'light' ) ? nx_hex_shift( $atts['background'], 'lighter', 50 ) : nx_hex_shift( $atts['background'], 'darker', 40 ),
			'ts_pos'   => ( $atts['ts_pos'] !== null ) ? $shadows[$atts['ts_pos']] : $shadows['none']
		);
		// Calculate border-radius
		if ( $atts['radius'] == 'auto' ) $radius = round( $atts['size'] + 2 ) . 'px';
		elseif ( $atts['radius'] == 'round' ) $radius = round( ( ( $atts['size'] * 2 ) + 2 ) * 2 + $styles['size'] ) . 'px';
		elseif ( is_numeric( $atts['radius'] ) ) $radius = intval( $atts['radius'] ) . 'px';
		// CSS rules for <a> tag
		$a_rules = array(
			'color'                 => $atts['color'],
			'background-color'      => $atts['background'],
			'border-color'          => nx_hex_shift( $atts['background'], 'darker', 20 ),
			'border-radius'         => $radius,
			'-moz-border-radius'    => $radius,
			'-webkit-border-radius' => $radius
		);
		// CSS rules for <span> tag
		$span_rules = array(
			'color'                 => $atts['color'],
			'padding'               => ( $atts['icon'] ) ? round( ( $atts['size'] ) / 2 + 4 ) . 'px ' . round( $atts['size'] * 2 + 10 ) . 'px' : '0px ' . round( $atts['size'] * 2 + 10 ) . 'px',
			'font-size'             => $styles['size'] . 'px',
			'line-height'           => ( $atts['icon'] ) ? round( $styles['size'] * 1.5 ) . 'px' : round( $styles['size'] * 2 ) . 'px',
			'border-color'          => nx_hex_shift( $atts['background'], 'lighter', 30 ),
			'border-radius'         => $radius,
			'-moz-border-radius'    => $radius,
			'-webkit-border-radius' => $radius,
			'text-shadow'           => $styles['ts_pos'] . ' 1px ' . $styles['ts_color'],
			'-moz-text-shadow'      => $styles['ts_pos'] . ' 1px ' . $styles['ts_color'],
			'-webkit-text-shadow'   => $styles['ts_pos'] . ' 1px ' . $styles['ts_color']
		);
		// Apply new text-shadow value
		if ( $atts['ts_color'] === null && $atts['ts_pos'] === null ) {
			$span_rules['text-shadow'] = $atts['text_shadow'];
			$span_rules['-moz-text-shadow'] = $atts['text_shadow'];
			$span_rules['-webkit-text-shadow'] = $atts['text_shadow'];
		}
		
		if ( $atts['style'] == 'transparent' ) {
			$a_rules['color'] = $atts['color'];
			$a_rules['background'] = 'transparent';
			//$a_rules['background'] = 'rgba(255,255,255,0.0)';
			$a_rules['border-color'] = '#ffffff';

			// CSS rules for <span> tag
			$span_rules['color'] = $atts['color'];
			$span_rules['border-color'] = '#ffffff';			
		}
		// CSS rules for <img> tag
		$img_rules = array(
			'width'     => round( $styles['size'] * 1.5 ) . 'px',
			'height'    => round( $styles['size'] * 1.5 ) . 'px'
		);
		// CSS rules for <small> tag
		$small_rules = array(
			'padding-bottom' => round( ( $atts['size'] ) / 2 + 4 ) . 'px',
			'color' => $atts['color']
		);
		// Create style attr value for <a> tag
		foreach ( $a_rules as $a_rule => $a_value ) $a_css[] = $a_rule . ':' . $a_value;
		// Create style attr value for <span> tag
		foreach ( $span_rules as $span_rule => $span_value ) $span_css[] = $span_rule . ':' . $span_value;
		// Create style attr value for <img> tag
		foreach ( $img_rules as $img_rule => $img_value ) $img_css[] = $img_rule . ':' . $img_value;
		// Create style attr value for <img> tag
		foreach ( $small_rules as $small_rule => $small_value ) $small_css[] = $small_rule . ':' . $small_value;
		// Prepare button classes
		$classes = array( 'nx-button', 'nx-button-style-' . $atts['style'] );
		// Additional classes
		if ( $atts['class'] ) $classes[] = $atts['class'];
		// Wide class
		if ( $atts['wide'] === 'yes' ) $classes[] = 'nx-button-wide';
		// Prepare icon
		if ( $atts['icon'] ) {
			if ( strpos( $atts['icon'], 'icon:' ) !== false ) {
				$icon = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style="font-size:' . $styles['size'] . 'px;color:' . $atts['icon_color'] . '"></i>';
				nx_query_asset( 'css', 'font-awesome' );
			}
			else $icon = '<img src="' . $atts['icon'] . '" alt="' . esc_attr( $content ) . '" style="' . implode( $img_css, ';' ) . '" />';
		}
		else $icon = '';
		// Prepare <small> with description
		$desc = ( $atts['desc'] ) ? '<small style="' . implode( $small_css, ';' ) . '">' . nx_scattr( $atts['desc'] ) . '</small>' : '';
		// Wrap with div if button centered
		if ( $atts['center'] === 'yes' ) {
			$before .= '<div class="nx-button-center">';
			$after .= '</div>';
		}
		// Replace icon marker in content,
		// add float-icon class to rearrange margins
		if ( strpos( $content, '%icon%' ) !== false ) {
			$content = str_replace( '%icon%', $icon, $content );
			$classes[] = 'nx-button-float-icon';
		}
		// Button text has no icon marker, append icon to begin of the text
		else $content = $icon . ' ' . $content;
		// Prepare onclick action
		$atts['onclick'] = ( $atts['onclick'] ) ? ' onClick="' . $atts['onclick'] . '"' : '';
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		return $before . '<a href="' . nx_scattr( $atts['url'] ) . '" class="' . implode( $classes, ' ' ) . '" style="' . implode( $a_css, ';' ) . '" target="_' . $atts['target'] . '"' . $atts['onclick'] . '><span style="' . implode( $span_css, ';' ) . '">' . do_shortcode( $content ) . $desc . '</span></a>' . $after;
	}

	public static function service( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'       => __( 'Service title', 'nx' ),
				'style'       => 'default',				
				'icon'        => plugins_url( 'assets/images/service.png', NX_PLUGIN_FILE ),
				'icon_color'  => '#333',
				'size'        => 32,
				'class'       => ''
			), $atts, 'service' );
		// Built-in icon
		if ( strpos( $atts['icon'], 'icon:' ) !== false ) {
			
			if ( $atts['style'] == 'round' || $atts['style'] == 'square' || $atts['style'] == 'curved' )
			{
				$atts['icon'] = '<span class="service-icon-wrap ' . $atts['style'] . '"><i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style="font-size:' . $atts['size'] . 'px;background-color:' . $atts['icon_color'] . '"></i></span>';
			} elseif ( $atts['style'] == 'fancyflip' )
			{
				$atts['icon'] = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style="font-size:' . $atts['size'] . 'px;line-height:' . $atts['size']*2 . 'px;color:' . $atts['icon_color'] . '"></i>';
			} else
			{
				$atts['icon'] = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style="font-size:' . $atts['size'] . 'px;color:' . $atts['icon_color'] . '"></i>';
			}
			
			nx_query_asset( 'css', 'font-awesome' );
		}
		// Uploaded icon
		else {
			$atts['icon'] = '<img src="' . $atts['icon'] . '" width="' . $atts['size'] . '" height="' . $atts['size'] . '" alt="' . $atts['title'] . '" />';
		}
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		
		if ( $atts['style'] == 'default' )
		{
			return '<div class="nx-service' . nx_ecssc( $atts ) . '"><div class="nx-service-title" style="padding-left:' . round( $atts['size'] + 14 ) . 'px;min-height:' . $atts['size'] . 'px;line-height:' . $atts['size'] . 'px">' . $atts['icon'] . ' ' . nx_scattr( $atts['title'] ) . '</div><div class="nx-service-content nx-clearfix" style="padding-left:' . round( $atts['size'] + 14 ) . 'px">' . do_shortcode( $content ) . '</div></div>';			
		} elseif ( $atts['style'] == 'fancyflip' )
		{
			return '<div class="nx-service nx-service-teaser ' . nx_ecssc( $atts ) . '"><div class="nx-cube" style="height: ' . $atts['size']*2 . 'px"><div class="nx-flippety" style="height: ' . $atts['size']*2 . 'px">'.$atts['icon'].'</div><div class="nx-flop" style="height: ' . $atts['size']*2 . 'px;background-color:' . $atts['icon_color'] . '">'.$atts['icon'].'</div></div><div class="nx-service-teaser-content nx-clearfix" style=""><h2>' . nx_scattr( $atts['title'] ) . '</h2><div class="content">' . do_shortcode( $content ) . '</div></div></div>';				
		} else 
		{
			return '<div class="nx-service' . nx_ecssc( $atts ) . '"><div class="nx-service-title" style="padding-left:' . (round( $atts['size'])*2 + 16 ) . 'px;min-height:' . $atts['size'] . 'px;line-height:' . $atts['size'] . 'px">' . $atts['icon'] . ' ' . nx_scattr( $atts['title'] ) . '</div><div class="nx-service-content nx-clearfix" style="padding-left:' . (round( $atts['size'])*2 +  16 ) . 'px">' . do_shortcode( $content ) . '</div></div>';			
		}
		
	}
	
	public static function iconbox( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style'       => 'top',		
				'title'       => __( 'Icon box title', 'nx' ),
				'icon'        => plugins_url( 'assets/images/service.png', NX_PLUGIN_FILE ),
				'size'        => 32,
				'class'       => ''
			), $atts, 'iconbox' );
		
		$ico_param = '';
		$border_adjust = 4;
		$ico_box_class = '';
		$ico_content_style = '';
		$padding_left = '';
		$ico_size = $atts['size'];
		
		if ( $atts['style'] == 'topcurved' || $atts['style'] == 'topsquare' )
		{
			$border_adjust = 12;
		}
		
		$ico_param = 'font-size:' . $ico_size . 'px; width: ' . (2*$ico_size+$border_adjust) . 'px; height: ' . (2*$ico_size+$border_adjust) . 'px; line-height: '. (2*$ico_size) . 'px';
			
		// Built-in icon
		if ( strpos( $atts['icon'], 'icon:' ) !== false ) {
			$atts['icon'] = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style=" ' . $ico_param . ' "></i>';
			nx_query_asset( 'css', 'font-awesome' );
		}
		// Uploaded icon
		else {
			$atts['icon'] = '<img src="' . $atts['icon'] . '" width="' . $atts['size'] . '" height="' . $atts['size'] . '" alt="' . $atts['title'] . '" />';
		}
		
		if ( $atts['style'] == 'left' )
		{
			$ico_box_class = 'ibox-left';
			$padding_left = 2*$ico_size+32;
			$ico_content_style = 'padding-left:' . $padding_left . 'px; ';
		} elseif ( $atts['style'] == 'topcurved' )
		{
			$ico_box_class = 'ibox-topcurved';
		} elseif ( $atts['style'] == 'topsquare' )
		{
			$ico_box_class = 'ibox-topcurved ibox-topsquare';
		}
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );			
		
		if ( $atts['style'] == 'topcurved' || $atts['style'] == 'topsquare' ) {
			
			return '<div class="nx-icobox iconbox2 ' . $ico_box_class . '"><div class="icon-wrap">' . $atts['icon'] . '</div><div class="iconbox-content-wrap clearfix" style="' . $ico_content_style . '"><h3>' . nx_scattr( $atts['title'] ) . '</h3><div class="iconbox-hr"></div><div class="iconbox-content">' . do_shortcode( $content ) . '</div></div></div>';
		} else
		{
			return '<div class="nx-icobox iconbox ' . $ico_box_class . '"><div class="icon-wrap">' . $atts['icon'] . '</div><div class="iconbox-content-wrap clearfix" style="' . $ico_content_style . '"><h3>' . nx_scattr( $atts['title'] ) . '</h3><div class="iconbox-hr"></div><div class="iconbox-content">' . do_shortcode( $content ) . '</div></div></div>';
		}

	}
	
	
	// Slide Down Menu Box
	public static function slidedownmenubox( $atts = null, $content = null ) {
		
		$menu_image_url = "";
		$bg_image_url = "";
		$height = 90;
		$bg_css = "";
		
		$atts = shortcode_atts( array(
				'title'        			=> 'Menu Title',
				'subtitle'        		=> 'Menu Subtitle',	
				'url'        			=> '',						
				'background_color'      => '#575757',
				'menu_image'  			=> '',
				'bg_image'  			=> '',							
				'width'    				=> '600',
				'direction'        		=> 'right',																		
				'class'					=> ''
			), $atts, 'slidedownmenubox' );
			
			$menu_url = nx_scattr($atts['url']);
		
			/**/
			if(!empty($atts['menu_image']))
			{
				$menu_image_url = nx_scattr($atts['menu_image']);
				$menu_image_url = nx_image_resize( $menu_image_url, $atts['width'], $atts['width'] );
				$menu_image_url = $menu_image_url['url'];				
			}
			
			$bg_css = 'background-color:'.$atts['background_color'].';';
			
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );			

		return '<div class="nx-slide-down-box' . nx_ecssc( $atts ) . '" data-sublink-direction="'.$atts['direction'].'"><a href="'.$menu_url.'"  style="'.$bg_css.'" class="sdt_imglink"><img src="'.$menu_image_url.'" alt=""/><span class="sdt_active"></span><span class="sdt_wrap"><span class="sdt_link">'.$atts['title'].'</span><span class="sdt_descr">'.$atts['subtitle'].'</span></span></a><div class="sdt_box">' . do_shortcode( $content ) . '</div></div>';				

	}	
	
	// video parallax
	public static function videoparallax( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'fullwidth'        	=> 'yes',
				'overlay_color'     => '#000',
				'overlay_opacity'   => 0.6,				
				'poster_url'        => '',				
				'mp4_url'        	=> '',
				'webm_url'        	=> '',
				'ogg_url'        	=> '',
				'padding'        	=> '72',
				'text_color'        => '#FFFFFF',
				'text_align'        	=> 'center',			
				'class'       		=> ''
			), $atts, 'videoparallax' );
			
			$nx_fullwidth = "";
			if ( $atts['fullwidth'] == 'yes')
			{
				$nx_fullwidth = "fullwidthrow";
			}
			
			$overlay_rgba = nx_hex2rgba($atts['overlay_color'], $atts['overlay_opacity']);
			
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );		

		return '<div class="row video-parallax ' . $nx_fullwidth . ' ' . nx_ecssc( $atts ) . '"><div class="prallax-wrap"><div class="parallax-contents" style="padding: '.$atts['padding'].'px 0px; color: ' .$atts['text_color']. '; text-align: ' .$atts['text_align']. ';">' . do_shortcode( $content ) . '</div></div><div class="video-overlay" style="background-color:' . $overlay_rgba. ';"></div><div class="video-wrap"><video class="parallax-video" poster="' . nx_scattr( $atts['poster_url'] ) . '" preload="auto" autoplay loop="loop" muted="muted" id="david"><source src="' . nx_scattr( $atts['mp4_url'] ) . '" type="video/mp4"><source src="' . nx_scattr( $atts['webm_url'] ) . '" type="video/webm"><source src="' . nx_scattr( $atts['ogg_url'] ) . '" type="video/ogg"></video></div></div>';		

	}
	
	public static function imageparallax( $atts = null, $content = null ) {
		
		$parallax_image_url = "";
		
		$atts = shortcode_atts( array(
				'fullwidth'        		=> 'yes',
				'overlay_color'        	=> '#000',
				'overlay_opacity'       => 0.6,				
				'prallax_image_url'     => '',
				'prallax_image_poster'  => '',				
				'image_repeat'    		=> 'cover',
				'image_move'    		=> 'dynamic',
				'padding'        		=> '72',
				'text_color'        	=> '#FFFFFF',
				'text_align'        	=> 'center',																		
				'class'					=> ''
			), $atts, 'imageparallax' );
			
			$nx_fullwidth = "";
			if ( $atts['fullwidth'] == 'yes')
			{
				$nx_fullwidth = "fullwidthrow";
			}
			
			$parallax_image_url = nx_scattr( $atts['prallax_image_url'] );
			
			if(!empty($atts['prallax_image_poster']))
			{
				$parallax_image_url = nx_scattr($atts['prallax_image_poster']);
			}
			
			
			$overlay_rgba = nx_hex2rgba($atts['overlay_color'], $atts['overlay_opacity']);
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );			
		
		$parallax_image_css = "background-attachment: fixed; background-size: cover;";
		if ($atts['image_repeat'] == 'cover')
		{
			$parallax_image_css = 'background-attachment: fixed; background-size: cover;';
		} else
		{
			$parallax_image_css = 'background-attachment: fixed; background-repeat: repeat;';
		}
		
		if ( $atts['image_move']=='fixed' )
		{
		return '<div class="row nx-fixedbg-parallax ' . $nx_fullwidth . ' ' . nx_ecssc( $atts ) . '"><div style="background-image: url(' . $parallax_image_url . '); '. $parallax_image_css .' "><div class="prallax-wrap-fixed" style="background-color:' . $overlay_rgba. ';"><div class="parallax-contents" style="padding: '.$atts['padding'].'px 0px; color: ' .$atts['text_color']. '; text-align: ' .$atts['text_align']. '; ">' . do_shortcode( $content ) . '</div></div></div></div>';				
		} else
		{

		return '<div class="row image-parallax ' . $nx_fullwidth . ' ' . nx_ecssc( $atts ) . '"><div class="prallax-wrap"><div class="parallax-contents" style="padding: '.$atts['padding'].'px 0px; color: ' .$atts['text_color']. '; text-align: ' .$atts['text_align']. ';">' . do_shortcode( $content ) . '</div></div><div class="image-overlay" style="background-color:' . $overlay_rgba. ';"></div><div class="image-wrap" style="background-image: url(' . $parallax_image_url . '); '. $parallax_image_css .' "><img src="' . $parallax_image_url . '" alt="" /></div></div>';				
			
		}
		
	

	}
	
	public static function calltoact( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'fullwidth'        	=> 'yes',
				'cta_bgcolor'   	=> '#77be32',
				'cta_textcolor'   	=> 'light',								
				'cta_button_text'   => 'Know More',
				'cta_button_url'   	=> '',												
				'class'				=> ''
			), $atts, 'calltoact' );
			
			$nx_classes = "";
			$nx_textcolor = "";
			$nx_buttoncolor = "";
			
			if ( $atts['fullwidth'] == 'yes')
			{
				$nx_classes .="fullwidthrow ";
			}
			
			if ( $atts['cta_textcolor'] == 'light')
			{
				$nx_textcolor .="whitetext ";
				$nx_buttoncolor = "white";
			} else
			{
				$nx_textcolor .="darktext ";
				$nx_buttoncolor = "dark";				
			}

		return '<div class="row calltoact ' . $nx_classes . ' ' . nx_ecssc( $atts ) . '" style="background-color:' . $atts['cta_bgcolor'] . ';"><div class="calltoact-wrap" style="background-color:' . $atts['cta_bgcolor'] . ';"><div class="calltoact-contents clearfix"><div class="cta-content ' . $nx_textcolor . '"><h2 class="">' . do_shortcode( $content ) . '</h2></div><div class="cta-button"><a href="' . nx_scattr($atts['cta_button_url']) . '" class="ibutton ' . $nx_buttoncolor . '">' . nx_scattr($atts['cta_button_text']) . '</a></div></div></div></div>';		

	}				

	public static function box( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'       => __( 'This is box title', 'nx' ),
				'style'       => 'default',
				'box_color'   => '#333333',
				'title_color' => '#FFFFFF',
				'color'       => null, // 3.x
				'radius'      => '3',
				'class'       => ''
			), $atts, 'box' );
		if ( $atts['color'] !== null ) $atts['box_color'] = $atts['color'];
		// Prepare border-radius
		$radius = ( $atts['radius'] != '0' ) ? 'border-radius:' . $atts['radius'] . 'px;-moz-border-radius:' . $atts['radius'] . 'px;-webkit-border-radius:' . $atts['radius'] . 'px;' : '';
		$title_radius = ( $atts['radius'] != '0' ) ? $atts['radius'] - 1 : '';
		$title_radius = ( $title_radius ) ? '-webkit-border-top-left-radius:' . $title_radius . 'px;-webkit-border-top-right-radius:' . $title_radius . 'px;-moz-border-radius-topleft:' . $title_radius . 'px;-moz-border-radius-topright:' . $title_radius . 'px;border-top-left-radius:' . $title_radius . 'px;border-top-right-radius:' . $title_radius . 'px;' : '';
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		// Return result
		return '<div class="nx-box nx-box-style-' . $atts['style'] . nx_ecssc( $atts ) . '" style="border-color:' . nx_hex_shift( $atts['box_color'], 'darker', 0 ) . ';' . $radius . '"><div class="nx-box-title" style="background-color:' . $atts['box_color'] . ';color:' . $atts['title_color'] . ';' . $title_radius . '">' . nx_scattr( $atts['title'] ) . '</div><div class="nx-box-content nx-clearfix">' . nx_do_shortcode( $content, 'b' ) . '</div></div>';
	}

	public static function note( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'note_color' => '#FFFF66',
				'text_color' => '#333333',
				'background' => null, // 3.x
				'color'      => null, // 3.x
				'radius'     => '3',
				'class'      => ''
			), $atts, 'note' );
		if ( $atts['color'] !== null ) $atts['note_color'] = $atts['color'];
		if ( $atts['background'] !== null ) $atts['note_color'] = $atts['background'];
		// Prepare border-radius
		$radius = ( $atts['radius'] != '0' ) ? 'border-radius:' . $atts['radius'] . 'px;-moz-border-radius:' . $atts['radius'] . 'px;-webkit-border-radius:' . $atts['radius'] . 'px;' : '';
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		return '<div class="nx-note' . nx_ecssc( $atts ) . '" style="border-color:' . nx_hex_shift( $atts['note_color'], 'darker', 10 ) . ';' . $radius . '"><div class="nx-note-inner nx-clearfix" style="background-color:' . $atts['note_color'] . ';border-color:' . nx_hex_shift( $atts['note_color'], 'lighter', 80 ) . ';color:' . $atts['text_color'] . ';' . $radius . '">' . nx_do_shortcode( $content, 'n' ) . '</div></div>';
	}

	public static function lightbox( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'src'   => false,
				'type'  => 'iframe',
				'class' => ''
			), $atts, 'lightbox' );
		if ( !$atts['src'] ) return '<p class="nx-error">Lightbox: ' . __( 'please specify correct source', 'nx' ) . '</p>';
		nx_query_asset( 'css', 'magnific-popup' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'magnific-popup' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		return '<span class="nx-lightbox' . nx_ecssc( $atts ) . '" data-mfp-src="' . nx_scattr( $atts['src'] ) . '" data-mfp-type="' . $atts['type'] . '">' . do_shortcode( $content ) . '</span>';
	}

	public static function tooltip( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'style'        => 'yellow',
				'position'     => 'north',
				'shadow'       => 'no',
				'rounded'      => 'no',
				'size'         => 'default',
				'title'        => '',
				'content'      => __( 'Tooltip text', 'nx' ),
				'behavior'     => 'hover',
				'close'        => 'no',
				'class'        => ''
			), $atts, 'tooltip' );
		// Prepare style
		$atts['style'] = ( in_array( $atts['style'], array( 'light', 'dark', 'green', 'red', 'blue', 'youtube', 'tipsy', 'bootstrap', 'jtools', 'tipped', 'cluetip' ) ) ) ? $atts['style'] : 'plain';
		// Position
		$atts['position'] = str_replace( array( 'top', 'right', 'bottom', 'left' ), array( 'north', 'east', 'south', 'west' ), $atts['position'] );
		$position = array(
			'my' => str_replace( array( 'north', 'east', 'south', 'west' ), array( 'bottom center', 'center left', 'top center', 'center right' ), $atts['position'] ),
			'at' => str_replace( array( 'north', 'east', 'south', 'west' ), array( 'top center', 'center right', 'bottom center', 'center left' ), $atts['position'] )
		);
		// Prepare classes
		$classes = array( 'nx-qtip qtip-' . $atts['style'] );
		$classes[] = 'nx-qtip-size-' . $atts['size'];
		if ( $atts['shadow'] === 'yes' ) $classes[] = 'qtip-shadow';
		if ( $atts['rounded'] === 'yes' ) $classes[] = 'qtip-rounded';
		// Query assets
		nx_query_asset( 'css', 'qtip' );
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'qtip' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		return '<span class="nx-tooltip' . nx_ecssc( $atts ) . '" data-close="' . $atts['close'] . '" data-behavior="' . $atts['behavior'] . '" data-my="' . $position['my'] . '" data-at="' . $position['at'] . '" data-classes="' . implode( ' ', $classes ) . '" data-title="' . $atts['title'] . '" title="' . esc_attr( $atts['content'] ) . '">' . do_shortcode( $content ) . '</span>';
	}


	public static function piechart( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'    		=> __( 'Pie Chart Title', 'nx' ),
				'percent'     	=> '64',
				'barcolor'      => '#77bd32',
				'trackcolor'    => '#77bd32',
				'linewidth'     => '6',
				'piesize'     	=> '200',				
				'content'      	=> __( 'Pie Chart Content', 'nx' ),
				'piedelay'		=> '300',
				'class'        	=> ''
			), $atts, 'piechart' );
		
		
		// Query assets
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'js', 'easypiechart' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		
		
		return '<div class="nx-pie clearfix"><h4 class="pie-title">' . nx_scattr($atts['title']) . '</h4><span class="chart nx-piechart" data-percent="' . $atts['percent'] . '" data-barcolor="' . $atts['barcolor'] . '" data-trackcolor="' . $atts['trackcolor'] . '" data-linewidth="' . $atts['linewidth'] . '" data-piesize="' . $atts['piesize'] . '" style="height: ' . $atts['piesize'] . 'px; width: ' . $atts['piesize'] . 'px;"><span class="percent" style="line-height: ' . $atts['piesize'] . 'px;"></span></span><div class="pie-text">' . do_shortcode( $content ) . '</div></div>';
	}
	
	public static function countup( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'icon'     		=> '',
				'iconcolor'  	=> '#77bd32',				
				'iconsize'      => '32',
				'countto'     	=> '3221',
				'countercolor'  => '#77bd32',
				'fontsize'    	=> '24',
				'delay'        	=> '10',
				'ctimer'        	=> '1000',								
				'content'      	=> __( 'Lines of content', 'nx' ),				
				'class'        	=> ''
			), $atts, 'countup' );
			
			
		$ico_param = '';
		$ico_size = $atts['iconsize'];
		$ico_param = 'font-size:' . $ico_size . 'px; width: ' . 1.6*$ico_size . 'px; height: ' . 1.6*$ico_size . 'px; line-height: '. 1.6*$ico_size . 'px; color: '.$atts['iconcolor'].';';
			
		// Built-in icon
		if ( strpos( $atts['icon'], 'icon:' ) !== false ) {
			$atts['icon'] = '<i class="fa fa-' . trim( str_replace( 'icon:', '', $atts['icon'] ) ) . '" style=" ' . $ico_param . ' "></i>';
			nx_query_asset( 'css', 'font-awesome' );
		}
		// Uploaded icon
		else {
			$atts['icon'] = '<img src="' . $atts['icon'] . '" width="' . $atts['iconsize'] . '" height="' . $atts['iconsize'] . '" alt="' . $atts['title'] . '" />';
		}
				
		// Query assets
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'js', 'counterup' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		
		
		return '<div class="nx-cunter clearfix" data-delay="' . $atts['delay'] . '" data-ctimer="' . $atts['ctimer'] . '"><div class="icon-wrap">' . $atts['icon'] . '</div><span class="counter" style="font-size: '.$atts['fontsize'].'px; color: '.$atts['countercolor'].'">' . $atts['countto'] . '</span><div class="countup-text">' . do_shortcode( $content ) . '</div></div>';
	}	
	
	public static function progressbar( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'skill_name' 	=> __( 'Skill Name', 'nx' ),
				'percent'     	=> '64',
				'barcolor'      => '#77bd32',
				'trackcolor'    => '#e7e7e7',
				'barheight'     => '32',
				'candystrip'     => 'no',
				'class'        	=> ''
			), $atts, 'progressbar' );
			
			$nx_class = "candystrip";
			
			if ( $atts['candystrip'] == 'yes')
			{
				$nx_class = "";
			}			
		
		
		// Query assets
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		
		
		return '<div class="prograss-container" data-progress-percent="' . $atts['percent'] . '"><div class="pbar-outer" style="height: ' . $atts['barheight'] . 'px; line-height: ' . $atts['barheight'] . 'px; background-color: ' . $atts['trackcolor'] . ';"><div class="pbar-text">'. nx_scattr($atts['skill_name']) .' <span class="bpercent"></span></div><div class="pbar-inner" style="background-color:' . $atts['barcolor'] . '; height: ' . $atts['barheight'] . 'px;"><div class="'.$nx_class.'"></div></div></div></div> ';
	}	


	public static function nx_private( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 'class' => '' ), $atts, 'private' );
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		return ( current_user_can( 'publish_posts' ) ) ? '<div class="nx-private' . nx_ecssc( $atts ) . '"><div class="nx-private-shell">' . do_shortcode( $content ) . '</div></div>' : '';
	}

	public static function media( $atts = null, $content = null ) {
		// Check YouTube video
		if ( strpos( $atts['url'], 'youtu' ) !== false ) return Nx_Shortcodes::youtube( $atts );
		// Check Vimeo video
		elseif ( strpos( $atts['url'], 'vimeo' ) !== false ) return Nx_Shortcodes::vimeo( $atts );
		// Image
		else return '<img src="' . $atts['url'] . '" width="' . $atts['width'] . '" height="' . $atts['height'] . '" style="max-width:100%" />';
	}

	public static function youtube( $atts = null, $content = null ) {
		// Prepare data
		$return = array();
		$atts = shortcode_atts( array(
				'url'        => false,
				'width'      => 600,
				'height'     => 400,
				'autoplay'   => 'no',
				'responsive' => 'yes',
				'class'      => ''
			), $atts, 'youtube' );
		if ( !$atts['url'] ) return '<p class="nx-error">YouTube: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		$id = ( preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $atts['url'], $match ) ) ? $match[1] : false;
		// Check that url is specified
		if ( !$id ) return '<p class="nx-error">YouTube: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Prepare autoplay
		$autoplay = ( $atts['autoplay'] === 'yes' ) ? '?autoplay=1' : '';
		// Create player
		$return[] = '<div class="nx-youtube nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '">';
		$return[] = '<iframe width="' . $atts['width'] . '" height="' . $atts['height'] . '" src="http://www.youtube.com/embed/' . $id . $autoplay . '" frameborder="0" allowfullscreen="true"></iframe>';
		$return[] = '</div>';
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		// Return result
		return implode( '', $return );
	}

	public static function youtube_advanced( $atts = null, $content = null ) {
		// Prepare data
		$return = array();
		$params = array();
		$atts = shortcode_atts( array(
				'url'            => false,
				'width'          => 600,
				'height'         => 400,
				'responsive'     => 'yes',
				'autohide'       => 'alt',
				'autoplay'       => 'no',
				'controls'       => 'yes',
				'fs'             => 'yes',
				'loop'           => 'no',
				'modestbranding' => 'no',
				'playlist'       => '',
				'rel'            => 'yes',
				'showinfo'       => 'yes',
				'theme'          => 'dark',
				'https'          => 'no',
				'class'          => ''
			), $atts, 'youtube_advanced' );
		if ( !$atts['url'] ) return '<p class="nx-error">YouTube: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		$id = ( preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $atts['url'], $match ) ) ? $match[1] : false;
		// Check that url is specified
		if ( !$id ) return '<p class="nx-error">YouTube: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Prepare params
		foreach ( array( 'autohide', 'autoplay', 'controls', 'fs', 'loop', 'modestbranding', 'playlist', 'rel', 'showinfo', 'theme' ) as $param ) $params[$param] = str_replace( array( 'no', 'yes', 'alt' ), array( '0', '1', '2' ), $atts[$param] );
		// Correct loop
		if ( $params['loop'] === '1' && $params['playlist'] === '' ) $params['playlist'] = $id;
		// Prepare protocol
		$protocol = ( $atts['https'] === 'yes' ) ? 'https' : 'http';
		// Prepare player parameters
		$params = http_build_query( $params );
		// Create player
		$return[] = '<div class="nx-youtube nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '">';
		$return[] = '<iframe width="' . $atts['width'] . '" height="' . $atts['height'] . '" src="' . $protocol . '://www.youtube.com/embed/' . $id . '?' . $params . '" frameborder="0" allowfullscreen="true"></iframe>';
		$return[] = '</div>';
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		// Return result
		return implode( '', $return );
	}

	public static function vimeo( $atts = null, $content = null ) {
		// Prepare data
		$return = array();
		$atts = shortcode_atts( array(
				'url'        => false,
				'width'      => 600,
				'height'     => 400,
				'autoplay'   => 'no',
				'responsive' => 'yes',
				'class'      => ''
			), $atts, 'vimeo' );
		if ( !$atts['url'] ) return '<p class="nx-error">Vimeo: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		$id = ( preg_match( '~(?:<iframe [^>]*src=")?(?:https?:\/\/(?:[\w]+\.)*vimeo\.com(?:[\/\w]*\/videos?)?\/([0-9]+)[^\s]*)"?(?:[^>]*></iframe>)?(?:<p>.*</p>)?~ix', $atts['url'], $match ) ) ? $match[1] : false;
		// Check that url is specified
		if ( !$id ) return '<p class="nx-error">Vimeo: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Prepare autoplay
		$autoplay = ( $atts['autoplay'] === 'yes' ) ? '&amp;autoplay=1' : '';
		// Create player
		$return[] = '<div class="nx-vimeo nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '">';
		$return[] = '<iframe width="' . $atts['width'] . '" height="' . $atts['height'] .
			'" src="http://player.vimeo.com/video/' . $id . '?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff' .
			$autoplay . '" frameborder="0" allowfullscreen="true"></iframe>';
		$return[] = '</div>';
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		// Return result
		return implode( '', $return );
	}

	public static function screenr( $atts = null, $content = null ) {
		// Prepare data
		$return = array();
		$atts = shortcode_atts( array(
				'url'        => false,
				'width'      => 600,
				'height'     => 400,
				'responsive' => 'yes',
				'class'      => ''
			), $atts, 'screenr' );
		if ( !$atts['url'] ) return '<p class="nx-error">Screenr: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		$id = ( preg_match( '~(?:<iframe [^>]*src=")?(?:https?:\/\/(?:[\w]+\.)*screenr\.com(?:[\/\w]*\/videos?)?\/([a-zA-Z0-9]+)[^\s]*)"?(?:[^>]*></iframe>)?(?:<p>.*</p>)?~ix', $atts['url'], $match ) ) ? $match[1] : false;
		// Check that url is specified
		if ( !$id ) return '<p class="nx-error">Screenr: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Create player
		$return[] = '<div class="nx-screenr nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '">';
		$return[] = '<iframe width="' . $atts['width'] . '" height="' . $atts['height'] . '" src="http://screenr.com/embed/' . $id . '" frameborder="0" allowfullscreen="true"></iframe>';
		$return[] = '</div>';
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		// Return result
		return implode( '', $return );
	}

	public static function dailymotion( $atts = null, $content = null ) {
		// Prepare data
		$return = array();
		$atts = shortcode_atts( array(
				'url'        => false,
				'width'      => 600,
				'height'     => 400,
				'responsive' => 'yes',
				'autoplay'   => 'no',
				'background' => '#FFC300',
				'foreground' => '#F7FFFD',
				'highlight'  => '#171D1B',
				'logo'       => 'yes',
				'quality'    => '380',
				'related'    => 'yes',
				'info'       => 'yes',
				'class'      => ''
			), $atts, 'dailymotion' );
		if ( !$atts['url'] ) return '<p class="nx-error">Dailymotion: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		$id = strtok( basename( $atts['url'] ), '_' );
		// Check that url is specified
		if ( !$id ) return '<p class="nx-error">Dailymotion: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Prepare params
		$params = array();
		foreach ( array( 'autoplay', 'background', 'foreground', 'highlight', 'logo', 'quality', 'related', 'info' ) as $param )
			$params[] = $param . '=' . str_replace( array( 'yes', 'no', '#' ), array( '1', '0', '' ), $atts[$param] );
		// Create player
		$return[] = '<div class="nx-dailymotion nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '">';
		$return[] = '<iframe width="' . $atts['width'] . '" height="' . $atts['height'] . '" src="http://www.dailymotion.com/embed/video/' . $id . '?' . implode( '&', $params ) . '" frameborder="0" allowfullscreen="true"></iframe>';
		$return[] = '</div>';
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		// Return result
		return implode( '', $return );
	}

	public static function audio( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'      => false,
				'width'    => 'auto',
				'title'    => '',
				'autoplay' => 'no',
				'loop'     => 'no',
				'class'    => ''
			), $atts, 'audio' );
		if ( !$atts['url'] ) return '<p class="nx-error">Audio: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		// Generate unique ID
		$id = uniqid( 'nx_audio_player_' );
		// Prepare width
		$width = ( $atts['width'] !== 'auto' ) ? 'max-width:' . $atts['width'] : '';
		// Check that url is specified
		if ( !$atts['url'] ) return '<p class="nx-error">Audio: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		nx_query_asset( 'css', 'nx-players-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'jplayer' );
		nx_query_asset( 'js', 'nx-players-shortcodes' );
		nx_query_asset( 'js', 'nx-players-shortcodes' );
		// Create player
		return '<div class="nx-audio' . nx_ecssc( $atts ) . '" data-id="' . $id . '" data-audio="' . $atts['url'] . '" data-swf="' . plugins_url( 'assets/other/Jplayer.swf', NX_PLUGIN_FILE ) . '" data-autoplay="' . $atts['autoplay'] . '" data-loop="' . $atts['loop'] . '" style="' . $width . '"><div id="' . $id . '" class="jp-jplayer"></div><div id="' . $id . '_container" class="jp-audio"><div class="jp-type-single"><div class="jp-gui jp-interface"><div class="jp-controls"><span class="jp-play"></span><span class="jp-pause"></span><span class="jp-stop"></span><span class="jp-mute"></span><span class="jp-unmute"></span><span class="jp-volume-max"></span></div><div class="jp-progress"><div class="jp-seek-bar"><div class="jp-play-bar"></div></div></div><div class="jp-volume-bar"><div class="jp-volume-bar-value"></div></div><div class="jp-current-time"></div><div class="jp-duration"></div></div><div class="jp-title">' . $atts['title'] . '</div></div></div></div>';
	}

	public static function video( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'      => false,
				'poster'   => false,
				'title'    => '',
				'width'    => 600,
				'height'   => 300,
				'controls' => 'yes',
				'autoplay' => 'no',
				'loop'     => 'no',
				'class'    => ''
			), $atts, 'video' );
		if ( !$atts['url'] ) return '<p class="nx-error">Video: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		$atts['url'] = nx_scattr( $atts['url'] );
		// Generate unique ID
		$id = uniqid( 'nx_video_player_' );
		// Check that url is specified
		if ( !$atts['url'] ) return '<p class="nx-error">Video: ' . __( 'please specify correct url', 'nx' ) . '</p>';
		// Prepare title
		$title = ( $atts['title'] ) ? '<div class="jp-title">' . $atts['title'] . '</div>' : '';
		nx_query_asset( 'css', 'nx-players-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'jplayer' );
		nx_query_asset( 'js', 'nx-players-shortcodes' );
		// Create player
		return '<div style="width:' . $atts['width'] . 'px"><div id="' . $id . '" class="nx-video jp-video nx-video-controls-' . $atts['controls'] . nx_ecssc( $atts ) . '" data-id="' . $id . '" data-video="' . $atts['url'] . '" data-swf="' . plugins_url( 'assets/other/Jplayer.swf', NX_PLUGIN_FILE ) . '" data-autoplay="' . $atts['autoplay'] . '" data-loop="' . $atts['loop'] . '" data-poster="' . $atts['poster'] . '"><div id="' . $id . '_player" class="jp-jplayer" style="width:' . $atts['width'] . 'px;height:' . $atts['height'] . 'px"></div>' . $title . '<div class="jp-start jp-play"></div><div class="jp-gui"><div class="jp-interface"><div class="jp-progress"><div class="jp-seek-bar"><div class="jp-play-bar"></div></div></div><div class="jp-current-time"></div><div class="jp-duration"></div><div class="jp-controls-holder"><span class="jp-play"></span><span class="jp-pause"></span><span class="jp-mute"></span><span class="jp-unmute"></span><span class="jp-full-screen"></span><span class="jp-restore-screen"></span><div class="jp-volume-bar"><div class="jp-volume-bar-value"></div></div></div></div></div></div></div>';
	}

	public static function table( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'   => false,
				'class' => ''
			), $atts, 'table' );
		$return = '<div class="nx-table' . nx_ecssc( $atts ) . '">';
		$return .= ( $atts['url'] ) ? nx_parse_csv( $atts['url'] ) : do_shortcode( $content );
		$return .= '</div>';
		nx_query_asset( 'css', 'nx-content-shortcodes' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		return $return;
	}

	public static function permalink( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'id' => 1,
				'p' => null, // 3.x
				'target' => 'self',
				'class' => ''
			), $atts, 'permalink' );
		if ( $atts['p'] !== null ) $atts['id'] = $atts['p'];
		$atts['id'] = nx_scattr( $atts['id'] );
		// Prepare link text
		$text = ( $content ) ? $content : get_the_title( $atts['id'] );
		return '<a href="' . get_permalink( $atts['id'] ) . '" class="' . nx_ecssc( $atts ) . '" title="' . $text . '" target="_' . $atts['target'] . '">' . $text . '</a>';
	}

	public static function members( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'message'    => __( 'This content is for registered users only. Please %login%.', 'nx' ),
				'color'      => '#ffcc00',
				'style'      => null, // 3.x
				'login_text' => __( 'login', 'nx' ),
				'login_url'  => wp_login_url(),
				'login'      => null, // 3.x
				'class'      => ''
			), $atts, 'members' );
		if ( $atts['style'] !== null ) $atts['color'] = str_replace( array( '0', '1', '2' ), array( '#fff', '#FFFF29', '#1F9AFF' ), $atts['style'] );
		// Check feed
		if ( is_feed() ) return;
		// Check authorization
		if ( !is_user_logged_in() ) {
			if ( $atts['login'] !== null && $atts['login'] == '0' ) return; // 3.x
			// Prepare login link
			$login = '<a href="' . esc_attr( $atts['login_url'] ) . '">' . $atts['login_text'] . '</a>';
			nx_query_asset( 'css', 'nx-other-shortcodes' );
			return '<div class="nx-members' . nx_ecssc( $atts ) . '" style="background-color:' . nx_hex_shift( $atts['color'], 'lighter', 50 ) . ';border-color:' .nx_hex_shift( $atts['color'], 'darker', 20 ) . ';color:' .nx_hex_shift( $atts['color'], 'darker', 60 ) . '">' . str_replace( '%login%', $login, nx_scattr( $atts['message'] ) ) . '</div>';
		}
		// Return original content
		else return do_shortcode( $content );
	}

	public static function guests( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 'class' => '' ), $atts, 'guests' );
		$return = '';
		if ( !is_user_logged_in() && !is_null( $content ) ) {
			nx_query_asset( 'css', 'nx-other-shortcodes' );
			$return = '<div class="nx-guests' . nx_ecssc( $atts ) . '">' . do_shortcode( $content ) . '</div>';
		}
		return $return;
	}

	public static function feed( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'   => get_bloginfo_rss( 'rss2_url' ),
				'limit' => 3,
				'class' => ''
			), $atts, 'feed' );
		if ( !function_exists( 'wp_rss' ) ) include_once ABSPATH . WPINC . '/rss.php';
		ob_start();
		echo '<div class="nx-feed' . nx_ecssc( $atts ) . '">';
		wp_rss( $atts['url'], $atts['limit'] );
		echo '</div>';
		$return = ob_get_contents();
		ob_end_clean();
		return $return;
	}

	public static function subpages( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'depth' => 1,
				'p'     => false,
				'class' => ''
			), $atts, 'subpages' );
		global $post;
		$child_of = ( $atts['p'] ) ? $atts['p'] : get_the_ID();
		$return = wp_list_pages( array(
				'title_li' => '',
				'echo' => 0,
				'child_of' => $child_of,
				'depth' => $atts['depth']
			) );
		return ( $return ) ? '<ul class="nx-subpages' . nx_ecssc( $atts ) . '">' . $return . '</ul>' : false;
	}

	public static function siblings( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 'depth' => 1, 'class' => '' ), $atts, 'siblings' );
		global $post;
		$return = wp_list_pages( array( 'title_li' => '',
				'echo' => 0,
				'child_of' => $post->post_parent,
				'depth' => $atts['depth'],
				'exclude' => $post->ID ) );
		return ( $return ) ? '<ul class="nx-siblings' . nx_ecssc( $atts ) . '">' . $return . '</ul>' : false;
	}

	public static function menu( $atts = null, $content = null ) {
		$atts = shortcode_atts( array( 'name' => false, 'class' => '' ), $atts, 'menu' );
		$return = wp_nav_menu( array(
				'echo'        => false,
				'menu'        => $atts['name'],
				'container'   => false,
				'fallback_cb' => array( __CLASS__, 'menu_fb' ),
				'class'       => $atts['class']
			) );
		return ( $atts['name'] ) ? $return : false;
	}

	public static function menu_fb() {
		return __( 'This menu doesn\'t exists, or has no elements', 'nx' );
	}

	public static function document( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'url'        => '',
				'file'       => null, // 3.x
				'width'      => 600,
				'height'     => 400,
				'responsive' => 'yes',
				'class'      => ''
			), $atts, 'document' );
		if ( $atts['file'] !== null ) $atts['url'] = $atts['file'];
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		return '<div class="nx-document nx-responsive-media-' . $atts['responsive'] . '"><iframe src="http://docs.google.com/viewer?embedded=true&url=' . $atts['url'] . '" width="' . $atts['width'] . '" height="' . $atts['height'] . '" class="nx-document' . nx_ecssc( $atts ) . '"></iframe></div>';
	}

	public static function gmap( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'width'      => 600,
				'height'     => 400,
				'fullwidth'  => 'yes',				
				'responsive' => 'yes',
				'address'    => 'New York',
				'class'      => ''
			), $atts, 'gmap' );
			
			$nx_classes = "";
		
			if ( $atts['fullwidth'] == 'yes')
			{
				$nx_classes .="fullwidthrow ";
			}
			
						
		nx_query_asset( 'css', 'nx-media-shortcodes' );
		return '<div class="row '. $nx_classes .'"><div class="nx-gmap nx-responsive-media-' . $atts['responsive'] . nx_ecssc( $atts ) . '" style="padding-bottom: ' . $atts['height'] . 'px"><iframe width="' . $atts['width'] . '" height="' . $atts['height'] . '" src="http://maps.google.com/maps?q=' . urlencode( nx_scattr( $atts['address'] ) ) . '&amp;output=embed&amp;noscroll=1"></iframe></div></div>';
	}

	public static function slider( $atts = null, $content = null ) {
		$return = '';
		$atts = shortcode_atts( array(
				'source'     => 'none',
				'limit'      => 20,
				'gallery'    => null, // Dep. 4.3.2
				'link'       => 'none',
				'target'     => 'self',
				'width'      => 600,
				'height'     => 300,
				'responsive' => 'yes',
				'title'      => 'yes',
				'centered'   => 'yes',
				'arrows'     => 'yes',
				'pages'      => 'yes',
				'mousewheel' => 'yes',
				'autoplay'   => 6000,
				'speed'      => 600,
				'class'      => ''
			), $atts, 'slider' );
		// Get slides
		$slides = (array) Nx_Tools::get_slides( $atts );
		// Loop slides
		if ( count( $slides ) ) {
			// Prepare unique ID
			$id = uniqid( 'nx_slider_' );
			// Links target
			$target = ( $atts['target'] === 'yes' || $atts['target'] === 'blank' ) ? ' target="_blank"' : '';
			// Centered class
			$centered = ( $atts['centered'] === 'yes' ) ? ' nx-slider-centered' : '';
			// Wheel control
			$mousewheel = ( $atts['mousewheel'] === 'yes' ) ? 'true' : 'false';
			// Prepare width and height
			$size = ( $atts['responsive'] === 'yes' ) ? 'width:100%' : 'width:' . intval( $atts['width'] ) . 'px;height:' . intval( $atts['height'] ) . 'px';
			// Add lightbox class
			if ( $atts['link'] === 'lightbox' ) $atts['class'] .= ' nx-lightbox-gallery';
			// Open slider
			$return .= '<div id="' . $id . '" class="nx-slider' . $centered . ' nx-slider-pages-' . $atts['pages'] . ' nx-slider-responsive-' . $atts['responsive'] . nx_ecssc( $atts ) . '" style="' . $size . '" data-autoplay="' . $atts['autoplay'] . '" data-speed="' . $atts['speed'] . '" data-mousewheel="' . $mousewheel . '"><div class="nx-slider-slides">';
			// Create slides
			foreach ( $slides as $slide ) {
				// Crop the image
				$image = nx_image_resize( $slide['image'], $atts['width'], $atts['height'] );
				// Prepare slide title
				$title = ( $atts['title'] === 'yes' && $slide['title'] ) ? '<span class="nx-slider-slide-title">' . stripslashes( $slide['title'] ) . '</span>' : '';
				// Open slide
				$return .= '<div class="nx-slider-slide">';
				// Slide content with link
				if ( $slide['link'] ) $return .= '<a href="' . $slide['link'] . '"' . $target . '><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" />' . $title . '</a>';
				// Slide content without link
				else $return .= '<a><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" />' . $title . '</a>';
				// Close slide
				$return .= '</div>';
			}
			// Close slides
			$return .= '</div>';
			// Open nav section
			$return .= '<div class="nx-slider-nav">';
			// Append direction nav
			if ( $atts['arrows'] === 'yes'
			) $return .= '<div class="nx-slider-direction"><span class="nx-slider-prev"></span><span class="nx-slider-next"></span></div>';
			// Append pagination nav
			$return .= '<div class="nx-slider-pagination"></div>';
			// Close nav section
			$return .= '</div>';
			// Close slider
			$return .= '</div>';
			// Add lightbox assets
			if ( $atts['link'] === 'lightbox' ) {
				nx_query_asset( 'css', 'magnific-popup' );
				nx_query_asset( 'js', 'magnific-popup' );
			}
			nx_query_asset( 'css', 'nx-galleries-shortcodes' );
			nx_query_asset( 'js', 'jquery' );
			nx_query_asset( 'js', 'swiper' );
			nx_query_asset( 'js', 'nx-galleries-shortcodes' );
		}
		// Slides not found
		else $return = '<p class="nx-error">Slider: ' . __( 'images not found', 'nx' ) . '</p>';
		return $return;
	}

	public static function carousel( $atts = null, $content = null ) {
		$return = '';
		$atts = shortcode_atts( array(
				'source'     => 'none',
				'limit'      => 20,
				'gallery'    => null, // Dep. 4.3.2
				'link'       => 'none',
				'target'     => 'self',
				'width'      => 600,
				'height'     => 100,
				'responsive' => 'yes',
				'items'      => 3,
				'scroll'     => 1,
				'title'      => 'yes',
				'centered'   => 'yes',
				'arrows'     => 'yes',
				'pages'      => 'no',
				'mousewheel' => 'yes',
				'autoplay'   => 3000,
				'speed'      => 600,
				'class'      => ''
			), $atts, 'carousel' );
		// Get slides
		$slides = (array) Nx_Tools::get_slides( $atts );
		// Loop slides
		if ( count( $slides ) ) {
			// Prepare unique ID
			$id = uniqid( 'nx_carousel_' );
			// Links target
			$target = ( $atts['target'] === 'yes' || $atts['target'] === 'blank' ) ? ' target="_blank"' : '';
			// Centered class
			$centered = ( $atts['centered'] === 'yes' ) ? ' nx-carousel-centered' : '';
			// Wheel control
			$mousewheel = ( $atts['mousewheel'] === 'yes' ) ? 'true' : 'false';
			// Prepare width and height
			$size = ( $atts['responsive'] === 'yes' ) ? 'width:100%' : 'width:' . intval( $atts['width'] ) . 'px;height:' . intval( $atts['height'] ) . 'px';
			// Add lightbox class
			if ( $atts['link'] === 'lightbox' ) $atts['class'] .= ' nx-lightbox-gallery';
			// Open slider
			$return .= '<div id="' . $id . '" class="nx-carousel' . $centered . ' nx-carousel-pages-' . $atts['pages'] . ' nx-carousel-responsive-' . $atts['responsive'] . nx_ecssc( $atts ) . '" style="' . $size . '" data-autoplay="' . $atts['autoplay'] . '" data-speed="' . $atts['speed'] . '" data-mousewheel="' . $mousewheel . '" data-items="' . $atts['items'] . '" data-scroll="' . $atts['scroll'] . '"><div class="nx-carousel-slides">';
			// Create slides
			foreach ( (array) $slides as $slide ) {
				// Crop the image
				$image = nx_image_resize( $slide['image'], round( $atts['width'] / $atts['items'] ), $atts['height'] );
				// Prepare slide title
				$title = ( $atts['title'] === 'yes' && $slide['title'] ) ? '<span class="nx-carousel-slide-title">' . stripslashes( $slide['title'] ) . '</span>' : '';
				// Open slide
				$return .= '<div class="nx-carousel-slide">';
				// Slide content with link
				if ( $slide['link'] ) $return .= '<a href="' . $slide['link'] . '"' . $target . '><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" />' . $title . '</a>';
				// Slide content without link
				else $return .= '<a><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" />' . $title . '</a>';
				// Close slide
				$return .= '</div>';
			}
			// Close slides
			$return .= '</div>';
			// Open nav section
			$return .= '<div class="nx-carousel-nav">';
			// Append direction nav
			if ( $atts['arrows'] === 'yes'
			) $return .= '<div class="nx-carousel-direction"><span class="nx-carousel-prev"></span><span class="nx-carousel-next"></span></div>';
			// Append pagination nav
			$return .= '<div class="nx-carousel-pagination"></div>';
			// Close nav section
			$return .= '</div>';
			// Close slider
			$return .= '</div>';
			// Add lightbox assets
			if ( $atts['link'] === 'lightbox' ) {
				nx_query_asset( 'css', 'magnific-popup' );
				nx_query_asset( 'js', 'magnific-popup' );
			}
			nx_query_asset( 'css', 'nx-galleries-shortcodes' );
			nx_query_asset( 'js', 'jquery' );
			nx_query_asset( 'js', 'swiper' );
			nx_query_asset( 'js', 'nx-galleries-shortcodes' );
		}
		// Slides not found
		else $return = '<p class="nx-error">Carousel: ' . __( 'images not found', 'nx' ) . '</p>';
		return $return;
	}

	public static function custom_gallery( $atts = null, $content = null ) {
		$return = '';
		$atts = shortcode_atts( array(
				'source'  => 'none',
				'limit'   => 20,
				'gallery' => null, // Dep. 4.4.0
				'link'    => 'none',
				'width'   => 90,
				'height'  => 90,
				'title'   => 'hover',
				'target'  => 'self',
				'class'   => ''
			), $atts, 'custom_gallery' );
		$slides = (array) Nx_Tools::get_slides( $atts );
		// Loop slides
		if ( count( $slides ) ) {
			// Prepare links target
			$atts['target'] = ( $atts['target'] === 'yes' || $atts['target'] === 'blank' ) ? ' target="_blank"' : '';
			// Add lightbox class
			if ( $atts['link'] === 'lightbox' ) $atts['class'] .= ' nx-lightbox-gallery';
			// Open gallery
			$return = '<div class="nx-custom-gallery nx-custom-gallery-title-' . $atts['title'] . nx_ecssc( $atts ) . '">';
			// Create slides
			foreach ( $slides as $slide ) {
				// Crop image
				$image = nx_image_resize( $slide['image'], $atts['width'], $atts['height'] );
				// Prepare slide title
				$title = ( $slide['title'] ) ? '<span class="nx-custom-gallery-title">' . stripslashes( $slide['title'] ) . '</span>' : '';
				// Open slide
				$return .= '<div class="nx-custom-gallery-slide">';
				// Slide content with link
				if ( $slide['link'] ) $return .= '<a href="' . $slide['link'] . '"' . $atts['target'] . '><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" width="' . $atts['width'] . '" height="' . $atts['height'] . '" />' . $title . '</a>';
				// Slide content without link
				else $return .= '<a><img src="' . $image['url'] . '" alt="' . esc_attr( $slide['title'] ) . '" width="' . $atts['width'] . '" height="' . $atts['height'] . '" />' . $title . '</a>';
				// Close slide
				$return .= '</div>';
			}
			// Clear floats
			$return .= '<div class="nx-clear"></div>';
			// Close gallery
			$return .= '</div>';
			// Add lightbox assets
			if ( $atts['link'] === 'lightbox' ) {
				nx_query_asset( 'css', 'magnific-popup' );
				nx_query_asset( 'js', 'jquery' );
				nx_query_asset( 'js', 'magnific-popup' );
				nx_query_asset( 'js', 'nx-galleries-shortcodes' );
			}
			nx_query_asset( 'css', 'nx-galleries-shortcodes' );
		}
		// Slides not found
		else $return = '<p class="nx-error">Custom gallery: ' . __( 'images not found', 'nx' ) . '</p>';
		return $return;
	}

	/*
	public static function posts( $atts = null, $content = null ) {
		// Prepare error var
		$error = null;
		// Parse attributes
		$atts = shortcode_atts( array(
				'template'            => 'templates/default-loop.php',
				'id'                  => false,
				'posts_per_page'      => get_option( 'posts_per_page' ),
				'post_type'           => 'post',
				'taxonomy'            => 'category',
				'tax_term'            => false,
				'tax_operator'        => 'IN',
				'author'              => '',
				'tag'                 => '',
				'meta_key'            => '',
				'offset'              => 0,
				'order'               => 'DESC',
				'orderby'             => 'date',
				'post_parent'         => false,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => 'no'
			), $atts, 'posts' );

		$original_atts = $atts;

		$author = sanitize_text_field( $atts['author'] );
		$id = $atts['id']; // Sanitized later as an array of integers
		$ignore_sticky_posts = ( bool ) ( $atts['ignore_sticky_posts'] === 'yes' ) ? true : false;
		$meta_key = sanitize_text_field( $atts['meta_key'] );
		$offset = intval( $atts['offset'] );
		$order = sanitize_key( $atts['order'] );
		$orderby = sanitize_key( $atts['orderby'] );
		$post_parent = $atts['post_parent'];
		$post_status = $atts['post_status'];
		$post_type = sanitize_text_field( $atts['post_type'] );
		$posts_per_page = intval( $atts['posts_per_page'] );
		$tag = sanitize_text_field( $atts['tag'] );
		$tax_operator = $atts['tax_operator'];
		$tax_term = sanitize_text_field( $atts['tax_term'] );
		$taxonomy = sanitize_key( $atts['taxonomy'] );
		// Set up initial query for post
		$args = array(
			'category_name'  => '',
			'order'          => $order,
			'orderby'        => $orderby,
			'post_type'      => explode( ',', $post_type ),
			'posts_per_page' => $posts_per_page,
			'tag'            => $tag
		);
		// Ignore Sticky Posts
		if ( $ignore_sticky_posts ) $args['ignore_sticky_posts'] = true;
		// Meta key (for ordering)
		if ( !empty( $meta_key ) ) $args['meta_key'] = $meta_key;
		// If Post IDs
		if ( $id ) {
			$posts_in = array_map( 'intval', explode( ',', $id ) );
			$args['post__in'] = $posts_in;
		}
		// Post Author
		if ( !empty( $author ) ) $args['author'] = $author;
		// Offset
		if ( !empty( $offset ) ) $args['offset'] = $offset;
		// Post Status
		$post_status = explode( ', ', $post_status );
		$validated = array();
		$available = array( 'publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit', 'trash', 'any' );
		foreach ( $post_status as $unvalidated ) {
			if ( in_array( $unvalidated, $available ) ) $validated[] = $unvalidated;
		}
		if ( !empty( $validated ) ) $args['post_status'] = $validated;
		// If taxonomy attributes, create a taxonomy query
		if ( !empty( $taxonomy ) && !empty( $tax_term ) ) {
			// Term string to array
			$tax_term = explode( ',', $tax_term );
			// Validate operator
			if ( !in_array( $tax_operator, array( 'IN', 'NOT IN', 'AND' ) ) ) $tax_operator = 'IN';
			$tax_args = array( 'tax_query' => array( array(
						'taxonomy' => $taxonomy,
						'field' => ( is_numeric( $tax_term[0] ) ) ? 'id' : 'slug',
						'terms' => $tax_term,
						'operator' => $tax_operator ) ) );
			// Check for multiple taxonomy queries
			$count = 2;
			$more_tax_queries = false;
			while ( isset( $original_atts['taxonomy_' . $count] ) && !empty( $original_atts['taxonomy_' . $count] ) &&
				isset( $original_atts['tax_' . $count . '_term'] ) &&
				!empty( $original_atts['tax_' . $count . '_term'] ) ) {
				// Sanitize values
				$more_tax_queries = true;
				$taxonomy = sanitize_key( $original_atts['taxonomy_' . $count] );
				$terms = explode( ', ', sanitize_text_field( $original_atts['tax_' . $count . '_term'] ) );
				$tax_operator = isset( $original_atts['tax_' . $count . '_operator'] ) ? $original_atts[
				'tax_' . $count . '_operator'] : 'IN';
				$tax_operator = in_array( $tax_operator, array( 'IN', 'NOT IN', 'AND' ) ) ? $tax_operator : 'IN';
				$tax_args['tax_query'][] = array( 'taxonomy' => $taxonomy,
					'field' => 'slug',
					'terms' => $terms,
					'operator' => $tax_operator );
				$count++;
			}
			if ( $more_tax_queries ):
				$tax_relation = 'AND';
			if ( isset( $original_atts['tax_relation'] ) &&
				in_array( $original_atts['tax_relation'], array( 'AND', 'OR' ) )
			) $tax_relation = $original_atts['tax_relation'];
			$args['tax_query']['relation'] = $tax_relation;
			endif;
			$args = array_merge( $args, $tax_args );
		}

		// If post parent attribute, set up parent
		if ( $post_parent ) {
			if ( 'current' == $post_parent ) {
				global $post;
				$post_parent = $post->ID;
			}
			$args['post_parent'] = intval( $post_parent );
		}
		// Save original posts
		global $posts;
		$original_posts = $posts;
		// Query posts
		$posts = new WP_Query( $args );
		// Buffer output
		ob_start();
		// Search for template in stylesheet directory
		if ( file_exists( STYLESHEETPATH . '/' . $atts['template'] ) ) load_template( STYLESHEETPATH . '/' . $atts['template'], false );
		// Search for template in theme directory
		elseif ( file_exists( TEMPLATEPATH . '/' . $atts['template'] ) ) load_template( TEMPLATEPATH . '/' . $atts['template'], false );
		// Search for template in plugin directory
		elseif ( path_join( dirname( NX_PLUGIN_FILE ), $atts['template'] ) ) load_template( path_join( dirname( NX_PLUGIN_FILE ), $atts['template'] ), false );
		// Template not found
		else echo '<p class="nx-error">Posts: ' . __( 'template not found', 'nx' ) . '</p>';
		$output = ob_get_contents();
		ob_end_clean();
		// Return original posts
		$posts = $original_posts;
		// Reset the query
		wp_reset_postdata();
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		return $output;
	}
	*/

	public static function dummy_text( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'amount' => 1,
				'what'   => 'paras',
				'cache'  => 'yes',
				'class'  => ''
			), $atts, 'dummy_text' );
		$transient = 'nx/cache/dummy_text/' . sanitize_text_field( $atts['what'] ) . '/' . intval( $atts['amount'] );
		$return = get_transient( $transient );
		if ( $return && $atts['cache'] === 'yes' && NX_ENABLE_CACHE ) return $return;
		else {
			$xml = simplexml_load_file( 'http://www.lipsum.com/feed/xml?amount=' . $atts['amount'] . '&what=' . $atts['what'] . '&start=0' );
			$return = '<div class="nx-dummy-text' . nx_ecssc( $atts ) . '">' . wpautop( str_replace( "\n", "\n\n", $xml->lipsum ) ) . '</div>';
			set_transient( $transient, $return, 60*60*24*30 );
			return $return;
		}
	}

	public static function dummy_image( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'width'  => 500,
				'height' => 300,
				'theme'  => 'any',
				'class'  => ''
			), $atts, 'dummy_image' );
		$url = 'http://lorempixel.com/' . $atts['width'] . '/' . $atts['height'] . '/';
		if ( $atts['theme'] !== 'any' ) $url .= $atts['theme'] . '/' . rand( 0, 10 ) . '/';
		return '<img src="' . $url . '" alt="' . __( 'Dummy image', 'nx' ) . '" width="' . $atts['width'] . '" height="' . $atts['height'] . '" class="nx-dummy-image' . nx_ecssc( $atts ) . '" />';
	}

	public static function animate( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'type'      => 'bounceIn',
				'duration'  => 1,
				'delay'     => 0,
				'inline'    => 'no',
				'class'     => ''
			), $atts, 'animate' );
		$tag = ( $atts['inline'] === 'yes' ) ? 'span' : 'div';
		$style = array(
			'duration' => array(),
			'delay' => array()
		);
		foreach ( array( '-webkit-', '-moz-', '-ms-', '-o-', '' ) as $vendor ) {
			$style['duration'][] = $vendor . 'animation-duration:' . $atts['duration'] . 's';
			$style['delay'][] = $vendor . 'animation-delay:' . $atts['delay'] . 's';
		}
		$return = '<' . $tag . ' class="nx-animate ' . nx_ecssc( $atts ) . '" style="visibility:hidden;' . implode( ';', $style['duration'] ) . ';' . implode( ';', $style['delay'] ) . '" data-animation="' . $atts['type'] . '" data-animation-duration="' . $atts['duration'] . '">' . do_shortcode( $content ) . '</' . $tag . '>';
		nx_query_asset( 'css', 'animate' );
		nx_query_asset( 'js', 'jquery' );
		nx_query_asset( 'js', 'inview' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		return $return;
	}

	public static function meta( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'key'     => '',
				'default' => '',
				'before'  => '',
				'after'   => '',
				'post_id' => '',
				'filter'  => ''
			), $atts, 'meta' );
		// Define current post ID
		if ( !$atts['post_id'] ) $atts['post_id'] = get_the_ID();
		// Check post ID
		if ( !is_numeric( $atts['post_id'] ) || $atts['post_id'] < 1 ) return sprintf( '<p class="nx-error">Meta: %s</p>', __( 'post ID is incorrect', 'nx' ) );
		// Check key name
		if ( !$atts['key'] ) return sprintf( '<p class="nx-error">Meta: %s</p>', __( 'please specify meta key name', 'nx' ) );
		// Get the meta
		$meta = get_post_meta( $atts['post_id'], $atts['key'], true );
		// Set default value if meta is empty
		if ( !$meta ) $meta = $atts['default'];
		// Apply cutom filter
		if ( $atts['filter'] && function_exists( $atts['filter'] ) ) $meta = call_user_func( $atts['filter'], $meta );
		// Return result
		return ( $meta ) ? $atts['before'] . $meta . $atts['after'] : '';
	}

	public static function user( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'field'   => 'display_name',
				'default' => '',
				'before'  => '',
				'after'   => '',
				'user_id' => '',
				'filter'  => ''
			), $atts, 'user' );
		// Check for password requests
		if ( $atts['field'] === 'user_pass' ) return sprintf( '<p class="nx-error">User: %s</p>', __( 'password field is not allowed', 'nx' ) );
		// Define current user ID
		if ( !$atts['user_id'] ) $atts['user_id'] = get_current_user_id();
		// Check user ID
		if ( !is_numeric( $atts['user_id'] ) || $atts['user_id'] < 1 ) return sprintf( '<p class="nx-error">User: %s</p>', __( 'user ID is incorrect', 'nx' ) );
		// Get user data
		$user = get_user_by( 'id', $atts['user_id'] );
		// Get user data if user was found
		$user = ( $user && isset( $user->data->$atts['field'] ) ) ? $user->data->$atts['field'] : $atts['default'];
		// Apply cutom filter
		if ( $atts['filter'] && function_exists( $atts['filter'] ) ) $user = call_user_func( $atts['filter'], $user );
		// Return result
		return ( $user ) ? $atts['before'] . $user . $atts['after'] : '';
	}

	public static function post( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'field'   => 'post_title',
				'default' => '',
				'before'  => '',
				'after'   => '',
				'post_id' => '',
				'filter'  => ''
			), $atts, 'post' );
		// Define current post ID
		if ( !$atts['post_id'] ) $atts['post_id'] = get_the_ID();
		// Check post ID
		if ( !is_numeric( $atts['post_id'] ) || $atts['post_id'] < 1 ) return sprintf( '<p class="nx-error">Post: %s</p>', __( 'post ID is incorrect', 'nx' ) );
		// Get the post
		$post = get_post( $atts['post_id'] );
		// Set default value if meta is empty
		$post = ( empty( $post ) || empty( $post->$atts['field'] ) ) ? $atts['default'] : $post->$atts['field'];
		// Apply cutom filter
		if ( $atts['filter'] && function_exists( $atts['filter'] ) ) $post = call_user_func( $atts['filter'], $post );
		// Return result
		return ( $post ) ? $atts['before'] . $post . $atts['after'] : '';
	}
	
	public static function blog( $atts = null, $content = null ) {

		global $data;
		global $post;
		
		$layout_type = "masonry";
		$extra_layout_css = "masonry-default";

		if ( (is_front_page() || is_home() ) ) {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );
		} else {
			$paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
		}

		$atts = shortcode_atts( array(
		
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'order' => 'DESC', // DESC, ASC
			'orderby' => 'date',
			'post_status' => 'publish',
			'post_type' => 'post', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 10, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'paged' => $paged, // number of page. Show the posts that would normally show up just on page X when using the "Older Entries" link.
			'ignore_sticky_posts' => 'yes',

			'taxonomy' => 'category', // category, post_tag, nx_portfolio_tag, etc
			'field' => 'id', // slug or id
			'blog_term' => '', // taxonomy terms.

			//'title' => true, // show heading?
			'meta_all' => true, // show all meta info?
			'meta_author' => true, // show author?
			'meta_date' => true, // show date?
			'meta_comments' => true, // show comments?
			'meta_cat' => false, // show comments?	
			'read_more' => false, // show comments?						
			'thumbnail' => true, // show thumbnail?
			'content' => true, // show main content?
			'paging' => true, // show pagination navigation?
			'pagnav_align' => 'left', // salign pagination navigation?			
			
			//'offset' => 0, // show pagination navigation?			

			'size' => 'large', // default thumbnail size
			'filtering' => false, // insert isotope filter navigation
			'columns' => '2', // default number of isotope columns
			'heading_type' => 'h2', // heading tag for title
			'blog_layout' => '2', // blog layout
			
		), $atts, 'blog' );

		// clean input values
		$atts['terms'] = nx_shortcodes_comma_delim_to_array( $atts['blog_term'] );
		$atts['post__in'] = nx_shortcodes_comma_delim_to_array( $atts['post__in'] );
		$atts['columns'] == (int) $atts['columns'];
		$atts['order'] = strtoupper( $atts['order'] );
		$atts['heading_type'] = strtolower( $atts['heading_type'] );

	
		if (isset($atts['posts_per_page']) && $atts['posts_per_page']) {
			$atts['posts_per_page'] = (int) $atts['posts_per_page'];
		}
		else {
			$atts['posts_per_page'] = 0;
		}

		// add tax query if user specified
		if ( ! empty( $atts['terms'] ) ) {
			$atts['tax_query'] = array(
				array(
					'taxonomy' => $atts['taxonomy'],
					'field' => $atts['field'],
					'terms' => $atts['terms'],
				),
			);
		}

		// no paging needed when showing all posts
		if(isset($atts['posts_per_page']) && $atts['posts_per_page'] == -1) {
			$atts['nopaging'] = true;
		}
		
		
		// added
		//$ignore_sticky_posts = ( bool ) ( $atts['ignore_sticky_posts'] === 'yes' ) ? true : false;
		//if ( $ignore_sticky_posts ) $atts['ignore_sticky_posts'] = true;
		if ( $atts['ignore_sticky_posts'] == 'yes' )
		{
			$atts['ignore_sticky_posts'] = 1;
		} else
		{
			$atts['ignore_sticky_posts'] = 0;
		}
		
		if( $atts['blog_layout'] == '1' || $atts["columns"] == '1' )
		{
			$atts["columns"] = '1';
			$layout_type = "Standard";			
		} else
		{
			$layout_type = "masonry";
		}
		
		if( $atts['blog_layout'] == "3" )
		{
			$extra_layout_css = "masonry-modern";
		}		
		
		//$image = nx_image_resize( $slide['image'], round( $atts['width'] / $atts['items'] ), $atts['height'] );

		
		// setting attributes right for the php script
		$valid_headings = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' );
		$atts['heading_type'] = in_array( $atts['heading_type'], $valid_headings ) ? $atts['heading_type'] : 'h2';

		$valid_columns = array( 1, 2, 3, 4 );
		$atts['columns'] = in_array( $atts['columns'], $valid_columns ) ? $atts['columns'] : 2;
		
		//($atts['title'] == "yes") ? ($atts['title'] = true) : ($atts['title'] = false);
		($atts['meta_all'] == "yes") ? ($atts['meta_all'] = true) : ($atts['meta_all'] = false);
		($atts['meta_author'] == "yes") ? ($atts['meta_author'] = true) : ($atts['meta_author'] = false);
		($atts['meta_date'] == "yes") ? ($atts['meta_date'] = true) : ($atts['meta_date'] = false);
		($atts['meta_cat'] == "yes") ? ($atts['meta_cat'] = true) : ($atts['meta_cat'] = false);
		($atts['read_more'] == "yes") ? ($atts['read_more'] = true) : ($atts['read_more'] = false);
		($atts['meta_comments'] == "yes") ? ($atts['meta_comments'] = true) : ($atts['meta_comments'] = false);
		($atts['thumbnail'] == "yes") ? ($atts['thumbnail'] = true) : ($atts['thumbnail'] = false);
		($atts['content'] == "yes") ? ($atts['content'] = true) : ($atts['content'] = false);
		($atts['paging'] == "yes") ? ($atts['paging'] = true) : ($atts['paging'] = false);
		($atts['filtering'] == "yes") ? ($atts['filtering'] = true) : ($atts['filtering'] = false);
		($atts['order'] == "ASC") ? ($atts['order'] = "ASC") : ($atts['order'] = "DESC");

		$ml_query = new WP_Query($atts);

		$html = '';
		$atts['title'] = true;

		$class = array();
		$class[] = 'nx-posts';
		$class[] = 'nx-posts-col-' . $atts["columns"];
		$class[] = 'nx-posts-layout-' . $layout_type;
		$class[] = $extra_layout_css;
		$atts['nav-template'] = 'templates/blog/nav-filtering.php';
		$atts['blog-template'] = 'templates/blog/index.php';
		$atts['page-template'] = 'templates/blog/nav-pagination.php';
		
		if ( $atts['filtering'] ) {
			ob_start();
			//include( STYLESHEETPATH . '/templates/blog/nav-filtering.php' );
			
			if ( file_exists( STYLESHEETPATH . '/' . $atts['nav-template'] ) ) include( STYLESHEETPATH . '/' . $atts['nav-template'] );
			elseif ( file_exists( TEMPLATEPATH . '/' . $atts['nav-template'] ) ) include( TEMPLATEPATH . '/' . $atts['nav-template'] );
			elseif ( path_join( dirname( NX_PLUGIN_FILE ), $atts['nav-template'] ) ) include( path_join( dirname( NX_PLUGIN_FILE ), $atts['nav-template'] ) );
			else echo '<p class="nx-error">Posts: ' . __( 'template not found', 'nx' ) . '</p>';			
			
			$html .= ob_get_clean();
		}

		$html .= '<div data-columns="'.$atts["columns"].'" class="' . implode( ' ', $class ) . '">';

			while( $ml_query->have_posts() ) :
				$ml_query->the_post();
				
				if ( $atts['content'] && empty( $post->post_excerpt ) && empty( $post->post_content ) )
					$atts['content'] = false;

				ob_start();
				//include('templates/index.php');
				//include(STYLESHEETPATH . '/templates/blog/index.php');

				if ( file_exists( STYLESHEETPATH . '/' . $atts['blog-template'] ) ) include( STYLESHEETPATH . '/' . $atts['blog-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['blog-template'] ) ) include( TEMPLATEPATH . '/' . $atts['blog-template'] );
				elseif ( path_join( dirname( NX_PLUGIN_FILE ), $atts['blog-template'] ) ) include( path_join( dirname( NX_PLUGIN_FILE ), $atts['blog-template'] ) );
				else echo '<p class="nx-error">Posts: ' . __( 'template not found', 'nx' ) . '</p>';				
				
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div>';

		//no paging if only the latest posts are shown
		if ( $atts['paging'] ) {
			ob_start();
			//include(STYLESHEETPATH . '/templates/blog/nav-pagination.php');
			
			if ( file_exists( STYLESHEETPATH . '/' . $atts['page-template'] ) ) include( STYLESHEETPATH . '/' . $atts['page-template'] );
			elseif ( file_exists( TEMPLATEPATH . '/' . $atts['page-template'] ) ) include( TEMPLATEPATH . '/' . $atts['page-template'] );
			elseif ( path_join( dirname( NX_PLUGIN_FILE ), $atts['page-template'] ) ) include( path_join( dirname( NX_PLUGIN_FILE ), $atts['page-template'] ) );
			else echo '<p class="nx-error">Posts: ' . __( 'template not found', 'nx' ) . '</p>';	
							
			$html .= ob_get_clean();
		}
		wp_reset_query();
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'css', 'magnific-popup' );
		nx_query_asset( 'css', 'nx-blog-shortcodes' );			
		nx_query_asset( 'js', 'magnific-popup' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
				
		
		return $html;
	}		

	public static function blogcarousel( $atts = null, $content = null ) {

		global $data;
		global $post;

		$atts = shortcode_atts( array(
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'order' => 'DESC', // DESC, ASC
			'orderby' => 'date',
			'post_status' => 'publish',
			'post_type' => 'post', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 10, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'ignore_sticky_posts' => 'yes',

			'taxonomy' => 'category', // category, post_tag, nx_portfolio_tag, etc
			'field' => 'id', // slug or id
			'blog_term' => '', // taxonomy terms.

			//'title' => true, // show heading?
			'meta_all' => true, // show all meta info?
			'meta_author' => true, // show author?
			'meta_date' => true, // show date?
			'meta_comments' => true, // show comments?
			'meta_cat' => false, // show comments?	
			'read_more' => false, // show comments?						
			'thumbnail' => true, // show thumbnail?
			'content' => true, // show main content?
			'paging' => true, // show pagination navigation?
			'pagnav_align' => 'left', // salign pagination navigation?			
			
			//'offset' => 0, // show pagination navigation?	
			'size' => 'large', // default thumbnail size

			'filtering' => false, // insert isotope filter navigation
			'columns' => '2', // default number of isotope columns
			'heading_type' => 'h2', // heading tag for title
			'blog_layout' => '2', // blog layout
			'blog_car_layout' => '1', // blog layout
		), $atts, 'blogcarousel' );

		// clean input values
		$atts['terms'] = nx_shortcodes_comma_delim_to_array( $atts['blog_term'] );
		$atts['post__in'] = nx_shortcodes_comma_delim_to_array( $atts['post__in'] );
		$atts['columns'] == (int) $atts['columns'];
		$atts['order'] = strtoupper( $atts['order'] );

	
		if (isset($atts['posts_per_page']) && $atts['posts_per_page']) {
			$atts['posts_per_page'] = (int) $atts['posts_per_page'];
		}
		else {
			$atts['posts_per_page'] = 0;
		}

		// add tax query if user specified
		if ( ! empty( $atts['terms'] ) ) {
			$atts['tax_query'] = array(
				array(
					'taxonomy' => $atts['taxonomy'],
					'field' => $atts['field'],
					'terms' => $atts['terms'],
				),
			);
		}

		// no paging needed when showing all posts
		if(isset($atts['posts_per_page']) && $atts['posts_per_page'] == -1) {
			$atts['nopaging'] = true;
		}
		
		
		// added
		//$ignore_sticky_posts = ( bool ) ( $atts['ignore_sticky_posts'] === 'yes' ) ? true : false;
		//if ( $ignore_sticky_posts ) $atts['ignore_sticky_posts'] = true;
		if ( $atts['ignore_sticky_posts'] == 'yes' )
		{
			$atts['ignore_sticky_posts'] = 1;
		} else
		{
			$atts['ignore_sticky_posts'] = 0;
		}
		
		$valid_columns = array( 1, 2, 3, 4 );
		$atts['columns'] = in_array( $atts['columns'], $valid_columns ) ? $atts['columns'] : 2;
		
		//($atts['title'] == "yes") ? ($atts['title'] = true) : ($atts['title'] = false);
		($atts['meta_all'] == "yes") ? ($atts['meta_all'] = true) : ($atts['meta_all'] = false);
		($atts['meta_author'] == "yes") ? ($atts['meta_author'] = true) : ($atts['meta_author'] = false);
		($atts['meta_date'] == "yes") ? ($atts['meta_date'] = true) : ($atts['meta_date'] = false);
		($atts['meta_cat'] == "yes") ? ($atts['meta_cat'] = true) : ($atts['meta_cat'] = false);
		($atts['read_more'] == "yes") ? ($atts['read_more'] = true) : ($atts['read_more'] = false);		
		($atts['meta_comments'] == "yes") ? ($atts['meta_comments'] = true) : ($atts['meta_comments'] = false);
		($atts['thumbnail'] == "yes") ? ($atts['thumbnail'] = true) : ($atts['thumbnail'] = false);
		($atts['content'] == "yes") ? ($atts['content'] = true) : ($atts['content'] = false);
		($atts['order'] == "ASC") ? ($atts['order'] = "ASC") : ($atts['order'] = "DESC");

		$ml_query_pc = new WP_Query($atts);

		$html = '';
		$atts['title'] = true;

		$class = array();
		$class[] = 'nx-posts';
		//$class[] = 'nx-posts-col-' . $atts["columns"];
		$class[] = 'nx-posts-col-1';
		$class[] = 'nx-posts-carousel';

		$atts['blog-template'] = 'templates/posts-car/index.php';
	

		$html .= '<div class="blog-carousel-wrap blog-carousel-layout-'.$atts["blog_car_layout"].'"><div data-columns="'.$atts["columns"].'" class="' . implode( ' ', $class ) . '">';

			while( $ml_query_pc->have_posts() ) :
				$ml_query_pc->the_post();
				
				if ( $atts['content'] && empty( $post->post_excerpt ) && empty( $post->post_content ) )
					$atts['content'] = false;

				ob_start();
				//include(STYLESHEETPATH . '/templates/posts-car/index.php');
				
				if ( file_exists( STYLESHEETPATH . '/' . $atts['blog-template'] ) ) include( STYLESHEETPATH . '/' . $atts['blog-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['blog-template'] ) ) include( TEMPLATEPATH . '/' . $atts['blog-template'] );
				else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['blog-template'] ) );
		
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div></div>';

		wp_reset_query();
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'css', 'magnific-popup' );
		nx_query_asset( 'css', 'nx-blog-shortcodes' );
		nx_query_asset( 'css', 'owl-carousel' );
		nx_query_asset( 'css', 'owl-carousel-transitions' );		
		nx_query_asset( 'js', 'owl-carousel' );		
		nx_query_asset( 'js', 'magnific-popup' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
				
		
		return $html;
	}		
	
	
	public static function portfolio( $atts = null, $content = null ) {

		global $data;
		global $post;

		if ( (is_front_page() || is_home() ) ) {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );
		} else {
			$paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
		}

		$atts = shortcode_atts( array(
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'order' => 'DESC', // DESC, ASC
			'orderby' => 'date',
			'post_status' => 'publish',
			'post_type' => 'portfolio', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 10, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'paged' => $paged, // number of page. Show the posts that would normally show up just on page X when using the "Older Entries" link.

			'taxonomy' => 'portfolio-category', // category, post_tag, nx_portfolio_tag, etc
			'field' => 'id', // slug or id
			'blog_term' => '0', // taxonomy terms.

			//'title' => true, // show heading?
			'meta_all' => true, // show all meta info?
			'meta_author' => true, // show author?
			'meta_date' => true, // show date?
			'meta_comments' => true, // show comments?
			'meta_cat' => false, // show comments?			
			'thumbnail' => true, // show thumbnail?
			'content' => true, // show main content?
			'paging' => false, // show pagination navigation?
			'pagnav_align' => 'left', // show pagination navigation?
			
			//'offset' => 0, // show pagination navigation?	
			'size' => 'large', // default thumbnail size

			'filtering' => false, // insert isotope filter navigation
			'columns' => '3', // default number of isotope columns
			'heading_type' => 'h2', // heading tag for title
			'layout' => '2', // blog layout
			'class'					=> ''			
		), $atts, 'portfolio' );

		// clean input values
		$atts['terms'] = nx_shortcodes_comma_delim_to_array( $atts['blog_term'] );
		$atts['post__in'] = nx_shortcodes_comma_delim_to_array( $atts['post__in'] );
		$atts['columns'] == (int) $atts['columns'];
		$atts['order'] = strtoupper( $atts['order'] );
		$atts['heading_type'] = strtolower( $atts['heading_type'] );

		
		if (isset($atts['posts_per_page']) && $atts['posts_per_page']) {
			$atts['posts_per_page'] = (int) $atts['posts_per_page'];
		}
		else {
			$atts['posts_per_page'] = 0;
		}

		// add tax query if user specified
		if ( ! empty( $atts['terms'] ) ) {
			$atts['tax_query'] = array(
				array(
					'taxonomy' => $atts['taxonomy'],
					'field' => $atts['field'],
					'terms' => $atts['terms'],
				),
			);
		}

		// no paging needed when showing all posts
		if(isset($atts['posts_per_page']) && $atts['posts_per_page'] == -1) {
			$atts['nopaging'] = true;
		}
		
		$valid_columns = array( 1, 2, 3, 4 );
		$atts['columns'] = in_array( $atts['columns'], $valid_columns ) ? $atts['columns'] : 2;
		
		//($atts['title'] == "yes") ? ($atts['title'] = true) : ($atts['title'] = false);
		($atts['meta_all'] == "yes") ? ($atts['meta_all'] = true) : ($atts['meta_all'] = false);
		($atts['meta_author'] == "yes") ? ($atts['meta_author'] = true) : ($atts['meta_author'] = false);
		($atts['meta_date'] == "yes") ? ($atts['meta_date'] = true) : ($atts['meta_date'] = false);
		($atts['meta_comments'] == "yes") ? ($atts['meta_comments'] = true) : ($atts['meta_comments'] = false);
		($atts['thumbnail'] == "yes") ? ($atts['thumbnail'] = true) : ($atts['thumbnail'] = false);
		($atts['content'] == "yes") ? ($atts['content'] = true) : ($atts['content'] = false);
		($atts['paging'] == "yes") ? ($atts['paging'] = true) : ($atts['paging'] = false);
		($atts['filtering'] == "yes") ? ($atts['filtering'] = true) : ($atts['filtering'] = false);
		($atts['order'] == "ASC") ? ($atts['order'] = "ASC") : ($atts['order'] = "DESC");

		$ml2_query = new WP_Query($atts);

		$html = '';
		$atts['title'] = true;

		$class = array();
		$class[] = 'nx-folio';
		$class[] = 'nx-folio-layout-' . $atts['layout'];
		
		$atts['nav-template'] = 'templates/portfolio/nav-filtering.php';
		$atts['folio-template'] = 'templates/portfolio/index.php';
		$atts['page-template'] = 'templates/portfolio/nav-pagination.php';		

		if ( $atts['filtering'] ) {
			ob_start();
			//include( STYLESHEETPATH . '/templates/portfolio/nav-filtering.php' );
			if ( file_exists( STYLESHEETPATH . '/' . $atts['nav-template'] ) ) include( STYLESHEETPATH . '/' . $atts['nav-template'] );
			elseif ( file_exists( TEMPLATEPATH . '/' . $atts['nav-template'] ) ) include( TEMPLATEPATH . '/' . $atts['nav-template'] );
			else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['nav-template'] ) );			
			
			$html .= ob_get_clean();
		}
		
		if ( $atts['columns'] > 1 )
		{
			$html .= '<div class="' . implode( ' ', $class ) . ' clearfix masonry-folio ' . nx_ecssc( $atts ) . '">';
		} else
		{
			$html .= '<div class="' . implode( ' ', $class ) . ' clearfix ' . nx_ecssc( $atts ) . '">';
		}

			while( $ml2_query->have_posts() ) :
				$ml2_query->the_post();
				
				if ( $atts['content'] && empty( $post->post_excerpt ) && empty( $post->post_content ) )
					$atts['content'] = false;

				ob_start();
				//include(STYLESHEETPATH . '/templates/portfolio/index.php');
				
				if ( file_exists( STYLESHEETPATH . '/' . $atts['folio-template'] ) ) include( STYLESHEETPATH . '/' . $atts['folio-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['folio-template'] ) ) include( TEMPLATEPATH . '/' . $atts['folio-template'] );
				else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['folio-template'] ) );	
							
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div>';

		//no paging if only the latest posts are shown
		if ( $atts['paging'] ) {
			ob_start();
			//include(STYLESHEETPATH . '/templates/portfolio/nav-pagination.php');

			if ( file_exists( STYLESHEETPATH . '/' . $atts['page-template'] ) ) include( STYLESHEETPATH . '/' . $atts['page-template'] );
			elseif ( file_exists( TEMPLATEPATH . '/' . $atts['page-template'] ) ) include( TEMPLATEPATH . '/' . $atts['page-template'] );
			else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['page-template'] ) );
						
			$html .= ob_get_clean();
		}
		wp_reset_query();
		
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'css', 'nx-blog-shortcodes' );		
		nx_query_asset( 'css', 'magnific-popup' );
		
		nx_query_asset( 'js', 'isotope' );
		nx_query_asset( 'js', 'magnific-popup' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );		
						
		return $html;
	}	
	
	
	public static function team( $atts = null, $content = null ) {

		global $data;
		global $post;

		if ( (is_front_page() || is_home() ) ) {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );
		} else {
			$paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
		}

		$atts = shortcode_atts( array(
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'order' => 'DESC', // DESC, ASC
			'orderby' => 'date',
			'post_status' => 'publish',
			'post_type' => 'team', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 10, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'paged' => $paged, // number of page. Show the posts that would normally show up just on page X when using the "Older Entries" link.

			'taxonomy' => 'team-category', // category, post_tag, nx_portfolio_tag, etc
			'field' => 'id', // slug or id
			'blog_term' => '', // taxonomy terms.

			//'title' => true, // show heading?
			'meta_all' => true, // show all meta info?
			'meta_author' => true, // show author?
			'meta_date' => true, // show date?
			'meta_comments' => true, // show comments?
			'meta_cat' => false, // show comments?			
			'thumbnail' => true, // show thumbnail?
			'content' => true, // show main content?
			'paging' => false, // show pagination navigation?
			'pagnav_align' => 'left', // show pagination navigation?			
			
			//'offset' => 0, // show pagination navigation?	
			'size' => 'large', // default thumbnail size

			'filtering' => false, // insert isotope filter navigation
			'columns' => '4', // default number of isotope columns
			'layout' => '1', // blog layout
		), $atts, 'team' );

		// clean input values
		$atts['terms'] = nx_shortcodes_comma_delim_to_array( $atts['blog_term'] );
		$atts['post__in'] = nx_shortcodes_comma_delim_to_array( $atts['post__in'] );
		$atts['columns'] == (int) $atts['columns'];
		$atts['order'] = strtoupper( $atts['order'] );

		
		if (isset($atts['posts_per_page']) && $atts['posts_per_page']) {
			$atts['posts_per_page'] = (int) $atts['posts_per_page'];
		}
		else {
			$atts['posts_per_page'] = 0;
		}

		// add tax query if user specified
		if ( ! empty( $atts['terms'] ) ) {
			$atts['tax_query'] = array(
				array(
					'taxonomy' => $atts['taxonomy'],
					'field' => $atts['field'],
					'terms' => $atts['terms'],
				),
			);
		}

		// no paging needed when showing all posts
		if(isset($atts['posts_per_page']) && $atts['posts_per_page'] == -1) {
			$atts['nopaging'] = true;
		}
		
		$valid_columns = array( 1, 2, 3, 4 );
		$atts['columns'] = in_array( $atts['columns'], $valid_columns ) ? $atts['columns'] : 2;
		
		//($atts['title'] == "yes") ? ($atts['title'] = true) : ($atts['title'] = false);
		($atts['meta_all'] == "yes") ? ($atts['meta_all'] = true) : ($atts['meta_all'] = false);
		($atts['meta_author'] == "yes") ? ($atts['meta_author'] = true) : ($atts['meta_author'] = false);
		($atts['meta_date'] == "yes") ? ($atts['meta_date'] = true) : ($atts['meta_date'] = false);
		($atts['meta_comments'] == "yes") ? ($atts['meta_comments'] = true) : ($atts['meta_comments'] = false);
		($atts['thumbnail'] == "yes") ? ($atts['thumbnail'] = true) : ($atts['thumbnail'] = false);
		($atts['content'] == "yes") ? ($atts['content'] = true) : ($atts['content'] = false);
		($atts['paging'] == "yes") ? ($atts['paging'] = true) : ($atts['paging'] = false);
		($atts['filtering'] == "yes") ? ($atts['filtering'] = true) : ($atts['filtering'] = false);
		($atts['order'] == "ASC") ? ($atts['order'] = "ASC") : ($atts['order'] = "DESC");

		$ml2_query = new WP_Query($atts);

		$html = '';
		$atts['title'] = true;

		$class = array();
		$class[] = 'nx-team';
		$class[] = 'nx-team-layout-' . $atts['layout'];
		
		$atts['team-template'] = 'templates/team/index.php';
		$atts['page-template'] = 'templates/team/nav-pagination.php';			

		$html .= '<div class="' . implode( ' ', $class ) . ' clearfix">';
		

			while( $ml2_query->have_posts() ) :
				$ml2_query->the_post();
				
				if ( $atts['content'] && empty( $post->post_excerpt ) && empty( $post->post_content ) )
					$atts['content'] = false;

				ob_start();
				//include('templates/index.php');
				//include(STYLESHEETPATH . '/templates/team/index.php');
				
				if ( file_exists( STYLESHEETPATH . '/' . $atts['team-template'] ) ) include( STYLESHEETPATH . '/' . $atts['team-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['team-template'] ) ) include( TEMPLATEPATH . '/' . $atts['team-template'] );
				else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['team-template'] ) );				
				
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div>';

		//no paging if only the latest posts are shown
		if ( $atts['paging'] ) {
			ob_start();
			//include(STYLESHEETPATH . '/templates/portfolio/nav-pagination.php');
			
			if ( file_exists( STYLESHEETPATH . '/' . $atts['page-template'] ) ) include( STYLESHEETPATH . '/' . $atts['page-template'] );
			elseif ( file_exists( TEMPLATEPATH . '/' . $atts['page-template'] ) ) include( TEMPLATEPATH . '/' . $atts['page-template'] );
			else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['page-template'] ) );			
			
			$html .= ob_get_clean();
		}
		wp_reset_query();
		
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'css', 'nx-blog-shortcodes' );		
		nx_query_asset( 'css', 'magnific-popup' );
		
		nx_query_asset( 'js', 'isotope' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );		
		nx_query_asset( 'js', 'magnific-popup' );
						
		return $html;
	}		
	
	
	public static function testimonials( $atts = null, $content = null ) {

		global $data;
		global $post;

		if ( (is_front_page() || is_home() ) ) {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );
		} else {
			$paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
		}

		$atts = shortcode_atts( array(
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'post_status' => 'publish',
			'post_type' => 'testimonials', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 20, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'paged' => $paged, // number of page. Show the posts that would normally show up just on page X when using the "Older Entries" link.

			'style' => 'default',
			'delay' => 8000, 

			'taxonomy' => 'testimonials-category', // category, post_tag, nx_portfolio_tag, etc
			'columns' => '4', // default number of isotope columns
			'layout' => '1', // blog layout
		), $atts, 'testimonials' );

		// clean input values
		
		$id = $atts['post__in']; // Sanitized later as an array of integers
		if ( $id ) {
			$posts_in = array_map( 'intval', explode( ',', $id ) );
			$atts['post__in'] = $posts_in;
		}			

		$atts['columns'] == (int) $atts['columns'];

		
		if (isset($atts['posts_per_page']) && $atts['posts_per_page']) {
			$atts['posts_per_page'] = (int) $atts['posts_per_page'];
		}
		else {
			$atts['posts_per_page'] = 0;
		}


		$valid_columns = array( 1, 2, 3, 4 );
		$atts['columns'] = in_array( $atts['columns'], $valid_columns ) ? $atts['columns'] : 2;

		$ml2_query = new WP_Query($atts);

		$html = '';

		$class = array();
		$class[] = 'nx-testi';
		
		$atts['testi-template'] = 'templates/testimonials/index.php';

		$html .= '<div class="' . implode( ' ', $class ) . ' ' . $atts['style'] . '  clearfix" data-autoplay-speed="'.$atts['delay'].'">';
		

			while( $ml2_query->have_posts() ) :
				$ml2_query->the_post();
				
				ob_start();
				//include(STYLESHEETPATH . '/templates/testimonials/index.php');
				
				if ( file_exists( STYLESHEETPATH . '/' . $atts['testi-template'] ) ) include( STYLESHEETPATH . '/' . $atts['testi-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['testi-template'] ) ) include( TEMPLATEPATH . '/' . $atts['testi-template'] );
				else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['testi-template'] ) );						
				
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div>';


		wp_reset_query();
		
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'owl-carousel' );
		nx_query_asset( 'css', 'owl-carousel-transitions' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );				
		nx_query_asset( 'js', 'owl-carousel' );				
						
		return $html;
	}
	
	public static function clients( $atts = null, $content = null ) {

		global $data;
		global $post;
		
		$client_border_class = "";

		$atts = shortcode_atts( array(
			'author' => '', //use author id
			'author_name' => '', //use 'user_nicename' (NOT name).
			'p' => false, //use post id.
			'post__in' => false, //use post ids
			'post_status' => 'publish',
			'post_type' => 'clients', // post, page, nx_portfolio_item, etc
			'posts_per_page' => 10, //number of post to show per page
			'nopaging' => false, //show all posts or use pagination. Default value is 'false', use paging.
			'taxonomy' => 'clients-category', // category, post_tag, wc_portfolio_tag, etc
			'columns' => '4', // default number of isotope columns
			'layout' => '1', // blog layout
			'client_border' => '1', // blog layout
		), $atts, 'testimonials' );

		// clean input values
		$id = $atts['post__in']; // Sanitized later as an array of integers
		if ( $id ) {
			$posts_in = array_map( 'intval', explode( ',', $id ) );
			$atts['post__in'] = $posts_in;
		}		

		$atts['columns'] == (int) $atts['columns'];

		$ml2_query_clients = new WP_Query($atts);

		$html = '';

		$class = array();
		$class[] = 'nx-clients';
		$class[] = 'nx-clients-carousel';
		
		if ($atts['client_border'] == 2)
		{
			$client_border_class = "client-no-border";
		}
		
		$atts['client-template'] = 'templates/clients/index.php';		

		$html .= '<div class="nx-clients-wrap ' . $client_border_class . '"><div class="' . implode( ' ', $class ) . ' clearfix">';
		

			while( $ml2_query_clients->have_posts() ) :
				$ml2_query_clients->the_post();
				
				ob_start();
				//include('templates/index.php');
				//include(STYLESHEETPATH . '/templates/clients/index.php');
				if ( file_exists( STYLESHEETPATH . '/' . $atts['client-template'] ) ) include( STYLESHEETPATH . '/' . $atts['client-template'] );
				elseif ( file_exists( TEMPLATEPATH . '/' . $atts['client-template'] ) ) include( TEMPLATEPATH . '/' . $atts['client-template'] );
				else include( path_join( dirname( NX_PLUGIN_FILE ), $atts['client-template'] ) );				
				$html .= ob_get_clean();

			endwhile;

		$html .= '</div></div>';


		wp_reset_query();
		
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'owl-carousel' );
		nx_query_asset( 'css', 'owl-carousel-transitions' );		
		nx_query_asset( 'js', 'owl-carousel' );		
		nx_query_asset( 'js', 'nx-other-shortcodes' );
						
		return $html;	

	}	
	
	
	public static function fancyrow( $atts = null, $content = null ) {
		
		$atts = shortcode_atts( array(
				'fullwidth'        		=> 'no',
				'block_height'	=> '',
				'background_color'      => '#77be32',
				'background_opacity'      => 1,
				'background_image'      => '',
				'background_repeat'    	=> 'no-repeat',
				'background_position'   => 'left top',
				'arrow_position'   		=> 'no-arrow',											
				'class'					=> ''
			), $atts, 'fancyrow' );
			
		$nx_fullwidth = "";
		$fancy_block_css = "";
		$arrow_class = "";
		$arrow_style = "";
		$background_color = "";
		$angle_color = $atts['background_color'];
		
		if ( $atts['fullwidth'] == 'yes')
		{
			$nx_fullwidth = "fullwidthrow";
		}
		
		if ( $atts['background_opacity'] <= 0.9 || $atts['background_opacity'] >= 0.1 )
		{
			$background_color = nx_hex2rgba($atts['background_color'], $atts['background_opacity']);
			$fancy_block_css .= 'background-color: '.$background_color.';';
		} else
		{
			$fancy_block_css .= 'background-color: '.$atts['background_color'].';';
		}
		
		if ( $atts['arrow_position'] == 'top')
		{
			$arrow_class = "arrow-up";
			$arrow_style = "border-bottom: 30px solid ".$angle_color.";";
			
		} elseif ( $atts['arrow_position'] == 'bottom')
		{
			$arrow_class = "arrow-down";
			$arrow_style = "border-top: 30px solid ".$angle_color.";";
		}				
		
		if(!empty($atts['background_image']))
		{
			$fancy_block_css .= 'background-image: URL('.$atts['background_image'].');';
			$arrow_class = "";
		}
		
		if(!empty($atts['block_height']))
		{
			$fancy_block_css .= 'height: '.$atts['block_height'].'px; vertical-align: middle;';
		}		
		
		if( $atts['background_repeat'] == 'cover' )
		{
			$fancy_block_css .= 'background-size: cover;';
		} else if( $atts['background_repeat'] == 'repeat' )
		{
			$fancy_block_css .= 'background-repeat: repeat;';
		} else
		{
			$fancy_block_css .= 'background-repeat: no-repeat;';			
		}
		
		$fancy_block_css .= 'background-position: '.$atts['background_position'].';';
		
					
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		
		return '<div class="row fancy-block ' . $nx_fullwidth .' '. $arrow_class.' ' . nx_ecssc( $atts ) . '"><div class="fancy-block-contents" style="'.$fancy_block_css.'"><div class="fancy-inner clearfix">' . do_shortcode( $content ) . '<div class="nx-arrow" style="'.$arrow_style.'"></div></div></div></div>';				
			

	}
	

	//Ads row
	public static function adsrow( $atts = null, $content = null ) {
		
		$atts = shortcode_atts( array(
				'class'					=> ''
			), $atts, 'adsrow' );
			
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		return '<div class="nx-adsrow' . nx_ecssc( $atts ) . '">' . nx_do_shortcode( $content, 'r' ) . '</div>';				

	}
	
	// ads column
	public static function adscolumn( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'size'   => '1-2',
				'class'  => ''
			), $atts, 'adscolumn' );
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		
		return '<div class="nx-adscol nx-adscol-' . str_replace( '/', '-', $atts['size'] ) . nx_ecssc( $atts ) . '">' . nx_do_shortcode( $content, 'c' ) . '</div>';		
		
	}	
	
	//Ads block
	public static function adsblock( $atts = null, $content = null ) {
		
		$atts = shortcode_atts( array(
				'title'					=> 'Title',
				'subtitle'      		=> 'Sub Title',
				'buttontext'      		=> 'View Products',
				'ads_image'    			=> '',
				'url'   				=> get_option( 'home' ),
				'padding_top'    		=> '120',
				'class'					=> ''
			), $atts, 'adsblock' );
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		
		return '<div class="nx-adsblock ' . nx_ecssc( $atts ) . '"><a href="' . nx_scattr($atts['url']) . '"><img src="'. ($atts['ads_image']) .'" alt="" class="" /><div class="adstext" style="padding-top: '. ($atts['padding_top']) .'px; "><div class="adstitle">' . nx_scattr($atts['title']) . '</div><div class="adssubtitle">' . nx_scattr($atts['subtitle']) . '</div><div class="adsbutton">' . nx_scattr($atts['buttontext']) . '</div></div></a></div>';				
			

	}	
	
	// Absolute Blocks
	public static function absolutebox( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'title'   => '',
				'title_size'   => 24,				
				'title_color'   => '#e7e7e7',
				'title_bg_color'   => '#373737',
				'box_state'   => 'opened',
				'top_position'   => 0,
				'box_hposition'   => 'left',				
				'h_position'   => 0,
				'width'   => 25,
				'text_color'   => '#373737',
				'bg_color'   => '#FFFFFF',
				'transparent' => 'no',
				'opacity' => 0.0,				
				'padding' => 16,				 
				'mobile_device' => '1', 							
				'class'  => ''
			), $atts, 'absolutebox' );
		
		$box_title = '';
		$container_class = '';
		$box_position = 'top: '.$atts['top_position'].'px';
		$h_position = 'left :' . $atts['h_position'] . 'px;';
		$container_bg = 'background-color :' . $atts['bg_color'] . ';';
		$mobile_device = 'data-mobile-device="' . $atts['mobile_device'] . '"';
		
		if ( $atts['box_state'] == 'open_from_top' && !empty($atts['title']) )
		{
			$box_position = 'top: '.$atts['top_position'].'px';
			$container_class = 'collapsable';
		} elseif ( $atts['box_state'] == 'open_from_bottom' && !empty($atts['title']) )
		{
			$box_position = 'bottom: '.$atts['top_position'].'px';
			$container_class = 'collapsable';
		}
		
		if ( $atts['box_hposition'] == 'right' )
		{
			$h_position = 'right :' . $atts['h_position'] . 'px;';
		}
		
		if ( $atts['transparent'] == 'yes' )
		{
			$container_bg = 'background : transparent; ';
			//$background_rgba = nx_hex2rgba($atts['bg_color'], $atts['opacity']);
			//$container_bg = 'background-color:' . $background_rgba. '; ';
		}
		
		$container_bg .= 'padding : '.$atts['padding'].'px; '; 
		
		$container_style = $h_position.$box_position.'; width: ' . $atts['width'] . '%; ';
		
		if ( !empty($atts['title']) )
		{
			$box_title = '<div class="nx-absblock-title" style="font-size: '.$atts['title_size'].'px; background-color: '.$atts['title_bg_color'].'; color: '.$atts['title_color'].'; ">'. nx_scattr($atts['title']) .'</div>';
		}
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		
		return '<div class="nx-abs-container-wrap"><div class="nx-abdcontainer '.$container_class.'" style="'.$container_style.'" '.$mobile_device.'>'.$box_title.'<div class="nx-abs-inner" style="'.$container_bg.'">' . nx_do_shortcode( $content, 'c' ) . '</div></div></div>';
		
	}
	
	public static function products_carusel( $atts = null, $content = null ) {
		$atts = shortcode_atts( array(
				'prod_ids'  => '',
				'product_listing_type'  => 'recent_products',				
				'columns'   => 4,
				'number'   => 10
			), $atts, 'products_carusel' );
		
		$prod_shotcode = "";
		
		if ( $atts['columns'] > 6 || $atts['columns'] < 2 )
		{
			$atts['columns'] = 4;	
		}
		
		if( $atts['product_listing_type'] == 'recent_products' )
		{
			$prod_shotcode = '[recent_products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
		} elseif( $atts['product_listing_type'] == 'featured_products' )
		{
			$prod_shotcode = '[featured_products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
		} elseif( $atts['product_listing_type'] == 'sale_products' )
		{
			$prod_shotcode = '[sale_products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
		} elseif( $atts['product_listing_type'] == 'best_selling_products' )
		{
			$prod_shotcode = '[best_selling_products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
		} elseif( $atts['product_listing_type'] == 'top_rated_products' )
		{
			$prod_shotcode = '[top_rated_products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
		} elseif( $atts['product_listing_type'] == 'products' )
		{
			if(!empty($atts['prod_ids']))
			{
				$prod_shotcode = '[products per_page="'.$atts['number'].'" ids="'.$atts['prod_ids'].'" columns="'.$atts['columns'].'"]';
			} else
			{
				$prod_shotcode = '[products per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
			}
			
		} elseif( $atts['product_listing_type'] == 'product_categories' )
		{
			if(!empty($atts['prod_ids']))
			{
				$prod_shotcode = '[product_categories per_page="'.$atts['number'].'" ids="'.$atts['prod_ids'].'" columns="'.$atts['columns'].'"]';
			} else
			{
				$prod_shotcode = '[product_categories per_page="'.$atts['number'].'" columns="'.$atts['columns'].'"]';
			}			
			
		}
		
		nx_query_asset( 'css', 'nx-box-shortcodes' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );
		
		return '<div class="nxprodscroll" data-column-count="'.$atts['columns'].'">' . do_shortcode( $prod_shotcode ) . '</div>';
	}
	
	// itrans Slider
	public static function itrans_slider( $atts = null, $content = null ) {
		$atts = shortcode_atts(array(
			'style' => '',
			'items' => 10,
			'category' => '',
			'delay' => 8,
			'parallax' => 'yes',
			'transition' => 'slide',
			'align' => 'left',		
			'title' => 'show',
			'desc' => 'show',
			'link' => 'show',
			'height' => 520,
			'textbg' => 'shadow',												
			'class' => '',								
		), $atts, 'itrans_slider');
		
		$return_string = '';
		$cat_slug = '';
		
		if( !empty($atts['category']) )
		{
			$cat_slug = $atts['category'];
		}
	
		$posts_per_page = intval( $atts['items'] );
		$tx_class = $atts['class'];
		$tx_delay = intval( $atts['delay'] )*1000;
		$tx_parallax = $atts['parallax'];
		
		$tx_transition = $atts['transition'];
		$tx_title = $atts['title'];
		$tx_desc = $atts['desc'];
		$tx_link = $atts['link'];	
		$tx_align = $atts['align'];
		$tx_height = intval( $atts['height'] );	
		$tx_textbg = $atts['textbg'];		
		
		
		$return_string .= '<div class="nx-itrans-slider '.$tx_textbg.'" data-delay="'.$tx_delay.'" data-parallax="'.$tx_parallax.'" data-transition="'.$tx_transition.'">';		
		
		
		wp_reset_query();
		global $post;
		
		$args = array(
			'post_type' => 'itrans-slider',
			'posts_per_page' => $posts_per_page,
			'orderby' => 'date', 
			'order' => 'DESC',
			'ignore_sticky_posts' => 1,
			'itrans-slider-category' => $cat_slug, //use post ids				
		);
	
		$full_image_url = '';
		$large_image_url = '';
		$image_url = '';
		$width = 1200;
		$height = (int)$tx_height;
	
		query_posts( $args );
	   
		if ( have_posts() ) : while ( have_posts() ) : the_post();
		
			$full_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );	
			$image_url = nx_image_resize( $full_image_url[0], $width, $height, true, true );
	
			$slide_link_text = rwmb_meta('ispirit_slide_link_text');
			$show_link_url = rwmb_meta('ispirit_slide_link_url');		
			
			$return_string .= '<div class="tx-slider-item">';
			$return_string .= '<div class="tx-slider-box">';
			
			if ( has_post_thumbnail() ) { 
				$return_string .= '<div class="tx-slider-img">';
				$return_string .= '<img src="'.esc_url($image_url["url"]).'" alt="" class="blog-image" />';
				$return_string .= '</div>';
			} 
			/**/
			$return_string .= '<div class="tx-slide-content"><div class="tx-slide-content-inner" style="text-align:'.$tx_align.';">';
			if ( $tx_title == 'show' && get_the_title() )
			{
				$return_string .= '<h3 class="tx-slide-title">'.get_the_title().'</h3>';
			}
			if ( $tx_desc == 'show' && get_the_content() ) {
				$return_string .= '<div class="tx-slide-details"><p>'.get_the_content().'</p></div>';
			}
			//if ( $tx_link == 'show' || !empty($slide_link_text) ) {
			if ( $tx_link == 'show' && !empty($slide_link_text) ) {	
				$return_string .= '<div class="tx-slide-button"><a href="'.esc_url( $show_link_url ).'" class="button">'.esc_attr( $slide_link_text ).'</a></div>';		
			}
			$return_string .= '</div></div></div></div>';		
			
			
		endwhile; else :
			$return_string .= '<div style="padding: 32px; background-color: #eee;"><p>Sorry, no slider matched your criteria.</p></div>';
		endif;
	  
		$return_string .= '</div>';
	
		wp_reset_query();
		
		nx_query_asset( 'css', 'nx-other-shortcodes' );
		nx_query_asset( 'css', 'owl-carousel' );
		nx_query_asset( 'css', 'owl-carousel-transitions' );
		nx_query_asset( 'js', 'nx-other-shortcodes' );				
		nx_query_asset( 'js', 'owl-carousel' );				
		
		return $return_string;
	}		

}

new Nx_Shortcodes;

class Nx_Shortcode_Shortcodes extends Nx_Shortcodes {
	function __construct() {
		parent::__construct();
	}
}