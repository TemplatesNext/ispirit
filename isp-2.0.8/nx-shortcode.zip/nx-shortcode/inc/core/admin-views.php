<?php
class Nx_Admin_Views {
	function __construct() {}

	public static function about( $field, $config ) {
		ob_start();
?>
<div id="nx-about-screen">
	<h1><?php _e( 'Welcome to TemplatesNext Shortcode', 'nx' ); ?> <small><?php _e( 'A real swiss army knife for WordPress', 'nx' ); ?></small></h1>
	<div class="sunrise-inline-menu">
		<a href="http://templatesnext.org/nx-shortcode/" target="_blank"><strong><?php _e( 'Project homepage', 'nx' ); ?></strong></a>
		<a href="http://templatesnext.org/kb/" target="_blank"><?php _e( 'Documentation', 'nx' ); ?></a>
		<a href="http://wordpress.org/support/plugin/nx-shortcode/" target="_blank"><?php _e( 'Support forum', 'nx' ); ?></a>
		<a href="http://wordpress.org/extend/plugins/nx-shortcode/changelog/" target="_blank"><?php _e( 'Changelog', 'nx' ); ?></a>
		<a href="https://github.com/gndev/nx-shortcode" target="_blank"><?php _e( 'Fork on GitHub', 'nx' ); ?></a>
	</div>
	<div class="nx-clearfix">
		<div class="nx-about-column">
			<h3><?php _e( 'Plugin features', 'nx' ); ?></h3>
			<ul>
				<li><?php _e( '40+ amazing shortcodes', 'nx' ); ?></li>
				<li><?php _e( 'Power of CSS3 transitions', 'nx' ); ?></li>
				<li><?php _e( 'Handy shortcodes generator', 'nx' ) ?></li>
				<li><?php _e( 'International', 'nx' ); ?></li>
				<li><?php _e( 'Documented API', 'nx' ); ?></li>
			</ul>
		</div>
		<div class="nx-about-column">
			<h3><?php _e( 'What is a shortcode?', 'nx' ); ?></h3>
			<p><?php _e( '<strong>Shortcode</strong> is a WordPress-specific code that lets you do nifty things with very little effort.', 'nx' ); ?></p>
			<p><?php _e( 'Shortcodes can embed files or create objects that would normally require lots of complicated, ugly code in just one line. Shortcode = shortcut.', 'nx' ); ?></p>
		</div>
	</div>
	<div class="nx-clearfix">
		<div class="nx-about-column">
			<h3><?php _e( 'How does it works', 'nx' ); ?></h3>
			<a href="http://www.youtube.com/watch?v=DR2c266yWEA?autoplay=1&amp;showinfo=0&amp;rel=0&amp;theme=light#" target="_blank" class="nx-demo-video"><img src="<?php echo plugins_url( 'assets/images/banners/how-it-works.jpg', NX_PLUGIN_FILE ); ?>" alt=""></a>
		</div>
		<div class="nx-about-column">
			<h3><?php _e( 'More videos', 'nx' ); ?></h3>
			<ul>
				<li><a href="http://www.youtube.com/watch?v=IjmaXz-b55I" target="_blank"><?php _e( 'TemplatesNext Shortcode Tutorial', 'nx' ); ?></a></li>
				<li><a href="http://www.youtube.com/watch?v=YU3Zu6C5ZfA" target="_blank"><?php _e( 'How to use special widget', 'nx' ); ?></a></li>
				<li><a href="http://www.screenr.com/BK0H" target="_blank"><?php _e( 'How to create Carousel', 'nx' ); ?></a></li>
				<li><a href="http://www.youtube.com/watch?v=kCWyO2F7jTw" target="_blank"><?php _e( 'How to create image gallery', 'nx' ); ?></a></li>
			</ul>
		</div>
	</div>
</div>
		<?php
		$output = ob_get_contents();
		ob_end_clean();
		nx_query_asset( 'css', array( 'magnific-popup', 'nx-options-page' ) );
		nx_query_asset( 'js', array( 'jquery', 'magnific-popup', 'nx-options-page' ) );
		return $output;
	}

	public static function custom_css( $field, $config ) {
		ob_start();
?>
<div id="nx-custom-css-screen">
	<div class="nx-custom-css-originals">
		<p><strong><?php _e( 'You can overview the original styles to override it', $config['textdomain'] ); ?></strong></p>
		<div class="sunrise-inline-menu">
			<a href="<?php echo nx_skin_url( 'content-shortcodes.css' ); ?>">content-shortcodes.css</a>
			<a href="<?php echo nx_skin_url( 'box-shortcodes.css' ); ?>">box-shortcodes.css</a>
			<a href="<?php echo nx_skin_url( 'media-shortcodes.css' ); ?>">media-shortcodes.css</a>
			<a href="<?php echo nx_skin_url( 'galleries-shortcodes.css' ); ?>">galleries-shortcodes.css</a>
			<a href="<?php echo nx_skin_url( 'players-shortcodes.css' ); ?>">players-shortcodes.css</a>
			<a href="<?php echo nx_skin_url( 'other-shortcodes.css' ); ?>">other-shortcodes.css</a>
		</div>
		<?php do_action( 'nx/admin/css/originals/after' ); ?>
	</div>
	<div class="nx-custom-css-vars">
		<p><strong><?php _e( 'You can use next variables in your custom CSS', $config['textdomain'] ); ?></strong></p>
		<code>%home_url%</code> - <?php _e( 'home url', $config['textdomain'] ); ?><br/>
		<code>%theme_url%</code> - <?php _e( 'theme url', $config['textdomain'] ); ?><br/>
		<code>%plugin_url%</code> - <?php _e( 'plugin url', $config['textdomain'] ); ?>
	</div>
	<div id="nx-custom-css-editor">
		<div id="sunrise-field-<?php echo $field['id']; ?>-editor"></div>
		<textarea name="sunrise[<?php echo $field['id']; ?>]" id="sunrise-field-<?php echo $field['id']; ?>" class="regular-text" rows="10"><?php echo stripslashes( get_option( $config['prefix'] . $field['id'] ) ); ?></textarea>
	</div>
</div>
			<?php
		$output = ob_get_contents();
		ob_end_clean();
		nx_query_asset( 'css', array( 'magnific-popup', 'nx-options-page' ) );
		nx_query_asset( 'js', array( 'jquery', 'magnific-popup', 'ace', 'nx-options-page' ) );
		return $output;
	}

	public static function examples( $field, $config ) {
		$output = array();
		$examples = Nx_Data::examples();
		$preview = '<div style="display:none"><div id="nx-examples-window"><div id="nx-examples-preview"></div></div></div>';
		$open = ( isset( $_GET['example'] ) ) ? sanitize_text_field( $_GET['example'] ) : '';
		$open = '<input id="nx_open_example" type="hidden" name="nx_open_example" value="' . $open . '" />';
		foreach ( $examples as $group ) {
			$items = array();
			if ( isset( $group['items'] ) ) foreach ( $group['items'] as $item ) {
					$code = ( isset( $item['code'] ) ) ? $item['code'] : plugins_url( 'inc/examples/' . $item['id'] . '.example', NX_PLUGIN_FILE );
					$id = ( isset( $item['id'] ) ) ? $item['id'] : '';
					$items[] = '<div class="nx-examples-item" data-code="' . $code . '" data-id="' . $id . '" data-mfp-src="#nx-examples-window" style="visibility:hidden"><i class="fa fa-' . $item['icon'] . '"></i> ' . $item['name'] . '</div>';
				}
			$output[] = '<div class="nx-examples-group nx-clearfix"><h2 class="nx-examples-group-title" style="visibility:hidden">' . $group['title'] . '</h2>' . implode( '', $items ) . '</div>';
		}
		nx_query_asset( 'css', array( 'magnific-popup', 'animate', 'font-awesome', 'nx-options-page' ) );
		nx_query_asset( 'js', array( 'jquery', 'magnific-popup', 'nx-options-page' ) );
		return '<div id="nx-examples-screen">' . implode( '', $output ) . '</div>' . $preview . $open;
	}

	public static function addons( $field, $config ) {
		$output = array();
		$addons = array(
			array(
				'name' => __( 'New Shortcodes', 'nx' ),
				'desc' => __( 'Parallax sections, responsive content slider, pricing tables, vector icons, testimonials, progress bars and even more', 'nx' ),
				'url' => 'http://templatesnext.org/nx-shortcode/extra/',
				'image' => plugins_url( 'assets/images/banners/extra.png', NX_PLUGIN_FILE )
			),
			array(
				'name' => __( 'Maker', 'nx' ),
				'desc' => __( 'This add-on allows you to create custom shortcodes. You can easily create any shortcode with different parameters or even override default shortcodes', 'nx' ),
				'url' => 'http://templatesnext.org/nx-shortcode/maker/',
				'image' => plugins_url( 'assets/images/banners/maker.png', NX_PLUGIN_FILE )
			),
			array(
				'name' => __( 'Skins', 'nx' ),
				'desc' => __( 'Set of additional skins for TemplatesNext Shortcode. It includes skins for accordeons/spoilers, tabs and some other shortcodes', 'nx' ),
				'url' => 'http://templatesnext.org/nx-shortcode/skins/',
				'image' => plugins_url( 'assets/images/banners/skins.png', NX_PLUGIN_FILE )
			),
		);
		$plugins = array();
		$output[] = '<h2>' . __( 'TemplatesNext Shortcode Add-ons', 'nx' ) . '</h2>';
		$output[] = '<div class="nx-addons-loop nx-clearfix">';
		foreach ( $addons as $addon ) {
			$output[] = '<div class="nx-addons-item" style="visibility:hidden" data-url="' . $addon['url'] . '"><img src="' . $addon['image'] . '" alt="' . $addon['image'] . '" /><div class="nx-addons-item-content"><h4>' . $addon['name'] . '</h4><p>' . $addon['desc'] . '</p><div class="nx-addons-item-button"><a href="' . $addon['url'] . '" class="button button-primary" target="_blank">' . __( 'Learn more', 'nx' ) . '</a></div></div></div>';
		}
		$output[] = '</div>';
		if ( count( $plugins ) ) {
			$output[] = '<h2>' . __( 'Other WordPress Plugins', 'nx' ) . '</h2>';
			$output[] = '<div class="nx-addons-loop nx-clearfix">';
			foreach ( $plugins as $plugin ) {
				$output[] = '<div class="nx-addons-item" style="visibility:hidden" data-url="' . $plugin['url'] . '"><img src="' . $plugin['image'] . '" alt="' . $plugin['image'] . '" /><div class="nx-addons-item-content"><h4>' . $plugin['name'] . '</h4><p>' . $plugin['desc'] . '</p>' . Nx_Shortcodes::button( array( 'url' => $plugin['url'], 'target' => 'blank', 'style' => 'flat', 'background' => '#FF7654', 'wide' => 'yes', 'radius' => '0' ), __( 'Learn more', 'nx' ) ) . '</div></div>';
			}
			$output[] = '</div>';
		}
		nx_query_asset( 'css', array( 'animate', 'nx-options-page' ) );
		nx_query_asset( 'js', array( 'jquery', 'nx-options-page' ) );
		return '<div id="nx-addons-screen">' . implode( '', $output ) . '</div>';
	}
}
