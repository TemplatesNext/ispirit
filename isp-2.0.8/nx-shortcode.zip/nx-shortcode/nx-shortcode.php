<?php
/*
  Plugin Name: TemplatesNext Shortcode
  Plugin URI: http://templatesnext.org/nx-shortcode/
  Version: 1.0.7
  Author: TemplatesNext
  Author URI: http://templatesnext.org/
  Description: Power up your WordPress with mega pack of shortcodes
  Text Domain: nx
  Domain Path: /languages
  License: GPL
  
 */
// Plugin based on Vladimir Anokhin's Shortcodes Ultimate

// Define plugin file constants
define( 'NX_PLUGIN_FILE', __FILE__ );
define( 'NX_PLUGIN_VERSION', '1.0.2' );
define( 'NX_ENABLE_CACHE', true );

define( 'NX_PLUGIN_DIR', untrailingslashit( dirname( __FILE__ ) ) );

// include post types
require_once 'inc/custom-post-types/portfolio-type.php';
require_once 'inc/custom-post-types/gallery-type.php';
require_once 'inc/custom-post-types/team-type.php';
require_once 'inc/custom-post-types/clients-type.php';
require_once 'inc/custom-post-types/testimonials-type.php';
require_once 'inc/custom-post-types/itrans-slider.php';

// Includes core files
require_once 'inc/vendor/sunrise.php';
require_once 'inc/core/admin-views.php';
require_once 'inc/core/requirements.php';
require_once 'inc/core/load.php';
require_once 'inc/core/assets.php';
require_once 'inc/core/shortcodes.php';
require_once 'inc/core/tools.php';
require_once 'inc/core/data.php';
require_once 'inc/core/generator-views.php';
require_once 'inc/core/generator.php';
require_once 'inc/core/widget.php';


// including page Builder Widgets
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if ( is_plugin_active( 'siteorigin-panels/siteorigin-panels.php' ) )
{
	require_once('inc/pb-widgets/widget-testimonials.php');
	require_once('inc/pb-widgets/widget-portfolio.php');	
	require_once('inc/pb-widgets/widget-posts.php');		
	require_once('inc/pb-widgets/widget-spacer.php');	
	require_once('inc/pb-widgets/widget-heading.php');	
	require_once('inc/pb-widgets/widget-prodscroll.php');
	require_once('inc/pb-widgets/widget-team.php');	
	require_once('inc/pb-widgets/widget-services.php');	
	require_once('inc/pb-widgets/widget-iconbox.php');
	require_once('inc/pb-widgets/widget-calltoact.php');
	require_once('inc/pb-widgets/widget-pie.php');
	require_once('inc/pb-widgets/widget-countup.php');
	require_once('inc/pb-widgets/widget-progressbar.php');
	require_once('inc/pb-widgets/widget-blog-carousel.php');
	
	/* JS and CSS files for the controls */
	add_action( 'admin_enqueue_scripts', 'nx_enqueue_iconpicker' );
	function nx_enqueue_iconpicker( $hook_suffix ) {
		wp_enqueue_style( 'simple-iconpicker', get_template_directory_uri().'/css/simple-iconpicker.min.css', array(), '2.09'  );
		wp_enqueue_script( 'simple-iconpicker', get_template_directory_uri().'/js/simple-iconpicker.min.js', array(), '2.09'  );
	}
	
} elseif ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

	/* JS and CSS files for the controls */
	add_action( 'admin_enqueue_scripts', 'nx_enqueue_iconpicker' );
	function nx_enqueue_iconpicker( $hook_suffix ) {
		wp_enqueue_style( 'simple-iconpicker', get_template_directory_uri().'/css/simple-iconpicker.min.css', array(), '2.09'  );
		wp_enqueue_script( 'simple-iconpicker', get_template_directory_uri().'/js/simple-iconpicker.min.js', array(), '2.09'  );
	}
	
}

/* Add SiteOrigin PageBuilder Widget Filter Tab */
function nx_add_widget_tabs($tabs) {
    $tabs[] = array(
        'title' => __('TemplatesNext Shortcode', 'nx'),
        'filter' => array(
            'groups' => array('nx')
        )
    );

    return $tabs;
}
add_filter('siteorigin_panels_widget_dialog_tabs', 'nx_add_widget_tabs', 20);
/*
require 'update/plugin-update-checker.php';
$myUpdateChecker = PucFactory::buildUpdateChecker(
    'http://templatesnext.org/downloads/update-check/nx-update.json',
    __FILE__
);
*/