=== TemplatesNext Shortcode ===
License: GPL
Tags: shortcode, shortcodes, short code, video, responsive, responsive video, youtube, vimeo, audio, tab, tabs, button, buttons, box, boxes, toggle, spoiler, column, columns, services, service, pullquote, list, lists, images, image, links, fancy, fancy link, fancy links, fancy buttons, accordion, slider, plugin, admin, gallery, bloginfo, list pages, sub pages, navigation, carousel, touch, icon, icons
Requires at least: 3.6
Tested up to: 4.8
Stable tag: 1.0.7

Supercharges TemplatesNext Premium WordPress themes with mega pack of shortcodes

== Description ==

[TemplatesNext Shortcode](http://templatesnext.org/nx-shortcode/) is WordPress plugin that provides mega pack of shortcodes. 

With this plugin you can easily create tabs, buttons, boxes, different sliders, responsive videos and much, much more. Turn your free theme to premium in just a few clicks. Using TemplatesNext Shortcode you can quickly and easily retrieve premium themes features and display it on your site. See screenshots for more information.

= Features =
* Shortcode Generator
* 60+ amazing shortcodes
* Modern responsive design
* Power of CSS3
* Custom CSS editor with syntax highlight
* Special widget
* Rich API


= Requirements =
* WordPress 3.6+
* PHP 5.6+

= Got a bug or suggestion? =
* [Documentation](http://templatesnext.org/nx-shortcodes/)
* [Contact author](http://templatesnext.org/feedback/) (Not for support requests)

Have a translation? [Contact me](http://templatesnext.org/feedback/)

= Thanks =
* Dmitry Semenov - [Magnific Popup jQuery plugin](http://dimsemenov.com/plugins/magnific-popup/)
* Craig Thompson - [qTip jQuery plugin](http://qtip2.com/)
* Vladimir Kharlampidi - [Swiper jQuery plugin](http://www.idangero.us/sliders/swiper/)
* Designmodo - [Flat UI Free icons](http://designmodo.com/)
* Dave Gandy - [Font Awesome](http://fontawesome.github.io/Font-Awesome/)
* James Smith - [Simple Slider jQuery plugin](http://loopj.com/jquery-simple-slider/)
* Kevin Batdorf - [Liquid Slider jQuery plugin](http://liquidslider.com)


== Installation ==

Unzip plugin files and upload them under your '/wp-content/plugins/' directory.

Resulted names will be: 
  './wp-content/plugins/nx-shortcode/*'

Activate plugin at "Plugins" administration page.


