jQuery(document).ready(function ($) {
	
	"use strict";
	
	// Enable sliders
	$('.nx-slider').each(function () {
		// Prepare data
		var $slider = $(this);
		// Apply Swiper
		var $swiper = $slider.swiper({
			wrapperClass: 'nx-slider-slides',
			slideClass: 'nx-slider-slide',
			slideActiveClass: 'nx-slider-slide-active',
			slideVisibleClass: 'nx-slider-slide-visible',
			pagination: '#' + $slider.attr('id') + ' .nx-slider-pagination',
			autoplay: $slider.data('autoplay'),
			paginationClickable: true,
			grabCursor: true,
			mode: 'horizontal',
			mousewheelControl: $slider.data('mousewheel'),
			speed: $slider.data('speed'),
			calculateHeight: $slider.hasClass('nx-slider-responsive-yes'),
			loop: true
		});
		// Prev button
		$slider.find('.nx-slider-prev').click(function (e) {
			$swiper.swipeNext();
		});
		// Next button
		$slider.find('.nx-slider-next').click(function (e) {
			$swiper.swipePrev();
		});
	});
	// Enable carousels
	$('.nx-carousel').each(function () {
		// Prepare data
		var $carousel = $(this),
			$slides = $carousel.find('.nx-carousel-slide');
		// Apply Swiper
		var $swiper = $carousel.swiper({
			wrapperClass: 'nx-carousel-slides',
			slideClass: 'nx-carousel-slide',
			slideActiveClass: 'nx-carousel-slide-active',
			slideVisibleClass: 'nx-carousel-slide-visible',
			pagination: '#' + $carousel.attr('id') + ' .nx-carousel-pagination',
			autoplay: $carousel.data('autoplay'),
			paginationClickable: true,
			grabCursor: true,
			mode: 'horizontal',
			mousewheelControl: $carousel.data('mousewheel'),
			speed: $carousel.data('speed'),
			slidesPerView: ($carousel.data('items') > $slides.length) ? $slides.length : $carousel.data('items'),
			slidesPerGroup: $carousel.data('scroll'),
			calculateHeight: $carousel.hasClass('nx-carousel-responsive-yes'),
			loop: true
		});
		// Prev button
		$carousel.find('.nx-carousel-prev').click(function (e) {
			$swiper.swipeNext();
		});
		// Next button
		$carousel.find('.nx-carousel-next').click(function (e) {
			$swiper.swipePrev();
		});
	});
	// Lightbox for galleries (slider, carousel, custom_gallery)
	$('.nx-lightbox-gallery').each(function () {
		$(this).magnificPopup({
			delegate: 'a',
			type: 'image',
			mainClass: 'mfp-img-mobile',
			gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0, 1], // Will preload 0 - before current, and 1 after the current image
				tPrev: nx_magnific_popup.prev,
				tNext: nx_magnific_popup.next,
				tCounter: nx_magnific_popup.counter
			},
			image: {
				tError: nx_magnific_popup.error,
				titleSrc: function (item) {
					return item.el.children('img').attr('alt');
				}
			},
			tClose: nx_magnific_popup.close,
			tLoading: nx_magnific_popup.loading
		});
	});
});