<?php

/*
Plugin Name: Plugin Welcome Screen Example
Plugin URI: https://github.com/danielpataki/plugin-welcome-screen-example/
Description: A simple example plugin for creating welcome screens for your plugins
Version: 1.0
Author: Daniel Pataki
Author URI: http://danielpataki.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


if (isset($_GET['activated']) && is_admin()) {
	set_transient( '_welcome_screen_activation_redirect', true, 30 );
}

add_action( 'admin_init', 'welcome_screen_do_activation_redirect' );
function welcome_screen_do_activation_redirect() {
  // Bail if no activation redirect
    if ( ! get_transient( '_welcome_screen_activation_redirect' ) ) {
    return;
  }

  // Delete the redirect transient
  delete_transient( '_welcome_screen_activation_redirect' );

  // Bail if activating from network, or bulk
  if ( is_network_admin() || isset( $_GET['activate-multi'] ) ) {
    return;
  }

  // Redirect to bbPress about page
  wp_safe_redirect( add_query_arg( array( 'page' => 'welcome-screen-about' ), admin_url( 'themes.php' ) ) );

}

add_action('admin_menu', 'welcome_screen_pages');

function welcome_screen_pages() {
	add_theme_page(
		'Welcome To Welcome i-spirit',
		'About i-spirit',
		'read',
		'welcome-screen-about',
		'welcome_screen_content',
		'dashicons-awards', 
		6 		
	);
}

function welcome_screen_content() {
	
	$logo_url = get_template_directory_uri() . '/inc/theme-welcome/welcome-logo.png';
	$active_tab = 'ispirit_about';
	$ocdi_buttont = "";
	if ( class_exists('OCDI_Plugin') ) {
		$ocdi_buttont = "button-enabled";
	} else
	{
		$ocdi_buttont = "button-disabled";
	} 	
	$details_theme = wp_get_theme();
	$name_version = $details_theme->get( 'Name' ) . " - " . $details_theme->get( 'Version' );
  	?>
  	<div class="wrapp">
        <div class="nx-info-wrap-2 welcome-panel">
        	
        	<div class="nx-info-wrap">
            	
                <div class="nx-welcome">Welcome To <?php echo $name_version; ?></div>
                <p class="nx-info-desc">
                    Congratulations! You are about to use most flexible and powerful premium WordPress theme combined with #1 premium slider and page builder.
                </p>
                <p>&nbsp;</p>
                <div class="nx-admin-row">
                	<div class="one-four-col">
                    	<a href="http://templatesnext.org/ispirit/landing/i-spirit-video-guide/" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-video-alt2"></span></div>
                            <h3 class="tx-admin-link">Video Guide</h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="http://templatesnext.org/ispirit/landing/forums/forum/premium-theme/i-spirit-support/" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-format-chat"></span></div>
                            <h3 class="tx-admin-link">Support Forum</h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="http://templatesnext.org/ispirit/landing/start-up-guide/" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-migrate"></span></div>
                            <h3 class="tx-admin-link">SetUp Guide</h3>
                        </a>
                    </div>
                	<div class="one-four-col">
                    	<a href="https://www.facebook.com/templatesnext" target="_blank">
                            <div class="nx-dash"><span class="dashicons dashicons-facebook-alt"></span></div>
                            <h3 class="tx-admin-link">Community</h3>
                        </a>
                    </div>                                                            
                </div>
                <div class="tx-wspace"></div>
                <?php
					if( isset( $_GET[ 'tab' ] ) ) {
						$active_tab = $_GET[ 'tab' ];
					}
				?>
                <h2 class="nav-tab-wrapper">
                    <a href="?page=welcome-screen-about&tab=ispirit_about" class="nav-tab <?php echo $active_tab == 'ispirit_about' ? 'nav-tab-active' : ''; ?>">About i-spirit</a>
                    <a href="?page=welcome-screen-about&tab=ispirit_kickstart" class="nav-tab <?php echo $active_tab == 'ispirit_kickstart' ? 'nav-tab-active' : ''; ?> nx-kick">1 Click Kickstart</a>
                    <a href="?page=welcome-screen-about&tab=ispirit_plugins" class="nav-tab <?php echo $active_tab == 'ispirit_plugins' ? 'nav-tab-active' : ''; ?> nx-plug">Plugins</a>
                </h2>
                
                <?php
					if( $active_tab == 'ispirit_about' )
					{
				?> 
                	<div class="nx-tab-content"> 
                		<p>&nbsp;</p>
                        <h2>Starting with i-spirit</h2>
                        <ol>
                        	<li>Make sure you have all recomended plugin installed and active. To install and activate all the recommended plugin at once, go to 
                            	menu "Appearance" > "<a href="<?php echo admin_url(); ?>themes.php?page=tgmpa-install-plugins">Install Plugins</a>". 
                                This menu will not be available once all the recommended plugins are installed and active.</li>
                        	<li>To start setting up your theme go to menu "<a href="<?php echo admin_url(); ?>?page=_options&tab=0">i-spirit Options</a>", 
                            	Customizer also have the same settings but some conditional options might not work because of nerrow panel.</li>
                        	<li>i-spirit comes with "<a href="<?php echo admin_url(); ?>themes.php?page=pt-one-click-demo-import">One Click Demo Import</a>", You can import and setup copy of any of our demo website in one click. </li>                                  
                        </ol>
        			</div>
				<?php		
					} elseif ( $active_tab == 'ispirit_kickstart' )
					{
				?>     
                	<div class="nx-tab-content">
                		<h3>Kickstart in one click</h3>
                        <p>Kick start your website in one click, Create a copy of any of our demo website and edit/remove/add contents. 
                        You can also use a demo installation as reference, check how the contents are formatted, copy/edit them in your main installation.</p>
                        <p><b>You must have the plugin "One Click Demo Import" installed and active.</b></p>
                        <a class="button button-primary button-hero <?php echo $ocdi_buttont; ?>" href="<?php echo admin_url(); ?>themes.php?page=pt-one-click-demo-import">One Click Demo Import</a>
                	</div>        
                        
				<?php	
					} elseif ( $active_tab == 'ispirit_plugins' )
					{
				?>     
                	<div class="nx-tab-content">
                		<h3>Required And Recommended Plugins</h3>
                        <h4>TemplatesNext Shortcode ( Prepackaged, <span class="nx-red">Required</span> )</h4>
                        This premium plugin is required for the Custom post type like Prtfolio, Team, Clients, etc and all the shortcode via button 
                        "Insert shortcode". Usage of the shortcodes demonstrated in <a href="https://www.youtube.com/watch?v=Goc_vdnW0wQ" target="_blank">this video</a>.
                        
                        <h4>Slider Revolution ( Prepackaged, <span class="nx-red">Highly Recommended</span> ) <sup>*</sup></h4>
                        The number one premium slider plugin is highly Recommended. i-spirit is configured for "Slider Revolution" slider beside its own 
                        native slider and i-trans slider or any other slider plugin. Slider options are demonstrated in 
                        <a href="https://www.youtube.com/watch?v=hl_H1oAwziY" target="_blank">this video</a>. <br />
                        Video Tutorial : <a href="https://www.youtube.com/watch?v=g-bHV_qll7E" target="_blank">YouTube Video</a>
                                                
                        <h4>WPBakery Visual Composer ( Prepackaged, <span class="nx-red">Recommended</span> ) <sup>*</sup>&nbsp;<sup>**</sup></h4> 
                        Another #1 premium page builder plugin for beginers. If you find it difficult building pages with shortcodes and basic editor tools
                        Use Visual Composer Editor, we have combined our shortcodes and functionality with Visual Composer<br />
                        Video Tutorial : <a href="http://vc.wpbakery.com/video-academy/" target="_blank">VC Video Academy</a><br />

                        
                        <h4>Contact Form 7 ( <span class="nx-red">Recommended</span> )</h4>
                        Recommended for contact forms, For usage view <a href="https://www.youtube.com/watch?v=wy70WGCjMY4" target="_blank">this video</a>.
                        
                        <h4>Max Mega Menu <sup>**</sup></h4>
                        Use if you requre a complex menu structure with images. We have used it in "Shop" demo with i-spirit.<br /> 
                        Plugin URL : <a href="https://wordpress.org/plugins/megamenu/" target="_blank">https://wordpress.org/plugins/megamenu/</a>
                        
                        <h4>Nx Responsive Menu ( <span class="nx-red">Recommended</span> ) <sup>**</sup></h4>
                        If you are looking for a responsive menu with more options and settings, use this configurable plugin for mobile menu.
                        
                        <h4>One Click Demo Import ( <span class="nx-red">Recommended</span> )</h4>
                        Required for one click demo import. if you are building your pages from scratch, you do not need to install this plugin.
                        
                        <h4>amr shortcode any widget <sup>**</sup></h4>
                        This plugin helps you place any widget in any place in a page, not required unless you need it.<br /> 
                        Plugin URL : <a href="https://wordpress.org/plugins/oauth-twitter-feed-for-developers/" target="_blank">https://wordpress.org/plugins/oauth-twitter-feed-for-developers/</a>
                        
                        <h4>oAuth Twitter Feed for Developers <sup>**</sup></h4>
                        Reqired for twitter feed widget.<br /> 
                        Plugin URL : <a href="https://wordpress.org/plugins/amr-shortcode-any-widget/" target="_blank">https://wordpress.org/plugins/amr-shortcode-any-widget/</a>
                        
                        <h4>Breadcrumb NavXT ( <span class="nx-red">Recommended</span> )</h4>
                        It creates the breadcrumb (displayes location of your user beside the title).   
                        
                        <h4>Page Builder by SiteOrigin <sup>**</sup></h4>
                        We recommend premium plugin <b>"WPBakery Visual Composer"</b> instead of page builder. 
                        If you feel comfortable with "page builder", keep "Visual composer" uninstalled/inactive.<br />
                        Plugin URL : <a href="https://wordpress.org/plugins/siteorigin-panels/" target="_blank">https://wordpress.org/plugins/siteorigin-panels/</a><br />
                        Tutorials : <a href="https://siteorigin.com/page-builder/documentation/" target="_blank">https://siteorigin.com/page-builder/documentation/</a>
                        
                        <h4>SiteOrigin Widgets Bundle <sup>**</sup></h4>
                        This plugin adds additional widgets for "SiteOrigin Page Builder".<br />
                        Plugin URL : <a href="https://wordpress.org/plugins/so-widgets-bundle/" target="_blank">https://wordpress.org/plugins/so-widgets-bundle/</a> 
                        
                        <p><sup>*</sup> <span class="nx-black">We have exclusive right to prepackage full version of "Slider Revolution" and "Visual Composer" premium plugin with i-spirit. 
                        Updates and support for these plugins are provided by us. ONLY for direct update and support you will have to buy individual licence.</span></p>  
						<p><sup>**</sup> <span class="nx-black">Unless you are using the features of these plugin, keep them inactive or do not install these plugins. 
                        Less the number of active plugins, faster and lighter will be your website</span></p>                                                       	
                     
                     
                     </div>        
                        
				<?php	
					}
				?>                
                
            </div>
        	<div class="welcome-logo"><img src="<?php echo $logo_url; ?>" alt="" class="welcome-logo-img" width="" /></div>
            <div class="tx-wspace"></div>
        </div>
  	</div>
  	<?php
}

add_action( 'admin_head', 'welcome_screen_remove_menus' );

function welcome_screen_remove_menus() {
    remove_submenu_page( 'index.php', 'welcome-screen-about' );
}

add_action('admin_head', 'nx_welcome_style');

function nx_welcome_style() {
  	echo '<style>
		.nx-info-wrap {
			display: block;
			float: left;
			max-width: 800px;
			padding: 12px;
			display: inline-block;
		}
		
		.welcome-panel .nx-welcome,
		.nx-info-wrap .nx-welcome {
			font-size: 28px; 
			font-weight: 600; 
			padding-bottom: 0px;
			line-height: 32px;
		}
		
		.nx-info-wrap .nx-info-desc {
			font-size: 16px;
			line-height: 22px;
		}
		
		.welcome-logo {
			display: block;
			float: left;
			max-width: 160px;
			padding-top: 24px;
			margin-left: 32px;
		}
		.welcome-logo-img {
			width: 160px;
		}
		.nx-admin-row {
			display: block;
			clear: both;
			box-sizing: border-box;
		}
		.nx-admin-row:after {
			display: table;
			clear: both;
			width: 100%;
			content: " ";
			display: block;
		}
		.one-four-col {
			display: block;
			float: left;
			width: 24%;
			padding: 16px;
			box-sizing: border-box;	
			text-align: center;
			background-color: #f1f1f1;
			margin-right: 1%;
		}
		.one-four-col:hover {
			background-color: #FFFFFF;
		}
		.one-four-col a {
			display: block;
		}				
		
		.one-four-col:last-child {
			margin-right: 0px;
		}		
		.one-four-col h3 {
			text-transform: uppercase;
		}		
		.nx-dash {
			font-size: 48px;
			line-height: 80px;
			width: 80px;
			border: 4px solid #f1f1f1;
			margin: auto;
			border-radius: 42px;
			background-color: #dd9933;
		}		
		.nx-dash span {
			font-size: 48px;
			line-height: 80px;
			width: 64px;
			color: #FFF;
		}
		
		.nx-kick,
		.nx-kick:visited {
			background-color: #dd9933;
			color: #FFF;
		}
		.tx-wspace {
			display: block;
			clear: both;
			width: 100%;
			height: 120px;
		}
		.tx-wspace-12 {
			display: block;
			clear: both;
			width: 100%;
			height: 12px;
		}		
		.nx-tab-content {
			font-size: 15px;
		}
		.nx-tab-content p {
			font-size: 15px;
		}
		.nx-red {
			color: #b40000;
		}
		.nx-black {
			color: #333;
			font-size: 12px;
		}
		.nx-tab-content h4 {
			padding: 0px;
			margin: 0px;
			margin-top: 18px;
			font-size: 16px;
		}
		
  	</style>';
}


