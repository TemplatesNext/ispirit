// JavaScript Document

jQuery(document).ready(function($) {
	var admin_url = ispirit_nxc_variables.admin_url+"?page=_options&tab=0";
	var nx_customizer_info = "<b>Use menu \"<a href=\""+admin_url+"\">i-spirit Options</a>\" <b> to setup i-spirit instead of customizer, all theme settings are available there.";
	$( '#customize-theme-controls ul' ).first().prepend( '<li id="nx-custom-intro" class="accordion-section nx-custom-intro" style="position: relative;"><div class="nxc-info" style="padding: 12px;">'+nx_customizer_info+'</div></li>' );
});	
